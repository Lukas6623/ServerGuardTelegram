from aiogram.types import (
    InlineKeyboardMarkup,
    InlineKeyboardButton
)

from i18n import (
    LANGUAGES,
    tr
)


# ============================================================
# MAIN KEYBOARD
# ============================================================

def main_keyboard(
    language
):

    return InlineKeyboardMarkup(
        inline_keyboard=[

            [
                InlineKeyboardButton(
                    text=tr(
                        language,
                        "menu.protection"
                    ),
                    callback_data="menu:status"
                )
            ],

            [
                InlineKeyboardButton(
                    text=tr(
                        language,
                        "menu.blocked_ips"
                    ),
                    callback_data="menu:blocked"
                ),

                InlineKeyboardButton(
                    text=tr(
                        language,
                        "menu.events"
                    ),
                    callback_data="menu:events"
                )
            ],

            [
                InlineKeyboardButton(
                    text=tr(
                        language,
                        "menu.fileguard"
                    ),
                    callback_data="menu:fileguard"
                ),

                InlineKeyboardButton(
                    text=tr(
                        language,
                        "menu.ip_management"
                    ),
                    callback_data="menu:ip"
                )
            ],

            [
                InlineKeyboardButton(
                    text=tr(
                        language,
                        "menu.settings"
                    ),
                    callback_data="menu:settings"
                )
            ],

            [
                InlineKeyboardButton(
                    text=tr(
                        language,
                        "menu.refresh"
                    ),
                    callback_data="menu:home"
                )
            ]
        ]
    )


# ============================================================
# PROTECTION SETTINGS KEYBOARD
# ============================================================

def protection_keyboard():

    return InlineKeyboardMarkup(
        inline_keyboard=[

            [
                InlineKeyboardButton(
                    text="🟢 / 🔴 Enable / Disable",
                    callback_data="protection:toggle"
                )
            ],

            [
                InlineKeyboardButton(
                    text="🔢 Attempts",
                    callback_data="protection:attempts"
                ),

                InlineKeyboardButton(
                    text="⏱ Duration",
                    callback_data="protection:duration"
                )
            ],

            [
                InlineKeyboardButton(
                    text="♾️ Permanent blocking",
                    callback_data="protection:permanent"
                )
            ],

            [
                InlineKeyboardButton(
                    text="🌐 Whitelist",
                    callback_data="protection:whitelist"
                )
            ],

            [
                InlineKeyboardButton(
                    text="📊 Statistics",
                    callback_data="protection:show"
                )
            ],

            [
                InlineKeyboardButton(
                    text="⚙️ Reset settings",
                    callback_data="protection:reset"
                )
            ],

            [
                InlineKeyboardButton(
                    text="🔄 Refresh",
                    callback_data="protection:show"
                )
            ],

            [
                InlineKeyboardButton(
                    text="◀️ Back to Settings",
                    callback_data="menu:settings"
                )
            ]
        ]
    )


# ============================================================
# ATTEMPTS KEYBOARD
# ============================================================

def protection_attempts_keyboard():

    return InlineKeyboardMarkup(
        inline_keyboard=[

            [
                InlineKeyboardButton(
                    text="1",
                    callback_data="protection_attempts:1"
                ),

                InlineKeyboardButton(
                    text="2",
                    callback_data="protection_attempts:2"
                ),

                InlineKeyboardButton(
                    text="3",
                    callback_data="protection_attempts:3"
                ),

                InlineKeyboardButton(
                    text="5",
                    callback_data="protection_attempts:5"
                )
            ],

            [
                InlineKeyboardButton(
                    text="10",
                    callback_data="protection_attempts:10"
                ),

                InlineKeyboardButton(
                    text="20",
                    callback_data="protection_attempts:20"
                ),

                InlineKeyboardButton(
                    text="50",
                    callback_data="protection_attempts:50"
                ),

                InlineKeyboardButton(
                    text="100",
                    callback_data="protection_attempts:100"
                )
            ],

            [
                InlineKeyboardButton(
                    text="✏️ Custom value",
                    callback_data="protection_attempts:custom"
                )
            ],

            [
                InlineKeyboardButton(
                    text="◀️ Back",
                    callback_data="protection:show"
                )
            ]
        ]
    )


# ============================================================
# DURATION KEYBOARD
# ============================================================

def protection_duration_keyboard():

    return InlineKeyboardMarkup(
        inline_keyboard=[

            [
                InlineKeyboardButton(
                    text="1 min",
                    callback_data="protection_duration:60"
                ),

                InlineKeyboardButton(
                    text="5 min",
                    callback_data="protection_duration:300"
                ),

                InlineKeyboardButton(
                    text="10 min",
                    callback_data="protection_duration:600"
                )
            ],

            [
                InlineKeyboardButton(
                    text="20 min",
                    callback_data="protection_duration:1200"
                ),

                InlineKeyboardButton(
                    text="30 min",
                    callback_data="protection_duration:1800"
                ),

                InlineKeyboardButton(
                    text="1 hour",
                    callback_data="protection_duration:3600"
                )
            ],

            [
                InlineKeyboardButton(
                    text="2 hours",
                    callback_data="protection_duration:7200"
                ),

                InlineKeyboardButton(
                    text="6 hours",
                    callback_data="protection_duration:21600"
                ),

                InlineKeyboardButton(
                    text="12 hours",
                    callback_data="protection_duration:43200"
                )
            ],

            [
                InlineKeyboardButton(
                    text="24 hours",
                    callback_data="protection_duration:86400"
                )
            ],

            [
                InlineKeyboardButton(
                    text="7 days",
                    callback_data="protection_duration:604800"
                ),

                InlineKeyboardButton(
                    text="30 days",
                    callback_data="protection_duration:2592000"
                )
            ],

            [
                InlineKeyboardButton(
                    text="✏️ Custom value",
                    callback_data="protection_duration:custom"
                )
            ],

            [
                InlineKeyboardButton(
                    text="◀️ Back",
                    callback_data="protection:show"
                )
            ]
        ]
    )


# ============================================================
# PERMANENT KEYBOARD
# ============================================================

def protection_permanent_keyboard():

    return InlineKeyboardMarkup(
        inline_keyboard=[

            [
                InlineKeyboardButton(
                    text="♾️ Permanent: ON",
                    callback_data="protection_permanent:on"
                )
            ],

            [
                InlineKeyboardButton(
                    text="⏱️ Permanent: OFF",
                    callback_data="protection_permanent:off"
                )
            ],

            [
                InlineKeyboardButton(
                    text="◀️ Back",
                    callback_data="protection:show"
                )
            ]
        ]
    )


# ============================================================
# WHITELIST KEYBOARD
# ============================================================

def protection_whitelist_keyboard():

    return InlineKeyboardMarkup(
        inline_keyboard=[

            [
                InlineKeyboardButton(
                    text="➕ Add IP",
                    callback_data="protection_whitelist:add"
                )
            ],

            [
                InlineKeyboardButton(
                    text="➖ Remove IP",
                    callback_data="protection_whitelist:remove"
                )
            ],

            [
                InlineKeyboardButton(
                    text="📋 List",
                    callback_data="protection_whitelist:list"
                )
            ],

            [
                InlineKeyboardButton(
                    text="◀️ Back",
                    callback_data="protection:show"
                )
            ]
        ]
    )


# ============================================================
# IP KEYBOARD
# ============================================================

def ip_keyboard(
    language
):

    return InlineKeyboardMarkup(
        inline_keyboard=[

            [
                InlineKeyboardButton(
                    text=tr(
                        language,
                        "ip.block"
                    ),
                    callback_data="ip:block"
                ),

                InlineKeyboardButton(
                    text=tr(
                        language,
                        "ip.unblock"
                    ),
                    callback_data="ip:unblock"
                )
            ],

            [
                InlineKeyboardButton(
                    text=tr(
                        language,
                        "ip.check"
                    ),
                    callback_data="ip:check"
                ),

                InlineKeyboardButton(
                    text=tr(
                        language,
                        "ip.list"
                    ),
                    callback_data="ip:list"
                )
            ],

            [
                InlineKeyboardButton(
                    text=tr(
                        language,
                        "common.back"
                    ),
                    callback_data="menu:home"
                )
            ]
        ]
    )


# ============================================================
# SETTINGS KEYBOARD
# ============================================================

def settings_keyboard(
    language
):

    return InlineKeyboardMarkup(
        inline_keyboard=[

            [
                InlineKeyboardButton(
                    text="🛡️ Protection settings",
                    callback_data="settings:protection"
                )
            ],

            [
                InlineKeyboardButton(
                    text=tr(
                        language,
                        "settings.language"
                    ),
                    callback_data="settings:language"
                )
            ],

            [
                InlineKeyboardButton(
                    text=tr(
                        language,
                        "settings.timezone"
                    ),
                    callback_data="settings:timezone"
                )
            ],

            [
                InlineKeyboardButton(
                    text=tr(
                        language,
                        "settings.notifications"
                    ),
                    callback_data="settings:notifications"
                )
            ],

            [
                InlineKeyboardButton(
                    text=tr(
                        language,
                        "common.back"
                    ),
                    callback_data="menu:home"
                )
            ]
        ]
    )


# ============================================================
# CONFIRM KEYBOARD
# ============================================================

def confirm_keyboard(
    language,
    action
):

    return InlineKeyboardMarkup(
        inline_keyboard=[

            [
                InlineKeyboardButton(
                    text=tr(
                        language,
                        "common.confirm"
                    ),
                    callback_data=f"confirm:{action}"
                ),

                InlineKeyboardButton(
                    text=tr(
                        language,
                        "common.cancel"
                    ),
                    callback_data="menu:ip"
                )
            ]
        ]
    )


# ============================================================
# LANGUAGE KEYBOARD
# ============================================================

def language_keyboard(
    page=0
):

    languages = list(
        LANGUAGES.items()
    )

    per_page = 10

    start = (
        page * per_page
    )

    end = (
        start + per_page
    )

    current = languages[
        start:end
    ]

    rows = []

    row = []

    for code, data in current:

        flag, name = data

        row.append(
            InlineKeyboardButton(
                text=f"{flag} {name}",
                callback_data=f"lang:{code}"
            )
        )

        if len(row) == 2:

            rows.append(
                row
            )

            row = []

    if row:

        rows.append(
            row
        )

    navigation = []

    if page > 0:

        navigation.append(
            InlineKeyboardButton(
                text="◀️",
                callback_data=(
                    f"langpage:{page - 1}"
                )
            )
        )

    if end < len(languages):

        navigation.append(
            InlineKeyboardButton(
                text="▶️",
                callback_data=(
                    f"langpage:{page + 1}"
                )
            )
        )

    if navigation:

        rows.append(
            navigation
        )

    return InlineKeyboardMarkup(
        inline_keyboard=rows
    )