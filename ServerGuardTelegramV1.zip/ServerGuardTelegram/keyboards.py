from aiogram.types import (
    InlineKeyboardMarkup,
    InlineKeyboardButton
)

from i18n import (
    LANGUAGES,
    tr
)


def main_keyboard(
    language
):

    return InlineKeyboardMarkup(
        inline_keyboard=[

            [
                InlineKeyboardButton(
                    text=tr(
                        language,
                        "menu.protection"
                    ),
                    callback_data="menu:status"
                )
            ],

            [
                InlineKeyboardButton(
                    text=tr(
                        language,
                        "menu.blocked_ips"
                    ),
                    callback_data="menu:blocked"
                ),

                InlineKeyboardButton(
                    text=tr(
                        language,
                        "menu.events"
                    ),
                    callback_data="menu:events"
                )
            ],

            [
                InlineKeyboardButton(
                    text=tr(
                        language,
                        "menu.fileguard"
                    ),
                    callback_data="menu:fileguard"
                ),

                InlineKeyboardButton(
                    text=tr(
                        language,
                        "menu.ip_management"
                    ),
                    callback_data="menu:ip"
                )
            ],

            [
                InlineKeyboardButton(
                    text=tr(
                        language,
                        "menu.settings"
                    ),
                    callback_data="menu:settings"
                )
            ],

            [
                InlineKeyboardButton(
                    text=tr(
                        language,
                        "menu.refresh"
                    ),
                    callback_data="menu:home"
                )
            ]
        ]
    )


def ip_keyboard(
    language
):

    return InlineKeyboardMarkup(
        inline_keyboard=[

            [
                InlineKeyboardButton(
                    text=tr(
                        language,
                        "ip.block"
                    ),
                    callback_data="ip:block"
                ),

                InlineKeyboardButton(
                    text=tr(
                        language,
                        "ip.unblock"
                    ),
                    callback_data="ip:unblock"
                )
            ],

            [
                InlineKeyboardButton(
                    text=tr(
                        language,
                        "ip.check"
                    ),
                    callback_data="ip:check"
                ),

                InlineKeyboardButton(
                    text=tr(
                        language,
                        "ip.list"
                    ),
                    callback_data="ip:list"
                )
            ],

            [
                InlineKeyboardButton(
                    text=tr(
                        language,
                        "common.back"
                    ),
                    callback_data="menu:home"
                )
            ]
        ]
    )


def settings_keyboard(
    language
):

    return InlineKeyboardMarkup(
        inline_keyboard=[

            [
                InlineKeyboardButton(
                    text=tr(
                        language,
                        "settings.language"
                    ),
                    callback_data="settings:language"
                )
            ],

            [
                InlineKeyboardButton(
                    text=tr(
                        language,
                        "settings.timezone"
                    ),
                    callback_data="settings:timezone"
                )
            ],

            [
                InlineKeyboardButton(
                    text=tr(
                        language,
                        "settings.notifications"
                    ),
                    callback_data="settings:notifications"
                )
            ],

            [
                InlineKeyboardButton(
                    text=tr(
                        language,
                        "common.back"
                    ),
                    callback_data="menu:home"
                )
            ]
        ]
    )


def confirm_keyboard(
    language,
    action
):

    return InlineKeyboardMarkup(
        inline_keyboard=[

            [
                InlineKeyboardButton(
                    text=tr(
                        language,
                        "common.confirm"
                    ),
                    callback_data=f"confirm:{action}"
                ),

                InlineKeyboardButton(
                    text=tr(
                        language,
                        "common.cancel"
                    ),
                    callback_data="menu:ip"
                )
            ]
        ]
    )


def language_keyboard(
    page=0
):

    languages = list(
        LANGUAGES.items()
    )

    per_page = 10

    start = (
        page * per_page
    )

    end = (
        start + per_page
    )

    current = languages[
        start:end
    ]

    rows = []

    row = []

    for code, data in current:

        flag, name = data

        row.append(
            InlineKeyboardButton(
                text=f"{flag} {name}",
                callback_data=f"lang:{code}"
            )
        )

        if len(row) == 2:

            rows.append(
                row
            )

            row = []

    if row:

        rows.append(
            row
        )

    navigation = []

    if page > 0:

        navigation.append(
            InlineKeyboardButton(
                text="◀️",
                callback_data=(
                    f"langpage:{page - 1}"
                )
            )
        )

    if end < len(languages):

        navigation.append(
            InlineKeyboardButton(
                text="▶️",
                callback_data=(
                    f"langpage:{page + 1}"
                )
            )
        )

    if navigation:

        rows.append(
            navigation
        )

    return InlineKeyboardMarkup(
        inline_keyboard=rows
    )