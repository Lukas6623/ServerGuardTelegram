import html

from aiogram import Dispatcher, F

from aiogram.filters import (
    Command,
    CommandStart
)

from aiogram.types import (
    Message,
    CallbackQuery,
    InlineKeyboardMarkup,
    InlineKeyboardButton
)

from database import (
    is_owner,
    get_owner,
    get_owner_language,
    get_owner_timezone,
    set_owner_language,
    set_owner_timezone
)

from i18n import (
    LANGUAGES,
    tr
)

from keyboards import (
    main_keyboard,
    ip_keyboard,
    settings_keyboard,
    confirm_keyboard,
    language_keyboard
)

from registration import (
    handle_start
)

from security import (
    build_status_text,
    build_blocked_text,
    build_events_text
)

from fileguard import status as fileguard_status

from ip_manager import (
    validate_ip,
    ufw_is_blocked,
    ufw_block_ip,
    ufw_unblock_ip,
    get_server_ips
)


# ============================================================
# USER ACTIONS
# ============================================================

USER_ACTIONS = {}


# ============================================================
# FILEGUARD
# ============================================================

def build_fileguard_text(
    language
):

    data = fileguard_status()

    if data["active"]:

        state = tr(
            language,
            "status.active"
        )

    elif data["installed"]:

        state = tr(
            language,
            "status.stopped"
        )

    else:

        state = tr(
            language,
            "status.not_installed"
        )

    return (

        tr(
            language,
            "fileguard.title"
        )

        + "\n\n"

        + tr(
            language,
            "fileguard.state",
            value=state
        )

        + "\n\n"

        + tr(
            language,
            "fileguard.events",
            value=data["events"]
        )

        + "\n"

        + tr(
            language,
            "status.critical",
            value=data["critical"]
        )

        + "\n"

        + tr(
            language,
            "status.high",
            value=data["high"]
        )

        + "\n"

        + tr(
            language,
            "status.medium",
            value=data["medium"]
        )
    )


# ============================================================
# /START
# ============================================================

async def cmd_start(
    message: Message
):

    await handle_start(
        message
    )


# ============================================================
# /STATUS
# ============================================================

async def cmd_status(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        return

    language = get_owner_language()

    await message.answer(

        build_status_text(
            language
        ),

        reply_markup=main_keyboard(
            language
        )
    )


# ============================================================
# /BLOCKED
# ============================================================

async def cmd_blocked(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        return

    language = get_owner_language()

    await message.answer(

        build_blocked_text(
            language
        ),

        reply_markup=main_keyboard(
            language
        )
    )


# ============================================================
# /EVENTS
# ============================================================

async def cmd_events(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        return

    language = get_owner_language()

    await message.answer(

        build_events_text(
            language
        ),

        reply_markup=main_keyboard(
            language
        )
    )


# ============================================================
# /FILEGUARD
# ============================================================

async def cmd_fileguard(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        return

    language = get_owner_language()

    await message.answer(

        build_fileguard_text(
            language
        ),

        reply_markup=main_keyboard(
            language
        )
    )


# ============================================================
# /LANGUAGE
# ============================================================

async def cmd_language(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        return

    language = get_owner_language()

    await message.answer(

        tr(
            language,
            "language.select"
        ),

        reply_markup=language_keyboard()
    )


# ============================================================
# /TIMEZONE
# ============================================================

async def cmd_timezone(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        return

    language = get_owner_language()

    parts = (
        message.text or ""
    ).split(
        maxsplit=1
    )

    if len(parts) == 1:

        await message.answer(

            tr(
                language,
                "timezone.current",
                value=html.escape(
                    get_owner_timezone()
                )
            ),

            reply_markup=settings_keyboard(
                language
            )
        )

        return

    timezone_name = parts[1].strip()

    try:

        from zoneinfo import ZoneInfo

        ZoneInfo(
            timezone_name
        )

    except Exception:

        await message.answer(

            tr(
                language,
                "timezone.invalid"
            )
        )

        return

    if set_owner_timezone(
        message.chat.id,
        timezone_name
    ):

        await message.answer(

            tr(
                language,
                "timezone.changed",
                value=html.escape(
                    timezone_name
                )
            ),

            reply_markup=settings_keyboard(
                language
            )
        )


# ============================================================
# /IP
# ============================================================

async def cmd_ip(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        return

    language = get_owner_language()

    parts = (
        message.text or ""
    ).split()

    if len(parts) != 2:

        await message.answer(

            tr(
                language,
                "ip.send_ip"
            )
        )

        return

    ip = validate_ip(
        parts[1]
    )

    if not ip:

        await message.answer(

            tr(
                language,
                "ip.invalid"
            )
        )

        return

    if ufw_is_blocked(
        ip
    ):

        state = tr(
            language,
            "ip.current_blocked"
        )

    else:

        state = tr(
            language,
            "ip.current_unblocked"
        )

    await message.answer(

        tr(
            language,
            "ip.check_result",
            ip=html.escape(ip),
            status=state
        ),

        reply_markup=ip_keyboard(
            language
        )
    )


# ============================================================
# MENU CALLBACK
# ============================================================

async def callback_menu(
    callback: CallbackQuery
):

    if not is_owner(
        callback.message.chat.id
    ):

        await callback.answer(
            "Access denied.",
            show_alert=True
        )

        return

    language = get_owner_language()

    action = callback.data.split(
        ":",
        1
    )[1]

    if action == "home":

        await callback.message.edit_text(

            tr(
                language,
                "home.title"
            ),

            reply_markup=main_keyboard(
                language
            )
        )

    elif action == "status":

        await callback.message.edit_text(

            build_status_text(
                language
            ),

            reply_markup=main_keyboard(
                language
            )
        )

    elif action == "blocked":

        await callback.message.edit_text(

            build_blocked_text(
                language
            ),

            reply_markup=main_keyboard(
                language
            )
        )

    elif action == "events":

        await callback.message.edit_text(

            build_events_text(
                language
            ),

            reply_markup=main_keyboard(
                language
            )
        )

    elif action == "fileguard":

        await callback.message.edit_text(

            build_fileguard_text(
                language
            ),

            reply_markup=main_keyboard(
                language
            )
        )

    elif action == "ip":

        await callback.message.edit_text(

            tr(
                language,
                "ip.title"
            ),

            reply_markup=ip_keyboard(
                language
            )
        )

    elif action == "settings":

        await callback.message.edit_text(

            tr(
                language,
                "settings.title"
            ),

            reply_markup=settings_keyboard(
                language
            )
        )

    await callback.answer()


# ============================================================
# LANGUAGE CALLBACK
# ============================================================

async def callback_language(
    callback: CallbackQuery
):

    if not is_owner(
        callback.message.chat.id
    ):

        await callback.answer(
            "Access denied.",
            show_alert=True
        )

        return

    language = callback.data.split(
        ":",
        1
    )[1]

    if language not in LANGUAGES:

        await callback.answer(
            "Invalid language.",
            show_alert=True
        )

        return

    if not set_owner_language(
        callback.message.chat.id,
        language
    ):

        await callback.answer(
            "Language error.",
            show_alert=True
        )

        return

    await callback.message.edit_text(

        tr(
            language,
            "language.changed"
        ),

        reply_markup=main_keyboard(
            language
        )
    )

    await callback.answer()


# ============================================================
# LANGUAGE PAGE
# ============================================================

async def callback_language_page(
    callback: CallbackQuery
):

    if not is_owner(
        callback.message.chat.id
    ):

        await callback.answer(
            "Access denied.",
            show_alert=True
        )

        return

    page = int(
        callback.data.split(
            ":",
            1
        )[1]
    )

    await callback.message.edit_reply_markup(

        reply_markup=language_keyboard(
            page
        )
    )

    await callback.answer()


# ============================================================
# SETTINGS
# ============================================================

async def callback_settings(
    callback: CallbackQuery
):

    if not is_owner(
        callback.message.chat.id
    ):

        await callback.answer(
            "Access denied.",
            show_alert=True
        )

        return

    language = get_owner_language()

    action = callback.data.split(
        ":",
        1
    )[1]

    if action == "language":

        await callback.message.edit_text(

            tr(
                language,
                "language.select"
            ),

            reply_markup=language_keyboard()
        )

    elif action == "timezone":

        await callback.message.edit_text(

            tr(
                language,
                "timezone.current",
                value=html.escape(
                    get_owner_timezone()
                )
            ),

            reply_markup=settings_keyboard(
                language
            )
        )

    elif action == "notifications":

        await callback.message.edit_text(

            tr(
                language,
                "settings.notifications_text"
            ),

            reply_markup=settings_keyboard(
                language
            )
        )

    await callback.answer()


# ============================================================
# IP MENU
# ============================================================

async def callback_ip(
    callback: CallbackQuery
):

    if not is_owner(
        callback.message.chat.id
    ):

        await callback.answer(
            "Access denied.",
            show_alert=True
        )

        return

    language = get_owner_language()

    action = callback.data.split(
        ":",
        1
    )[1]

    chat_id = callback.message.chat.id

    if action == "block":

        USER_ACTIONS[
            chat_id
        ] = "block"

        await callback.message.edit_text(

            tr(
                language,
                "ip.enter_block"
            ),

            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text=tr(
                                language,
                                "common.cancel"
                            ),
                            callback_data="menu:ip"
                        )
                    ]
                ]
            )
        )

    elif action == "unblock":

        USER_ACTIONS[
            chat_id
        ] = "unblock"

        await callback.message.edit_text(

            tr(
                language,
                "ip.enter_unblock"
            ),

            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text=tr(
                                language,
                                "common.cancel"
                            ),
                            callback_data="menu:ip"
                        )
                    ]
                ]
            )
        )

    elif action == "check":

        USER_ACTIONS[
            chat_id
        ] = "check"

        await callback.message.edit_text(

            tr(
                language,
                "ip.enter_check"
            ),

            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text=tr(
                                language,
                                "common.cancel"
                            ),
                            callback_data="menu:ip"
                        )
                    ]
                ]
            )
        )

    elif action == "list":

        await callback.message.edit_text(

            build_blocked_text(
                language
            ),

            reply_markup=ip_keyboard(
                language
            )
        )

    await callback.answer()


# ============================================================
# CONFIRM
# ============================================================

async def callback_confirm(
    callback: CallbackQuery
):

    if not is_owner(
        callback.message.chat.id
    ):

        await callback.answer(
            "Access denied.",
            show_alert=True
        )

        return

    chat_id = callback.message.chat.id

    language = get_owner_language()

    data = USER_ACTIONS.get(
        chat_id
    )

    if not data:

        await callback.answer(
            "Action expired.",
            show_alert=True
        )

        return

    action, ip = data.split(
        ":",
        1
    )

    USER_ACTIONS.pop(
        chat_id,
        None
    )

    if action == "block":

        if ip in get_server_ips():

            await callback.message.edit_text(

                tr(
                    language,
                    "ip.server_ip_warning",
                    ip=html.escape(ip)
                ),

                reply_markup=ip_keyboard(
                    language
                )
            )

            await callback.answer()

            return

        success = ufw_block_ip(
            ip
        )

        if success:

            text = tr(
                language,
                "ip.blocked_success",
                ip=html.escape(ip)
            )

        else:

            text = tr(
                language,
                "ip.block_failed",
                ip=html.escape(ip)
            )

        await callback.message.edit_text(

            text,

            reply_markup=ip_keyboard(
                language
            )
        )

    elif action == "unblock":

        success = ufw_unblock_ip(
            ip
        )

        if success:

            text = tr(
                language,
                "ip.unblocked_success",
                ip=html.escape(ip)
            )

        else:

            text = tr(
                language,
                "ip.unblock_failed",
                ip=html.escape(ip)
            )

        await callback.message.edit_text(

            text,

            reply_markup=ip_keyboard(
                language
            )
        )

    await callback.answer()


# ============================================================
# TEXT IP ACTION
# ============================================================

async def handle_text(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        await message.answer(
            "⛔ Access denied."
        )

        return

    chat_id = message.chat.id

    action = USER_ACTIONS.get(
        chat_id
    )

    if not action:

        language = get_owner_language()

        await message.answer(

            tr(
                language,
                "common.use_menu"
            ),

            reply_markup=main_keyboard(
                language
            )
        )

        return

    language = get_owner_language()

    ip = validate_ip(
        message.text or ""
    )

    if not ip:

        await message.answer(

            tr(
                language,
                "ip.invalid"
            )
        )

        return

    USER_ACTIONS.pop(
        chat_id,
        None
    )

    if action == "check":

        if ufw_is_blocked(
            ip
        ):

            state = tr(
                language,
                "ip.current_blocked"
            )

        else:

            state = tr(
                language,
                "ip.current_unblocked"
            )

        await message.answer(

            tr(
                language,
                "ip.check_result",
                ip=html.escape(ip),
                status=state
            ),

            reply_markup=ip_keyboard(
                language
            )
        )

        return

    if action == "block":

        if ip in get_server_ips():

            await message.answer(

                tr(
                    language,
                    "ip.server_ip_warning",
                    ip=html.escape(ip)
                ),

                reply_markup=ip_keyboard(
                    language
                )
            )

            return

        if ufw_is_blocked(
            ip
        ):

            await message.answer(

                tr(
                    language,
                    "ip.already_blocked",
                    ip=html.escape(ip)
                ),

                reply_markup=ip_keyboard(
                    language
                )
            )

            return

        USER_ACTIONS[
            chat_id
        ] = f"block:{ip}"

        await message.answer(

            tr(
                language,
                "ip.confirm_block",
                ip=html.escape(ip)
            ),

            reply_markup=confirm_keyboard(
                language,
                "block"
            )
        )

        return

    if action == "unblock":

        USER_ACTIONS[
            chat_id
        ] = f"unblock:{ip}"

        await message.answer(

            tr(
                language,
                "ip.confirm_unblock",
                ip=html.escape(ip)
            ),

            reply_markup=confirm_keyboard(
                language,
                "unblock"
            )
        )


# ============================================================
# REGISTER
# ============================================================

def register_handlers(
    dp: Dispatcher
):

    dp.message.register(
        cmd_start,
        CommandStart()
    )

    dp.message.register(
        cmd_status,
        Command("status")
    )

    dp.message.register(
        cmd_blocked,
        Command("blocked")
    )

    dp.message.register(
        cmd_events,
        Command("events")
    )

    dp.message.register(
        cmd_fileguard,
        Command("fileguard")
    )

    dp.message.register(
        cmd_language,
        Command("language")
    )

    dp.message.register(
        cmd_timezone,
        Command("timezone")
    )

    dp.message.register(
        cmd_ip,
        Command("ip")
    )

    # --------------------------------------------------------
    # LANGUAGE
    # --------------------------------------------------------

    dp.callback_query.register(
        callback_language,
        F.data.startswith("lang:")
    )

    dp.callback_query.register(
        callback_language_page,
        F.data.startswith("langpage:")
    )

    # --------------------------------------------------------
    # SETTINGS
    # --------------------------------------------------------

    dp.callback_query.register(
        callback_settings,
        F.data.startswith("settings:")
    )

    # --------------------------------------------------------
    # IP
    # --------------------------------------------------------

    dp.callback_query.register(
        callback_ip,
        F.data.startswith("ip:")
    )

    dp.callback_query.register(
        callback_confirm,
        F.data.startswith("confirm:")
    )

    # --------------------------------------------------------
    # MENU
    # --------------------------------------------------------

    dp.callback_query.register(
        callback_menu,
        F.data.startswith("menu:")
    )

    # --------------------------------------------------------
    # TEXT
    # --------------------------------------------------------

    dp.message.register(
        handle_text
    )