from config import (
    LOCALES_DIR,
    DEFAULT_LANGUAGE
)

from database import get_owner_language


LANGUAGES = {

    "en": ("🇬🇧", "English"),

    "uk": ("🇺🇦", "Українська"),

    "ru": ("🇷🇺", "Русский"),

    "de": ("🇩🇪", "Deutsch"),

    "fr": ("🇫🇷", "Français"),

    "es": ("🇪🇸", "Español"),

    "it": ("🇮🇹", "Italiano"),

    "pt": ("🇵🇹", "Português"),

    "pl": ("🇵🇱", "Polski"),

    "cs": ("🇨🇿", "Čeština"),

    "sk": ("🇸🇰", "Slovenčina"),

    "ro": ("🇷🇴", "Română"),

    "hu": ("🇭🇺", "Magyar"),

    "tr": ("🇹🇷", "Türkçe"),

    "nl": ("🇳🇱", "Nederlands"),

    "sv": ("🇸🇪", "Svenska"),

    "no": ("🇳🇴", "Norsk"),

    "da": ("🇩🇰", "Dansk"),

    "fi": ("🇫🇮", "Suomi"),

    "bg": ("🇧🇬", "Български"),

    "el": ("🇬🇷", "Ελληνικά"),

    "ar": ("🇸🇦", "العربية"),

    "he": ("🇮🇱", "עברית"),

    "hi": ("🇮🇳", "हिन्दी"),

    "id": ("🇮🇩", "Bahasa Indonesia"),

    "vi": ("🇻🇳", "Tiếng Việt"),

    "th": ("🇹🇭", "ไทย"),

    "ja": ("🇯🇵", "日本語"),

    "ko": ("🇰🇷", "한국어"),

    "zh": ("🇨🇳", "中文")
}


_cache = {}


def load_language(
    language
):

    if language in _cache:

        return _cache[
            language
        ]

    path = (
        LOCALES_DIR /
        f"{language}.json"
    )

    data = {}

    try:

        if path.exists():

            import json

            with path.open(
                "r",
                encoding="utf-8"
            ) as file:

                data = json.load(
                    file
                )

    except Exception as e:

        print(
            f"[I18N] Cannot load "
            f"{language}: {e}",
            flush=True
        )

    _cache[
        language
    ] = data

    return data


def get_nested(
    data,
    key
):

    current = data

    for part in key.split("."):

        if not isinstance(
            current,
            dict
        ):

            return None

        current = current.get(
            part
        )

    return current


def tr(
    language,
    key,
    **kwargs
):

    data = load_language(
        language
    )

    value = get_nested(
        data,
        key
    )

    if value is None:

        english = load_language(
            DEFAULT_LANGUAGE
        )

        value = get_nested(
            english,
            key
        )

    if value is None:

        return key

    value = str(
        value
    )

    try:

        return value.format(
            **kwargs
        )

    except Exception:

        return value


def current_language():

    language = get_owner_language()

    if language not in LANGUAGES:

        return DEFAULT_LANGUAGE

    return language