
import html

from aiogram import (
    Dispatcher,
    F
)

from aiogram.filters import (
    Command,
    CommandStart
)

from aiogram.types import (
    Message,
    CallbackQuery,
    InlineKeyboardMarkup,
    InlineKeyboardButton
)

from database import (
    is_owner,
    get_owner_timezone,
    set_owner_timezone
)

from keyboards import (
    main_keyboard,
    ip_keyboard,
    settings_keyboard,
    confirm_keyboard
)

from registration import (
    handle_start
)

from security import (
    build_status_text,
    build_blocked_text,
    build_events_text
)

from fileguard import (
    status as fileguard_status
)

from ip_manager import (
    validate_ip,
    ufw_is_blocked,
    ufw_block_ip,
    ufw_unblock_ip,
    get_server_ips
)


# ============================================================
# LANGUAGE
# ============================================================

LANGUAGE = "en"


# ============================================================
# USER ACTIONS
# ============================================================

USER_ACTIONS = {}


# ============================================================
# FILEGUARD
# ============================================================

def build_fileguard_text():

    data = fileguard_status()

    if data["active"]:

        state = "ACTIVE"

    elif data["installed"]:

        state = "STOPPED"

    else:

        state = "NOT INSTALLED"

    return (

        "🛡️ <b>FileGuard</b>\n\n"

        f"<b>Status:</b> {state}\n\n"

        f"<b>Events:</b> {data['events']}\n"

        f"<b>Critical:</b> {data['critical']}\n"

        f"<b>High:</b> {data['high']}\n"

        f"<b>Medium:</b> {data['medium']}"
    )


# ============================================================
# START
# ============================================================

async def cmd_start(
    message: Message
):

    await handle_start(
        message
    )


# ============================================================
# STATUS
# ============================================================

async def cmd_status(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        return

    await message.answer(

        build_status_text(
            LANGUAGE
        ),

        reply_markup=main_keyboard()
    )


# ============================================================
# BLOCKED
# ============================================================

async def cmd_blocked(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        return

    await message.answer(

        build_blocked_text(
            LANGUAGE
        ),

        reply_markup=main_keyboard()
    )


# ============================================================
# EVENTS
# ============================================================

async def cmd_events(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        return

    await message.answer(

        build_events_text(
            LANGUAGE
        ),

        reply_markup=main_keyboard()
    )


# ============================================================
# FILEGUARD
# ============================================================

async def cmd_fileguard(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        return

    await message.answer(

        build_fileguard_text(),

        reply_markup=main_keyboard()
    )


# ============================================================
# TIMEZONE
# ============================================================

async def cmd_timezone(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        return

    parts = (
        message.text or ""
    ).split(
        maxsplit=1
    )

    if len(parts) == 1:

        await message.answer(

            "🌍 <b>Timezone</b>\n\n"

            f"Current timezone: "
            f"<code>{html.escape(get_owner_timezone())}</code>\n\n"

            "Use /timezone &lt;timezone&gt; to change it.\n\n"

            "Example:\n"
            "<code>/timezone Europe/Kyiv</code>",

            reply_markup=settings_keyboard()
        )

        return

    timezone_name = parts[1].strip()

    try:

        from zoneinfo import ZoneInfo

        ZoneInfo(
            timezone_name
        )

    except Exception:

        await message.answer(
            "❌ Invalid timezone."
        )

        return

    if set_owner_timezone(
        message.chat.id,
        timezone_name
    ):

        await message.answer(

            "✅ Timezone changed to "
            f"<code>{html.escape(timezone_name)}</code>.",

            reply_markup=settings_keyboard()
        )

    else:

        await message.answer(
            "❌ Failed to change timezone."
        )


# ============================================================
# IP
# ============================================================

async def cmd_ip(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        return

    parts = (
        message.text or ""
    ).split()

    if len(parts) != 2:

        await message.answer(
            "🌐 Usage: <code>/ip 1.2.3.4</code>"
        )

        return

    ip = validate_ip(
        parts[1]
    )

    if not ip:

        await message.answer(
            "❌ Invalid IP address."
        )

        return

    state = (

        "BLOCKED"

        if ufw_is_blocked(ip)

        else

        "NOT BLOCKED"
    )

    await message.answer(

        "🌐 <b>IP Status</b>\n\n"

        f"<b>IP:</b> "
        f"<code>{html.escape(ip)}</code>\n"

        f"<b>Status:</b> {state}",

        reply_markup=ip_keyboard()
    )


# ============================================================
# MENU CALLBACK
# ============================================================

async def callback_menu(
    callback: CallbackQuery
):

    if not is_owner(
        callback.message.chat.id
    ):

        await callback.answer(
            "Access denied.",
            show_alert=True
        )

        return

    action = callback.data.split(
        ":",
        1
    )[1]

    if action == "home":

        await callback.message.edit_text(

            "🛡️ <b>ServerGuard</b>\n\n"
            "Select an option:",

            reply_markup=main_keyboard()
        )

    elif action == "status":

        await callback.message.edit_text(

            build_status_text(
                LANGUAGE
            ),

            reply_markup=main_keyboard()
        )

    elif action == "blocked":

        await callback.message.edit_text(

            build_blocked_text(
                LANGUAGE
            ),

            reply_markup=main_keyboard()
        )

    elif action == "events":

        await callback.message.edit_text(

            build_events_text(
                LANGUAGE
            ),

            reply_markup=main_keyboard()
        )

    elif action == "fileguard":

        await callback.message.edit_text(

            build_fileguard_text(),

            reply_markup=main_keyboard()
        )

    elif action == "ip":

        await callback.message.edit_text(

            "🌐 <b>IP Management</b>\n\n"
            "Choose an action:",

            reply_markup=ip_keyboard()
        )

    elif action == "settings":

        await callback.message.edit_text(

            "⚙️ <b>Settings</b>\n\n"
            "Choose a setting:",

            reply_markup=settings_keyboard()
        )

    await callback.answer()


# ============================================================
# SETTINGS CALLBACK
# ============================================================

async def callback_settings(
    callback: CallbackQuery
):

    if not is_owner(
        callback.message.chat.id
    ):

        await callback.answer(
            "Access denied.",
            show_alert=True
        )

        return

    action = callback.data.split(
        ":",
        1
    )[1]

    if action == "timezone":

        await callback.message.edit_text(

            "🌍 <b>Timezone</b>\n\n"

            f"Current timezone: "
            f"<code>{html.escape(get_owner_timezone())}</code>\n\n"

            "Use /timezone &lt;timezone&gt; to change it.\n\n"

            "Example:\n"
            "<code>/timezone Europe/Kyiv</code>",

            reply_markup=settings_keyboard()
        )

    elif action == "notifications":

        await callback.message.edit_text(

            "🔔 <b>Notifications</b>\n\n"

            "Notification settings are managed by "
            "ServerGuard.",

            reply_markup=settings_keyboard()
        )

    await callback.answer()


# ============================================================
# IP MENU
# ============================================================

async def callback_ip(
    callback: CallbackQuery
):

    if not is_owner(
        callback.message.chat.id
    ):

        await callback.answer(
            "Access denied.",
            show_alert=True
        )

        return

    action = callback.data.split(
        ":",
        1
    )[1]

    chat_id = callback.message.chat.id

    if action == "block":

        USER_ACTIONS[
            chat_id
        ] = "block"

        await callback.message.edit_text(

            "🚫 <b>Block IP</b>\n\n"
            "Send the IP address you want to block.",

            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text="❌ Cancel",
                            callback_data="menu:ip"
                        )
                    ]
                ]
            )
        )

    elif action == "unblock":

        USER_ACTIONS[
            chat_id
        ] = "unblock"

        await callback.message.edit_text(

            "✅ <b>Unblock IP</b>\n\n"
            "Send the IP address you want to unblock.",

            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text="❌ Cancel",
                            callback_data="menu:ip"
                        )
                    ]
                ]
            )
        )

    elif action == "check":

        USER_ACTIONS[
            chat_id
        ] = "check"

        await callback.message.edit_text(

            "🔍 <b>Check IP</b>\n\n"
            "Send the IP address you want to check.",

            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text="❌ Cancel",
                            callback_data="menu:ip"
                        )
                    ]
                ]
            )
        )

    elif action == "list":

        await callback.message.edit_text(

            build_blocked_text(
                LANGUAGE
            ),

            reply_markup=ip_keyboard()
        )

    await callback.answer()


# ============================================================
# CONFIRM
# ============================================================

async def callback_confirm(
    callback: CallbackQuery
):

    if not is_owner(
        callback.message.chat.id
    ):

        await callback.answer(
            "Access denied.",
            show_alert=True
        )

        return

    chat_id = callback.message.chat.id

    data = USER_ACTIONS.get(
        chat_id
    )

    if not data:

        await callback.answer(
            "Action expired.",
            show_alert=True
        )

        return

    try:

        action, ip = data.split(
            ":",
            1
        )

    except ValueError:

        USER_ACTIONS.pop(
            chat_id,
            None
        )

        await callback.answer(
            "Invalid action.",
            show_alert=True
        )

        return

    USER_ACTIONS.pop(
        chat_id,
        None
    )

    if action == "block":

        if ip in get_server_ips():

            await callback.message.edit_text(

                f"⚠️ IP <code>{html.escape(ip)}</code> "
                "is one of the server IP addresses and "
                "cannot be blocked.",

                reply_markup=ip_keyboard()
            )

            await callback.answer()

            return

        success = ufw_block_ip(
            ip
        )

        if success:

            text = (
                f"✅ IP <code>{html.escape(ip)}</code> "
                "has been blocked."
            )

        else:

            text = (
                f"❌ Failed to block IP "
                f"<code>{html.escape(ip)}</code>."
            )

        await callback.message.edit_text(

            text,

            reply_markup=ip_keyboard()
        )

    elif action == "unblock":

        success = ufw_unblock_ip(
            ip
        )

        if success:

            text = (
                f"✅ IP <code>{html.escape(ip)}</code> "
                "has been unblocked."
            )

        else:

            text = (
                f"❌ Failed to unblock IP "
                f"<code>{html.escape(ip)}</code>."
            )

        await callback.message.edit_text(

            text,

            reply_markup=ip_keyboard()
        )

    await callback.answer()


# ============================================================
# TEXT ACTIONS
# ============================================================

async def handle_text(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        await message.answer(
            "⛔ Access denied."
        )

        return

    chat_id = message.chat.id

    action = USER_ACTIONS.get(
        chat_id
    )

    if not action:

        await message.answer(

            "🛡️ <b>ServerGuard</b>\n\n"
            "Please use the menu.",

            reply_markup=main_keyboard()
        )

        return

    text_value = (
        message.text or ""
    ).strip()

    # ========================================================
    # NORMAL IP ACTIONS
    # ========================================================

    ip = validate_ip(
        text_value
    )

    if not ip:

        await message.answer(
            "❌ Invalid IP address."
        )

        return

    USER_ACTIONS.pop(
        chat_id,
        None
    )

    # ========================================================
    # CHECK
    # ========================================================

    if action == "check":

        state = (

            "BLOCKED"

            if ufw_is_blocked(ip)

            else

            "NOT BLOCKED"
        )

        await message.answer(

            "🌐 <b>IP Status</b>\n\n"

            f"<b>IP:</b> "
            f"<code>{html.escape(ip)}</code>\n"

            f"<b>Status:</b> {state}",

            reply_markup=ip_keyboard()
        )

        return

    # ========================================================
    # BLOCK
    # ========================================================

    if action == "block":

        if ip in get_server_ips():

            await message.answer(

                f"⚠️ IP <code>{html.escape(ip)}</code> "
                "is one of the server IP addresses and "
                "cannot be blocked.",

                reply_markup=ip_keyboard()
            )

            return

        if ufw_is_blocked(
            ip
        ):

            await message.answer(

                f"ℹ️ IP <code>{html.escape(ip)}</code> "
                "is already blocked.",

                reply_markup=ip_keyboard()
            )

            return

        USER_ACTIONS[
            chat_id
        ] = f"block:{ip}"

        await message.answer(

            f"⚠️ Are you sure you want to block "
            f"<code>{html.escape(ip)}</code>?",

            reply_markup=confirm_keyboard(
                action="block"
            )
        )

        return

    # ========================================================
    # UNBLOCK
    # ========================================================

    if action == "unblock":

        USER_ACTIONS[
            chat_id
        ] = f"unblock:{ip}"

        await message.answer(

            f"⚠️ Are you sure you want to unblock "
            f"<code>{html.escape(ip)}</code>?",

            reply_markup=confirm_keyboard(
                action="unblock"
            )
        )

        return


# ============================================================
# REGISTER
# ============================================================

def register_handlers(
    dp: Dispatcher
):

    # ========================================================
    # COMMANDS
    # ========================================================

    dp.message.register(
        cmd_start,
        CommandStart()
    )

    dp.message.register(
        cmd_status,
        Command("status")
    )

    dp.message.register(
        cmd_blocked,
        Command("blocked")
    )

    dp.message.register(
        cmd_events,
        Command("events")
    )

    dp.message.register(
        cmd_fileguard,
        Command("fileguard")
    )

    dp.message.register(
        cmd_timezone,
        Command("timezone")
    )

    dp.message.register(
        cmd_ip,
        Command("ip")
    )

    # ========================================================
    # SETTINGS
    # ========================================================

    dp.callback_query.register(
        callback_settings,
        F.data.startswith(
            "settings:"
        )
    )

    # ========================================================
    # IP
    # ========================================================

    dp.callback_query.register(
        callback_ip,
        F.data.startswith(
            "ip:"
        )
    )

    # ========================================================
    # CONFIRM
    # ========================================================

    dp.callback_query.register(
        callback_confirm,
        F.data.startswith(
            "confirm:"
        )
    )

    # ========================================================
    # MENU
    # ========================================================

    dp.callback_query.register(
        callback_menu,
        F.data.startswith(
            "menu:"
        )
    )

    # ========================================================
    # TEXT
    # ========================================================

    dp.message.register(
        handle_text
    )
