import html

from aiogram import (
    Dispatcher,
    F
)

from aiogram.filters import (
    Command,
    CommandStart
)

from aiogram.types import (
    Message,
    CallbackQuery,
    InlineKeyboardMarkup,
    InlineKeyboardButton
)

from database import (
    is_owner,
    get_owner,
    get_owner_language,
    get_owner_timezone,
    set_owner_language,
    set_owner_timezone
)

from i18n import (
    LANGUAGES,
    tr
)

from keyboards import (
    main_keyboard,
    ip_keyboard,
    settings_keyboard,
    confirm_keyboard,
    language_keyboard,
    protection_keyboard,
    protection_attempts_keyboard,
    protection_duration_keyboard,
    protection_permanent_keyboard,
    protection_whitelist_keyboard
)

from registration import (
    handle_start
)

from security import (
    build_status_text,
    build_blocked_text,
    build_events_text
)

from fileguard import (
    status as fileguard_status
)

from ip_manager import (
    validate_ip,
    ufw_is_blocked,
    ufw_block_ip,
    ufw_unblock_ip,
    get_server_ips
)

from pathlib import Path

import json


# ============================================================
# PROTECTION CONFIG
# ============================================================

PROTECTION_CONFIG_FILE = Path(
    "/opt/serverguard/data/protection_config.json"
)


DEFAULT_PROTECTION_CONFIG = {

    "enabled": True,

    "attempts": 5,

    "duration": 600,

    "permanent": False,

    "mode": "ip",

    "whitelist": []
}


# ============================================================
# USER ACTIONS
# ============================================================

USER_ACTIONS = {}


# ============================================================
# PROTECTION CONFIG HELPERS
# ============================================================

def load_protection_config():

    try:

        if not PROTECTION_CONFIG_FILE.exists():

            PROTECTION_CONFIG_FILE.parent.mkdir(
                parents=True,
                exist_ok=True
            )

            save_protection_config(
                DEFAULT_PROTECTION_CONFIG
            )

            return dict(
                DEFAULT_PROTECTION_CONFIG
            )

        with PROTECTION_CONFIG_FILE.open(
            "r",
            encoding="utf-8"
        ) as file:

            config = json.load(
                file
            )

        if not isinstance(
            config,
            dict
        ):

            config = dict(
                DEFAULT_PROTECTION_CONFIG
            )

        result = dict(
            DEFAULT_PROTECTION_CONFIG
        )

        result.update(
            config
        )

        # ----------------------------------------------------
        # ATTEMPTS
        # ----------------------------------------------------

        try:

            result["attempts"] = int(
                result.get(
                    "attempts",
                    5
                )
            )

        except Exception:

            result["attempts"] = 5

        result["attempts"] = max(
            1,
            min(
                result["attempts"],
                100
            )
        )

        # ----------------------------------------------------
        # DURATION
        # ----------------------------------------------------

        try:

            result["duration"] = int(
                result.get(
                    "duration",
                    600
                )
            )

        except Exception:

            result["duration"] = 600

        result["duration"] = max(
            60,
            min(
                result["duration"],
                30 * 24 * 60 * 60
            )
        )

        # ----------------------------------------------------
        # ENABLED
        # ----------------------------------------------------

        result["enabled"] = bool(
            result.get(
                "enabled",
                True
            )
        )

        # ----------------------------------------------------
        # PERMANENT
        # ----------------------------------------------------

        result["permanent"] = bool(
            result.get(
                "permanent",
                False
            )
        )

        # ----------------------------------------------------
        # MODE
        # ----------------------------------------------------

        result["mode"] = "ip"

        # ----------------------------------------------------
        # WHITELIST
        # ----------------------------------------------------

        whitelist = result.get(
            "whitelist",
            []
        )

        if not isinstance(
            whitelist,
            list
        ):

            whitelist = []

        result["whitelist"] = [
            str(ip).strip()
            for ip in whitelist
            if str(ip).strip()
        ]

        return result

    except Exception as e:

        print(
            f"[TELEGRAM] Protection config "
            f"load error: {e}",
            flush=True
        )

        return dict(
            DEFAULT_PROTECTION_CONFIG
        )


def save_protection_config(
    config
):

    temp = PROTECTION_CONFIG_FILE.with_suffix(
        ".tmp"
    )

    try:

        PROTECTION_CONFIG_FILE.parent.mkdir(
            parents=True,
            exist_ok=True
        )

        with temp.open(
            "w",
            encoding="utf-8"
        ) as file:

            json.dump(
                config,
                file,
                indent=2,
                ensure_ascii=False
            )

            file.write(
                "\n"
            )

        temp.replace(
            PROTECTION_CONFIG_FILE
        )

        return True

    except Exception as e:

        print(
            f"[TELEGRAM] Protection config "
            f"save error: {e}",
            flush=True
        )

        try:

            if temp.exists():

                temp.unlink()

        except Exception:

            pass

        return False


# ============================================================
# FORMAT DURATION
# ============================================================

def format_duration(
    seconds
):

    try:

        seconds = int(
            seconds
        )

    except Exception:

        return "unknown"

    if seconds <= 0:

        return "0"

    if seconds % 86400 == 0:

        days = seconds // 86400

        return (
            f"{days} day"
            f"{'s' if days != 1 else ''}"
        )

    if seconds % 3600 == 0:

        hours = seconds // 3600

        return (
            f"{hours} hour"
            f"{'s' if hours != 1 else ''}"
        )

    minutes = seconds // 60

    return (
        f"{minutes} minute"
        f"{'s' if minutes != 1 else ''}"
    )


# ============================================================
# PROTECTION TEXT
# ============================================================

def build_protection_text():

    config = load_protection_config()

    enabled = (
        "🟢 ENABLED"
        if config["enabled"]
        else
        "🔴 DISABLED"
    )

    permanent = (
        "♾️ YES"
        if config["permanent"]
        else
        "⏱️ NO"
    )

    whitelist = config.get(
        "whitelist",
        []
    )

    return (

        "🛡️ <b>SSH Protection Settings</b>\n\n"

        f"<b>Status:</b> {enabled}\n"

        f"<b>Mode:</b> IP blocking\n"

        f"<b>Failed attempts:</b> "
        f"{config['attempts']}\n"

        f"<b>Block duration:</b> "
        f"{format_duration(config['duration'])}\n"

        f"<b>Permanent block:</b> "
        f"{permanent}\n"

        f"<b>Whitelist:</b> "
        f"{len(whitelist)} IP(s)\n\n"

        "The counter uses consecutive failed SSH "
        "attempts. A successful login resets the counter."
    )


# ============================================================
# FILEGUARD
# ============================================================

def build_fileguard_text(
    language
):

    data = fileguard_status()

    if data["active"]:

        state = tr(
            language,
            "status.active"
        )

    elif data["installed"]:

        state = tr(
            language,
            "status.stopped"
        )

    else:

        state = tr(
            language,
            "status.not_installed"
        )

    return (

        tr(
            language,
            "fileguard.title"
        )

        + "\n\n"

        + tr(
            language,
            "fileguard.state",
            value=state
        )

        + "\n\n"

        + tr(
            language,
            "fileguard.events",
            value=data["events"]
        )

        + "\n"

        + tr(
            language,
            "status.critical",
            value=data["critical"]
        )

        + "\n"

        + tr(
            language,
            "status.high",
            value=data["high"]
        )

        + "\n"

        + tr(
            language,
            "status.medium",
            value=data["medium"]
        )
    )


# ============================================================
# /START
# ============================================================

async def cmd_start(
    message: Message
):

    await handle_start(
        message
    )


# ============================================================
# /STATUS
# ============================================================

async def cmd_status(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        return

    language = get_owner_language()

    await message.answer(

        build_status_text(
            language
        ),

        reply_markup=main_keyboard(
            language
        )
    )


# ============================================================
# /BLOCKED
# ============================================================

async def cmd_blocked(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        return

    language = get_owner_language()

    await message.answer(

        build_blocked_text(
            language
        ),

        reply_markup=main_keyboard(
            language
        )
    )


# ============================================================
# /EVENTS
# ============================================================

async def cmd_events(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        return

    language = get_owner_language()

    await message.answer(

        build_events_text(
            language
        ),

        reply_markup=main_keyboard(
            language
        )
    )


# ============================================================
# /FILEGUARD
# ============================================================

async def cmd_fileguard(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        return

    language = get_owner_language()

    await message.answer(

        build_fileguard_text(
            language
        ),

        reply_markup=main_keyboard(
            language
        )
    )


# ============================================================
# /LANGUAGE
# ============================================================

async def cmd_language(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        return

    language = get_owner_language()

    await message.answer(

        tr(
            language,
            "language.select"
        ),

        reply_markup=language_keyboard()
    )


# ============================================================
# /TIMEZONE
# ============================================================

async def cmd_timezone(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        return

    language = get_owner_language()

    parts = (
        message.text or ""
    ).split(
        maxsplit=1
    )

    if len(parts) == 1:

        await message.answer(

            tr(
                language,
                "timezone.current",
                value=html.escape(
                    get_owner_timezone()
                )
            ),

            reply_markup=settings_keyboard(
                language
            )
        )

        return

    timezone_name = parts[1].strip()

    try:

        from zoneinfo import ZoneInfo

        ZoneInfo(
            timezone_name
        )

    except Exception:

        await message.answer(
            tr(
                language,
                "timezone.invalid"
            )
        )

        return

    if set_owner_timezone(
        message.chat.id,
        timezone_name
    ):

        await message.answer(

            tr(
                language,
                "timezone.changed",
                value=html.escape(
                    timezone_name
                )
            ),

            reply_markup=settings_keyboard(
                language
            )
        )


# ============================================================
# /PROTECTION
# ============================================================

async def cmd_protection(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        return

    await message.answer(

        build_protection_text(),

        reply_markup=protection_keyboard()
    )


# ============================================================
# /IP
# ============================================================

async def cmd_ip(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        return

    language = get_owner_language()

    parts = (
        message.text or ""
    ).split()

    if len(parts) != 2:

        await message.answer(
            tr(
                language,
                "ip.send_ip"
            )
        )

        return

    ip = validate_ip(
        parts[1]
    )

    if not ip:

        await message.answer(
            tr(
                language,
                "ip.invalid"
            )
        )

        return

    if ufw_is_blocked(
        ip
    ):

        state = tr(
            language,
            "ip.current_blocked"
        )

    else:

        state = tr(
            language,
            "ip.current_unblocked"
        )

    await message.answer(

        tr(
            language,
            "ip.check_result",
            ip=html.escape(ip),
            status=state
        ),

        reply_markup=ip_keyboard(
            language
        )
    )


# ============================================================
# MENU CALLBACK
# ============================================================

async def callback_menu(
    callback: CallbackQuery
):

    if not is_owner(
        callback.message.chat.id
    ):

        await callback.answer(
            "Access denied.",
            show_alert=True
        )

        return

    language = get_owner_language()

    action = callback.data.split(
        ":",
        1
    )[1]

    if action == "home":

        await callback.message.edit_text(

            tr(
                language,
                "home.title"
            ),

            reply_markup=main_keyboard(
                language
            )
        )

    elif action == "status":

        await callback.message.edit_text(

            build_status_text(
                language
            ),

            reply_markup=main_keyboard(
                language
            )
        )

    elif action == "blocked":

        await callback.message.edit_text(

            build_blocked_text(
                language
            ),

            reply_markup=main_keyboard(
                language
            )
        )

    elif action == "events":

        await callback.message.edit_text(

            build_events_text(
                language
            ),

            reply_markup=main_keyboard(
                language
            )
        )

    elif action == "fileguard":

        await callback.message.edit_text(

            build_fileguard_text(
                language
            ),

            reply_markup=main_keyboard(
                language
            )
        )

    elif action == "ip":

        await callback.message.edit_text(

            tr(
                language,
                "ip.title"
            ),

            reply_markup=ip_keyboard(
                language
            )
        )

    elif action == "settings":

        await callback.message.edit_text(

            tr(
                language,
                "settings.title"
            ),

            reply_markup=settings_keyboard(
                language
            )
        )

    await callback.answer()


# ============================================================
# LANGUAGE CALLBACK
# ============================================================

async def callback_language(
    callback: CallbackQuery
):

    if not is_owner(
        callback.message.chat.id
    ):

        await callback.answer(
            "Access denied.",
            show_alert=True
        )

        return

    language = callback.data.split(
        ":",
        1
    )[1]

    if language not in LANGUAGES:

        await callback.answer(
            "Invalid language.",
            show_alert=True
        )

        return

    if not set_owner_language(
        callback.message.chat.id,
        language
    ):

        await callback.answer(
            "Language error.",
            show_alert=True
        )

        return

    await callback.message.edit_text(

        tr(
            language,
            "language.changed"
        ),

        reply_markup=main_keyboard(
            language
        )
    )

    await callback.answer()


# ============================================================
# LANGUAGE PAGE
# ============================================================

async def callback_language_page(
    callback: CallbackQuery
):

    if not is_owner(
        callback.message.chat.id
    ):

        await callback.answer(
            "Access denied.",
            show_alert=True
        )

        return

    page = int(
        callback.data.split(
            ":",
            1
        )[1]
    )

    await callback.message.edit_reply_markup(

        reply_markup=language_keyboard(
            page
        )
    )

    await callback.answer()


# ============================================================
# SETTINGS
# ============================================================

async def callback_settings(
    callback: CallbackQuery
):

    if not is_owner(
        callback.message.chat.id
    ):

        await callback.answer(
            "Access denied.",
            show_alert=True
        )

        return

    language = get_owner_language()

    action = callback.data.split(
        ":",
        1
    )[1]

    if action == "language":

        await callback.message.edit_text(

            tr(
                language,
                "language.select"
            ),

            reply_markup=language_keyboard()
        )

    elif action == "timezone":

        await callback.message.edit_text(

            tr(
                language,
                "timezone.current",
                value=html.escape(
                    get_owner_timezone()
                )
            ),

            reply_markup=settings_keyboard(
                language
            )
        )

    elif action == "notifications":

        await callback.message.edit_text(

            tr(
                language,
                "settings.notifications_text"
            ),

            reply_markup=settings_keyboard(
                language
            )
        )

    elif action == "protection":

        await callback.message.edit_text(

            build_protection_text(),

            reply_markup=protection_keyboard()
        )

    await callback.answer()


# ============================================================
# PROTECTION CALLBACK
# ============================================================

async def callback_protection(
    callback: CallbackQuery
):

    if not is_owner(
        callback.message.chat.id
    ):

        await callback.answer(
            "Access denied.",
            show_alert=True
        )

        return

    action = callback.data.split(
        ":",
        1
    )[1]

    config = load_protection_config()

    if action == "show":

        await callback.message.edit_text(

            build_protection_text(),

            reply_markup=protection_keyboard()
        )

    elif action == "toggle":

        config["enabled"] = not config[
            "enabled"
        ]

        if save_protection_config(
            config
        ):

            await callback.message.edit_text(

                build_protection_text(),

                reply_markup=protection_keyboard()
            )

        else:

            await callback.answer(
                "Failed to save settings.",
                show_alert=True
            )

    elif action == "attempts":

        await callback.message.edit_text(

            "🔢 <b>Failed attempts before block</b>\n\n"
            "Choose how many consecutive failed SSH "
            "login attempts are required before the IP "
            "is blocked.",

            reply_markup=protection_attempts_keyboard()
        )

    elif action == "duration":

        await callback.message.edit_text(

            "⏱ <b>Block duration</b>\n\n"
            "Choose how long the IP should remain blocked.",

            reply_markup=protection_duration_keyboard()
        )

    elif action == "permanent":

        await callback.message.edit_text(

            "♾️ <b>Permanent blocking</b>\n\n"
            "If enabled, every triggered block will remain "
            "until you manually unblock the IP.",

            reply_markup=protection_permanent_keyboard()
        )

    elif action == "whitelist":

        await callback.message.edit_text(

            "🌐 <b>Whitelist</b>\n\n"
            "Whitelisted IP addresses will never be "
            "automatically blocked.",

            reply_markup=protection_whitelist_keyboard()
        )

    await callback.answer()


# ============================================================
# ATTEMPTS CALLBACK
# ============================================================

async def callback_protection_attempts(
    callback: CallbackQuery
):

    if not is_owner(
        callback.message.chat.id
    ):

        await callback.answer(
            "Access denied.",
            show_alert=True
        )

        return

    value = callback.data.split(
        ":",
        1
    )[1]

    if value == "custom":

        USER_ACTIONS[
            callback.message.chat.id
        ] = "protection_custom_attempts"

        await callback.message.edit_text(

            "✏️ <b>Custom attempts</b>\n\n"
            "Send a number from <b>1</b> to <b>100</b>.\n\n"
            "Example: <code>7</code>",

            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text="❌ Cancel",
                            callback_data="protection:show"
                        )
                    ]
                ]
            )
        )

        await callback.answer()

        return

    try:

        attempts = int(
            value
        )

    except Exception:

        await callback.answer(
            "Invalid value.",
            show_alert=True
        )

        return

    if attempts < 1 or attempts > 100:

        await callback.answer(
            "Allowed range: 1-100.",
            show_alert=True
        )

        return

    config = load_protection_config()

    config["attempts"] = attempts

    if save_protection_config(
        config
    ):

        await callback.message.edit_text(

            build_protection_text(),

            reply_markup=protection_keyboard()
        )

        await callback.answer(
            f"Threshold changed to {attempts}.",
            show_alert=False
        )

    else:

        await callback.answer(
            "Failed to save settings.",
            show_alert=True
        )


# ============================================================
# DURATION CALLBACK
# ============================================================

async def callback_protection_duration(
    callback: CallbackQuery
):

    if not is_owner(
        callback.message.chat.id
    ):

        await callback.answer(
            "Access denied.",
            show_alert=True
        )

        return

    value = callback.data.split(
        ":",
        1
    )[1]

    if value == "custom":

        USER_ACTIONS[
            callback.message.chat.id
        ] = "protection_custom_duration"

        await callback.message.edit_text(

            "✏️ <b>Custom duration</b>\n\n"
            "Send the duration in minutes.\n\n"
            "Allowed: <b>1-43200 minutes</b>.\n\n"
            "Example:\n"
            "<code>15</code> = 15 minutes\n"
            "<code>120</code> = 2 hours\n"
            "<code>1440</code> = 1 day",

            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text="❌ Cancel",
                            callback_data="protection:show"
                        )
                    ]
                ]
            )
        )

        await callback.answer()

        return

    try:

        duration = int(
            value
        )

    except Exception:

        await callback.answer(
            "Invalid value.",
            show_alert=True
        )

        return

    if duration < 60 or duration > 30 * 24 * 60 * 60:

        await callback.answer(
            "Invalid duration.",
            show_alert=True
        )

        return

    config = load_protection_config()

    config["duration"] = duration

    if save_protection_config(
        config
    ):

        await callback.message.edit_text(

            build_protection_text(),

            reply_markup=protection_keyboard()
        )

        await callback.answer(
            "Duration changed.",
            show_alert=False
        )

    else:

        await callback.answer(
            "Failed to save settings.",
            show_alert=True
        )


# ============================================================
# PERMANENT CALLBACK
# ============================================================

async def callback_protection_permanent(
    callback: CallbackQuery
):

    if not is_owner(
        callback.message.chat.id
    ):

        await callback.answer(
            "Access denied.",
            show_alert=True
        )

        return

    value = callback.data.split(
        ":",
        1
    )[1]

    config = load_protection_config()

    if value == "on":

        config["permanent"] = True

    elif value == "off":

        config["permanent"] = False

    else:

        await callback.answer(
            "Invalid value.",
            show_alert=True
        )

        return

    if save_protection_config(
        config
    ):

        await callback.message.edit_text(

            build_protection_text(),

            reply_markup=protection_keyboard()
        )

        await callback.answer()

    else:

        await callback.answer(
            "Failed to save settings.",
            show_alert=True
        )


# ============================================================
# WHITELIST CALLBACK
# ============================================================

async def callback_protection_whitelist(
    callback: CallbackQuery
):

    if not is_owner(
        callback.message.chat.id
    ):

        await callback.answer(
            "Access denied.",
            show_alert=True
        )

        return

    action = callback.data.split(
        ":",
        1
    )[1]

    if action == "add":

        USER_ACTIONS[
            callback.message.chat.id
        ] = "protection_whitelist_add"

        await callback.message.edit_text(

            "➕ <b>Add IP to whitelist</b>\n\n"
            "Send the IP address that should never "
            "be automatically blocked.",

            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text="❌ Cancel",
                            callback_data="protection:whitelist"
                        )
                    ]
                ]
            )
        )

    elif action == "remove":

        USER_ACTIONS[
            callback.message.chat.id
        ] = "protection_whitelist_remove"

        await callback.message.edit_text(

            "➖ <b>Remove IP from whitelist</b>\n\n"
            "Send the IP address to remove.",

            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text="❌ Cancel",
                            callback_data="protection:whitelist"
                        )
                    ]
                ]
            )
        )

    elif action == "list":

        config = load_protection_config()

        whitelist = config.get(
            "whitelist",
            []
        )

        if whitelist:

            lines = [
                "🌐 <b>Whitelist</b>",
                ""
            ]

            for ip in whitelist:

                lines.append(
                    f"• <code>{html.escape(ip)}</code>"
                )

            text = "\n".join(
                lines
            )

        else:

            text = (
                "🌐 <b>Whitelist</b>\n\n"
                "No IP addresses are whitelisted."
            )

        await callback.message.edit_text(

            text,

            reply_markup=protection_whitelist_keyboard()
        )

    await callback.answer()


# ============================================================
# IP MENU
# ============================================================

async def callback_ip(
    callback: CallbackQuery
):

    if not is_owner(
        callback.message.chat.id
    ):

        await callback.answer(
            "Access denied.",
            show_alert=True
        )

        return

    language = get_owner_language()

    action = callback.data.split(
        ":",
        1
    )[1]

    chat_id = callback.message.chat.id

    if action == "block":

        USER_ACTIONS[
            chat_id
        ] = "block"

        await callback.message.edit_text(

            tr(
                language,
                "ip.enter_block"
            ),

            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text=tr(
                                language,
                                "common.cancel"
                            ),
                            callback_data="menu:ip"
                        )
                    ]
                ]
            )
        )

    elif action == "unblock":

        USER_ACTIONS[
            chat_id
        ] = "unblock"

        await callback.message.edit_text(

            tr(
                language,
                "ip.enter_unblock"
            ),

            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text=tr(
                                language,
                                "common.cancel"
                            ),
                            callback_data="menu:ip"
                        )
                    ]
                ]
            )
        )

    elif action == "check":

        USER_ACTIONS[
            chat_id
        ] = "check"

        await callback.message.edit_text(

            tr(
                language,
                "ip.enter_check"
            ),

            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text=tr(
                                language,
                                "common.cancel"
                            ),
                            callback_data="menu:ip"
                        )
                    ]
                ]
            )
        )

    elif action == "list":

        await callback.message.edit_text(

            build_blocked_text(
                language
            ),

            reply_markup=ip_keyboard(
                language
            )
        )

    await callback.answer()


# ============================================================
# CONFIRM
# ============================================================

async def callback_confirm(
    callback: CallbackQuery
):

    if not is_owner(
        callback.message.chat.id
    ):

        await callback.answer(
            "Access denied.",
            show_alert=True
        )

        return

    chat_id = callback.message.chat.id

    language = get_owner_language()

    data = USER_ACTIONS.get(
        chat_id
    )

    if not data:

        await callback.answer(
            "Action expired.",
            show_alert=True
        )

        return

    action, ip = data.split(
        ":",
        1
    )

    USER_ACTIONS.pop(
        chat_id,
        None
    )

    if action == "block":

        if ip in get_server_ips():

            await callback.message.edit_text(

                tr(
                    language,
                    "ip.server_ip_warning",
                    ip=html.escape(ip)
                ),

                reply_markup=ip_keyboard(
                    language
                )
            )

            await callback.answer()

            return

        success = ufw_block_ip(
            ip
        )

        if success:

            text = tr(
                language,
                "ip.blocked_success",
                ip=html.escape(ip)
            )

        else:

            text = tr(
                language,
                "ip.block_failed",
                ip=html.escape(ip)
            )

        await callback.message.edit_text(

            text,

            reply_markup=ip_keyboard(
                language
            )
        )

    elif action == "unblock":

        success = ufw_unblock_ip(
            ip
        )

        if success:

            text = tr(
                language,
                "ip.unblocked_success",
                ip=html.escape(ip)
            )

        else:

            text = tr(
                language,
                "ip.unblock_failed",
                ip=html.escape(ip)
            )

        await callback.message.edit_text(

            text,

            reply_markup=ip_keyboard(
                language
            )
        )

    await callback.answer()


# ============================================================
# TEXT ACTIONS
# ============================================================

async def handle_text(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        await message.answer(
            "⛔ Access denied."
        )

        return

    chat_id = message.chat.id

    action = USER_ACTIONS.get(
        chat_id
    )

    if not action:

        language = get_owner_language()

        await message.answer(

            tr(
                language,
                "common.use_menu"
            ),

            reply_markup=main_keyboard(
                language
            )
        )

        return

    language = get_owner_language()

    text_value = (
        message.text or ""
    ).strip()

    # ========================================================
    # CUSTOM ATTEMPTS
    # ========================================================

    if action == "protection_custom_attempts":

        try:

            attempts = int(
                text_value
            )

        except Exception:

            await message.answer(
                "❌ Enter a number from 1 to 100."
            )

            return

        if attempts < 1 or attempts > 100:

            await message.answer(
                "❌ Allowed range: 1-100."
            )

            return

        config = load_protection_config()

        config["attempts"] = attempts

        USER_ACTIONS.pop(
            chat_id,
            None
        )

        if save_protection_config(
            config
        ):

            await message.answer(

                build_protection_text(),

                reply_markup=protection_keyboard()
            )

        else:

            await message.answer(
                "❌ Failed to save settings."
            )

        return

    # ========================================================
    # CUSTOM DURATION
    # ========================================================

    if action == "protection_custom_duration":

        try:

            minutes = int(
                text_value
            )

        except Exception:

            await message.answer(
                "❌ Enter the duration in minutes."
            )

            return

        if minutes < 1 or minutes > 43200:

            await message.answer(
                "❌ Allowed range: 1-43200 minutes."
            )

            return

        config = load_protection_config()

        config["duration"] = (
            minutes * 60
        )

        USER_ACTIONS.pop(
            chat_id,
            None
        )

        if save_protection_config(
            config
        ):

            await message.answer(

                build_protection_text(),

                reply_markup=protection_keyboard()
            )

        else:

            await message.answer(
                "❌ Failed to save settings."
            )

        return

    # ========================================================
    # WHITELIST ADD
    # ========================================================

    if action == "protection_whitelist_add":

        ip = validate_ip(
            text_value
        )

        if not ip:

            await message.answer(
                "❌ Invalid IP address."
            )

            return

        if ip in get_server_ips():

            await message.answer(
                "⚠️ This is one of the server IPs. "
                "It does not need to be added to whitelist."
            )

            USER_ACTIONS.pop(
                chat_id,
                None
            )

            return

        config = load_protection_config()

        whitelist = config.get(
            "whitelist",
            []
        )

        if ip not in whitelist:

            whitelist.append(
                ip
            )

        config["whitelist"] = whitelist

        USER_ACTIONS.pop(
            chat_id,
            None
        )

        if save_protection_config(
            config
        ):

            await message.answer(

                f"✅ IP <code>{html.escape(ip)}</code> "
                f"added to whitelist.",

                reply_markup=protection_whitelist_keyboard()
            )

        else:

            await message.answer(
                "❌ Failed to save whitelist."
            )

        return

    # ========================================================
    # WHITELIST REMOVE
    # ========================================================

    if action == "protection_whitelist_remove":

        ip = validate_ip(
            text_value
        )

        if not ip:

            await message.answer(
                "❌ Invalid IP address."
            )

            return

        config = load_protection_config()

        whitelist = config.get(
            "whitelist",
            []
        )

        if ip in whitelist:

            whitelist.remove(
                ip
            )

        else:

            await message.answer(
                f"ℹ️ IP <code>{html.escape(ip)}</code> "
                f"is not in whitelist.",
                reply_markup=protection_whitelist_keyboard()
            )

            USER_ACTIONS.pop(
                chat_id,
                None
            )

            return

        config["whitelist"] = whitelist

        USER_ACTIONS.pop(
            chat_id,
            None
        )

        if save_protection_config(
            config
        ):

            await message.answer(

                f"✅ IP <code>{html.escape(ip)}</code> "
                f"removed from whitelist.",

                reply_markup=protection_whitelist_keyboard()
            )

        else:

            await message.answer(
                "❌ Failed to save whitelist."
            )

        return

    # ========================================================
    # NORMAL IP ACTIONS
    # ========================================================

    ip = validate_ip(
        text_value
    )

    if not ip:

        await message.answer(

            tr(
                language,
                "ip.invalid"
            )
        )

        return

    USER_ACTIONS.pop(
        chat_id,
        None
    )

    if action == "check":

        if ufw_is_blocked(
            ip
        ):

            state = tr(
                language,
                "ip.current_blocked"
            )

        else:

            state = tr(
                language,
                "ip.current_unblocked"
            )

        await message.answer(

            tr(
                language,
                "ip.check_result",
                ip=html.escape(ip),
                status=state
            ),

            reply_markup=ip_keyboard(
                language
            )
        )

        return

    if action == "block":

        if ip in get_server_ips():

            await message.answer(

                tr(
                    language,
                    "ip.server_ip_warning",
                    ip=html.escape(ip)
                ),

                reply_markup=ip_keyboard(
                    language
                )
            )

            return

        if ufw_is_blocked(
            ip
        ):

            await message.answer(

                tr(
                    language,
                    "ip.already_blocked",
                    ip=html.escape(ip)
                ),

                reply_markup=ip_keyboard(
                    language
                )
            )

            return

        USER_ACTIONS[
            chat_id
        ] = f"block:{ip}"

        await message.answer(

            tr(
                language,
                "ip.confirm_block",
                ip=html.escape(ip)
            ),

            reply_markup=confirm_keyboard(
                language,
                "block"
            )
        )

        return

    if action == "unblock":

        USER_ACTIONS[
            chat_id
        ] = f"unblock:{ip}"

        await message.answer(

            tr(
                language,
                "ip.confirm_unblock",
                ip=html.escape(ip)
            ),

            reply_markup=confirm_keyboard(
                language,
                "unblock"
            )
        )


# ============================================================
# REGISTER
# ============================================================

def register_handlers(
    dp: Dispatcher
):

    # ========================================================
    # COMMANDS
    # ========================================================

    dp.message.register(
        cmd_start,
        CommandStart()
    )

    dp.message.register(
        cmd_status,
        Command("status")
    )

    dp.message.register(
        cmd_blocked,
        Command("blocked")
    )

    dp.message.register(
        cmd_events,
        Command("events")
    )

    dp.message.register(
        cmd_fileguard,
        Command("fileguard")
    )

    dp.message.register(
        cmd_language,
        Command("language")
    )

    dp.message.register(
        cmd_timezone,
        Command("timezone")
    )

    dp.message.register(
        cmd_protection,
        Command("protection")
    )

    dp.message.register(
        cmd_ip,
        Command("ip")
    )

    # ========================================================
    # LANGUAGE
    # ========================================================

    dp.callback_query.register(
        callback_language,
        F.data.startswith(
            "lang:"
        )
    )

    dp.callback_query.register(
        callback_language_page,
        F.data.startswith(
            "langpage:"
        )
    )

    # ========================================================
    # SETTINGS
    # ========================================================

    dp.callback_query.register(
        callback_settings,
        F.data.startswith(
            "settings:"
        )
    )

    # ========================================================
    # PROTECTION
    # ========================================================

    dp.callback_query.register(
        callback_protection,
        F.data.startswith(
            "protection:"
        )
    )

    dp.callback_query.register(
        callback_protection_attempts,
        F.data.startswith(
            "protection_attempts:"
        )
    )

    dp.callback_query.register(
        callback_protection_duration,
        F.data.startswith(
            "protection_duration:"
        )
    )

    dp.callback_query.register(
        callback_protection_permanent,
        F.data.startswith(
            "protection_permanent:"
        )
    )

    dp.callback_query.register(
        callback_protection_whitelist,
        F.data.startswith(
            "protection_whitelist:"
        )
    )

    # ========================================================
    # IP
    # ========================================================

    dp.callback_query.register(
        callback_ip,
        F.data.startswith(
            "ip:"
        )
    )

    dp.callback_query.register(
        callback_confirm,
        F.data.startswith(
            "confirm:"
        )
    )

    # ========================================================
    # MENU
    # ========================================================

    dp.callback_query.register(
        callback_menu,
        F.data.startswith(
            "menu:"
        )
    )

    # ========================================================
    # TEXT
    # ========================================================

    dp.message.register(
        handle_text
    )