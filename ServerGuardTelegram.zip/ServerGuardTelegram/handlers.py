import html
import json

from pathlib import Path

from aiogram import (
    Dispatcher,
    F
)

from aiogram.filters import (
    Command,
    CommandStart
)

from aiogram.types import (
    Message,
    CallbackQuery,
    InlineKeyboardMarkup,
    InlineKeyboardButton
)

from database import (
    is_owner,
    get_owner_timezone,
    set_owner_timezone
)

from i18n import (
    DEFAULT_LANGUAGE,
    tr
)

from keyboards import (
    main_keyboard,
    ip_keyboard,
    settings_keyboard,
    confirm_keyboard,
    protection_keyboard,
    protection_attempts_keyboard,
    protection_duration_keyboard,
    protection_permanent_keyboard,
    protection_whitelist_keyboard
)

from registration import (
    handle_start
)

from security import (
    build_status_text,
    build_blocked_text,
    build_events_text
)

from fileguard import (
    status as fileguard_status
)

from ip_manager import (
    validate_ip,
    ufw_is_blocked,
    ufw_block_ip,
    ufw_unblock_ip,
    get_server_ips
)


# ============================================================
# LANGUAGE
# ============================================================

LANGUAGE = DEFAULT_LANGUAGE


# ============================================================
# PROTECTION CONFIG
# ============================================================

PROTECTION_CONFIG_FILE = Path(
    "/opt/serverguard/data/protection_config.json"
)


DEFAULT_PROTECTION_CONFIG = {
    "enabled": True,
    "attempts": 5,
    "duration": 600,
    "permanent": False,
    "mode": "ip",
    "whitelist": []
}


# ============================================================
# USER ACTIONS
# ============================================================

USER_ACTIONS = {}


# ============================================================
# PROTECTION CONFIG HELPERS
# ============================================================

def load_protection_config():

    try:

        if not PROTECTION_CONFIG_FILE.exists():

            PROTECTION_CONFIG_FILE.parent.mkdir(
                parents=True,
                exist_ok=True
            )

            save_protection_config(
                DEFAULT_PROTECTION_CONFIG
            )

            return dict(
                DEFAULT_PROTECTION_CONFIG
            )

        with PROTECTION_CONFIG_FILE.open(
            "r",
            encoding="utf-8"
        ) as file:

            config = json.load(
                file
            )

        if not isinstance(
            config,
            dict
        ):

            config = dict(
                DEFAULT_PROTECTION_CONFIG
            )

        result = dict(
            DEFAULT_PROTECTION_CONFIG
        )

        result.update(
            config
        )

        try:

            result["attempts"] = int(
                result.get(
                    "attempts",
                    5
                )
            )

        except Exception:

            result["attempts"] = 5

        result["attempts"] = max(
            1,
            min(
                result["attempts"],
                100
            )
        )

        try:

            result["duration"] = int(
                result.get(
                    "duration",
                    600
                )
            )

        except Exception:

            result["duration"] = 600

        result["duration"] = max(
            60,
            min(
                result["duration"],
                30 * 24 * 60 * 60
            )
        )

        enabled = result.get(
            "enabled",
            True
        )

        if isinstance(
            enabled,
            str
        ):

            result["enabled"] = (
                enabled.lower()
                in (
                    "1",
                    "true",
                    "yes",
                    "on",
                    "enabled"
                )
            )

        else:

            result["enabled"] = bool(
                enabled
            )

        permanent = result.get(
            "permanent",
            False
        )

        if isinstance(
            permanent,
            str
        ):

            result["permanent"] = (
                permanent.lower()
                in (
                    "1",
                    "true",
                    "yes",
                    "on",
                    "enabled"
                )
            )

        else:

            result["permanent"] = bool(
                permanent
            )

        result["mode"] = "ip"

        whitelist = result.get(
            "whitelist",
            []
        )

        if not isinstance(
            whitelist,
            list
        ):

            whitelist = []

        clean_whitelist = []

        for ip in whitelist:

            value = str(
                ip
            ).strip()

            if not value:
                continue

            if value not in clean_whitelist:

                clean_whitelist.append(
                    value
                )

        result["whitelist"] = clean_whitelist

        return result

    except Exception as e:

        print(
            f"[TELEGRAM] Protection config "
            f"load error: {e}",
            flush=True
        )

        return dict(
            DEFAULT_PROTECTION_CONFIG
        )


def save_protection_config(
    config
):

    temp = PROTECTION_CONFIG_FILE.with_suffix(
        ".tmp"
    )

    try:

        PROTECTION_CONFIG_FILE.parent.mkdir(
            parents=True,
            exist_ok=True
        )

        with temp.open(
            "w",
            encoding="utf-8"
        ) as file:

            json.dump(
                config,
                file,
                indent=2,
                ensure_ascii=False
            )

            file.write(
                "\n"
            )

        temp.replace(
            PROTECTION_CONFIG_FILE
        )

        return True

    except Exception as e:

        print(
            f"[TELEGRAM] Protection config "
            f"save error: {e}",
            flush=True
        )

        try:

            if temp.exists():

                temp.unlink()

        except Exception:

            pass

        return False


# ============================================================
# FORMAT DURATION
# ============================================================

def format_duration(
    seconds
):

    try:

        seconds = int(
            seconds
        )

    except Exception:

        return "unknown"

    if seconds <= 0:

        return "0"

    if seconds % 86400 == 0:

        days = seconds // 86400

        return (
            f"{days} day"
            f"{'s' if days != 1 else ''}"
        )

    if seconds % 3600 == 0:

        hours = seconds // 3600

        return (
            f"{hours} hour"
            f"{'s' if hours != 1 else ''}"
        )

    minutes = seconds // 60

    return (
        f"{minutes} minute"
        f"{'s' if minutes != 1 else ''}"
    )


# ============================================================
# PROTECTION TEXT
# ============================================================

def build_protection_text():

    config = load_protection_config()

    enabled = (
        "🟢 ENABLED"
        if config["enabled"]
        else
        "🔴 DISABLED"
    )

    permanent = (
        "♾️ YES"
        if config["permanent"]
        else
        "⏱️ NO"
    )

    whitelist = config.get(
        "whitelist",
        []
    )

    return (

        "🛡️ <b>SSH Protection Settings</b>\n\n"

        f"<b>Status:</b> {enabled}\n"

        f"<b>Mode:</b> IP blocking\n"

        f"<b>Failed attempts:</b> "
        f"{config['attempts']}\n"

        f"<b>Block duration:</b> "
        f"{format_duration(config['duration'])}\n"

        f"<b>Permanent block:</b> "
        f"{permanent}\n"

        f"<b>Whitelist:</b> "
        f"{len(whitelist)} IP(s)\n\n"

        "The counter uses consecutive failed SSH "
        "attempts. A successful login resets the counter."
    )


# ============================================================
# FILEGUARD
# ============================================================

def build_fileguard_text():

    data = fileguard_status()

    if data["active"]:

        state = "ACTIVE"

    elif data["installed"]:

        state = "STOPPED"

    else:

        state = "NOT INSTALLED"

    return (

        "🛡️ <b>FileGuard</b>\n\n"

        f"<b>Status:</b> {state}\n\n"

        f"<b>Events:</b> {data['events']}\n"

        f"<b>Critical:</b> {data['critical']}\n"

        f"<b>High:</b> {data['high']}\n"

        f"<b>Medium:</b> {data['medium']}"
    )


# ============================================================
# /START
# ============================================================

async def cmd_start(
    message: Message
):

    await handle_start(
        message
    )


# ============================================================
# /STATUS
# ============================================================

async def cmd_status(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        return

    await message.answer(

        build_status_text(
            LANGUAGE
        ),

        reply_markup=main_keyboard()
    )


# ============================================================
# /BLOCKED
# ============================================================

async def cmd_blocked(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        return

    await message.answer(

        build_blocked_text(
            LANGUAGE
        ),

        reply_markup=main_keyboard()
    )


# ============================================================
# /EVENTS
# ============================================================

async def cmd_events(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        return

    await message.answer(

        build_events_text(
            LANGUAGE
        ),

        reply_markup=main_keyboard()
    )


# ============================================================
# /FILEGUARD
# ============================================================

async def cmd_fileguard(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        return

    await message.answer(

        build_fileguard_text(),

        reply_markup=main_keyboard()
    )


# ============================================================
# /TIMEZONE
# ============================================================

async def cmd_timezone(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        return

    parts = (
        message.text or ""
    ).split(
        maxsplit=1
    )

    if len(parts) == 1:

        await message.answer(

            "🌍 <b>Timezone</b>\n\n"
            f"Current timezone: "
            f"<code>{html.escape(get_owner_timezone())}</code>\n\n"
            "Use /timezone &lt;timezone&gt; to change it.\n\n"
            "Example:\n"
            "<code>/timezone Europe/Kyiv</code>",

            reply_markup=settings_keyboard()
        )

        return

    timezone_name = parts[1].strip()

    try:

        from zoneinfo import ZoneInfo

        ZoneInfo(
            timezone_name
        )

    except Exception:

        await message.answer(
            "❌ Invalid timezone."
        )

        return

    if set_owner_timezone(
        message.chat.id,
        timezone_name
    ):

        await message.answer(

            "✅ Timezone changed to "
            f"<code>{html.escape(timezone_name)}</code>.",

            reply_markup=settings_keyboard()
        )

    else:

        await message.answer(
            "❌ Failed to change timezone."
        )


# ============================================================
# /PROTECTION
# ============================================================

async def cmd_protection(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        return

    await message.answer(

        build_protection_text(),

        reply_markup=protection_keyboard()
    )


# ============================================================
# /IP
# ============================================================

async def cmd_ip(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        return

    parts = (
        message.text or ""
    ).split()

    if len(parts) != 2:

        await message.answer(
            "🌐 Usage: <code>/ip 1.2.3.4</code>"
        )

        return

    ip = validate_ip(
        parts[1]
    )

    if not ip:

        await message.answer(
            "❌ Invalid IP address."
        )

        return

    if ufw_is_blocked(
        ip
    ):

        state = "BLOCKED"

    else:

        state = "NOT BLOCKED"

    await message.answer(

        "🌐 <b>IP Status</b>\n\n"
        f"<b>IP:</b> <code>{html.escape(ip)}</code>\n"
        f"<b>Status:</b> {state}",

        reply_markup=ip_keyboard()
    )


# ============================================================
# MENU CALLBACK
# ============================================================

async def callback_menu(
    callback: CallbackQuery
):

    if not is_owner(
        callback.message.chat.id
    ):

        await callback.answer(
            "Access denied.",
            show_alert=True
        )

        return

    action = callback.data.split(
        ":",
        1
    )[1]

    if action == "home":

        await callback.message.edit_text(

            "🛡️ <b>ServerGuard</b>\n\n"
            "Select an option:",

            reply_markup=main_keyboard()
        )

    elif action == "status":

        await callback.message.edit_text(

            build_status_text(
                LANGUAGE
            ),

            reply_markup=main_keyboard()
        )

    elif action == "protection":

        await callback.message.edit_text(

            build_protection_text(),

            reply_markup=protection_keyboard()
        )

    elif action == "blocked":

        await callback.message.edit_text(

            build_blocked_text(
                LANGUAGE
            ),

            reply_markup=main_keyboard()
        )

    elif action == "events":

        await callback.message.edit_text(

            build_events_text(
                LANGUAGE
            ),

            reply_markup=main_keyboard()
        )

    elif action == "fileguard":

        await callback.message.edit_text(

            build_fileguard_text(),

            reply_markup=main_keyboard()
        )

    elif action == "ip":

        await callback.message.edit_text(

            "🌐 <b>IP Management</b>\n\n"
            "Choose an action:",

            reply_markup=ip_keyboard()
        )

    elif action == "settings":

        await callback.message.edit_text(

            "⚙️ <b>Settings</b>\n\n"
            "Choose a setting:",

            reply_markup=settings_keyboard()
        )

    await callback.answer()


# ============================================================
# SETTINGS CALLBACK
# ============================================================

async def callback_settings(
    callback: CallbackQuery
):

    if not is_owner(
        callback.message.chat.id
    ):

        await callback.answer(
            "Access denied.",
            show_alert=True
        )

        return

    action = callback.data.split(
        ":",
        1
    )[1]

    if action == "timezone":

        await callback.message.edit_text(

            "🌍 <b>Timezone</b>\n\n"
            f"Current timezone: "
            f"<code>{html.escape(get_owner_timezone())}</code>\n\n"
            "Use /timezone &lt;timezone&gt; to change it.\n\n"
            "Example:\n"
            "<code>/timezone Europe/Kyiv</code>",

            reply_markup=settings_keyboard()
        )

    elif action == "notifications":

        await callback.message.edit_text(

            "🔔 <b>Notifications</b>\n\n"
            "Notification settings are managed by "
            "ServerGuard.",

            reply_markup=settings_keyboard()
        )

    elif action == "protection":

        await callback.message.edit_text(

            build_protection_text(),

            reply_markup=protection_keyboard()
        )

    await callback.answer()


# ============================================================
# PROTECTION CALLBACK
# ============================================================

async def callback_protection(
    callback: CallbackQuery
):

    if not is_owner(
        callback.message.chat.id
    ):

        await callback.answer(
            "Access denied.",
            show_alert=True
        )

        return

    action = callback.data.split(
        ":",
        1
    )[1]

    if action == "show":

        await callback.message.edit_text(

            build_protection_text(),

            reply_markup=protection_keyboard()
        )

    elif action == "toggle":

        config = load_protection_config()

        config["enabled"] = not config[
            "enabled"
        ]

        if save_protection_config(
            config
        ):

            await callback.message.edit_text(

                build_protection_text(),

                reply_markup=protection_keyboard()
            )

        else:

            await callback.answer(
                "Failed to save settings.",
                show_alert=True
            )

    elif action == "attempts":

        await callback.message.edit_text(

            "🔢 <b>Failed attempts before block</b>\n\n"
            "Choose how many consecutive failed SSH "
            "login attempts are required before the IP "
            "is blocked.",

            reply_markup=protection_attempts_keyboard()
        )

    elif action == "duration":

        await callback.message.edit_text(

            "⏱ <b>Block duration</b>\n\n"
            "Choose how long the IP should remain blocked.",

            reply_markup=protection_duration_keyboard()
        )

    elif action == "permanent":

        await callback.message.edit_text(

            "♾️ <b>Permanent blocking</b>\n\n"
            "If enabled, every triggered block will remain "
            "until you manually unblock the IP.",

            reply_markup=protection_permanent_keyboard()
        )

    elif action == "whitelist":

        await callback.message.edit_text(

            "🌐 <b>Whitelist</b>\n\n"
            "Whitelisted IP addresses will never be "
            "automatically blocked.",

            reply_markup=protection_whitelist_keyboard()
        )

    elif action == "reset":

        config = dict(
            DEFAULT_PROTECTION_CONFIG
        )

        if save_protection_config(
            config
        ):

            await callback.message.edit_text(

                build_protection_text(),

                reply_markup=protection_keyboard()
            )

            await callback.answer(
                "Protection settings reset."
            )

            return

        else:

            await callback.answer(
                "Failed to reset settings.",
                show_alert=True
            )

            return

    await callback.answer()


# ============================================================
# ATTEMPTS CALLBACK
# ============================================================

async def callback_protection_attempts(
    callback: CallbackQuery
):

    if not is_owner(
        callback.message.chat.id
    ):

        await callback.answer(
            "Access denied.",
            show_alert=True
        )

        return

    value = callback.data.split(
        ":",
        1
    )[1]

    if value == "custom":

        USER_ACTIONS[
            callback.message.chat.id
        ] = "protection_custom_attempts"

        await callback.message.edit_text(

            "✏️ <b>Custom attempts</b>\n\n"
            "Send a number from <b>1</b> to <b>100</b>.\n\n"
            "Example: <code>7</code>",

            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text="❌ Cancel",
                            callback_data="protection:show"
                        )
                    ]
                ]
            )
        )

        await callback.answer()

        return

    try:

        attempts = int(
            value
        )

    except Exception:

        await callback.answer(
            "Invalid value.",
            show_alert=True
        )

        return

    if attempts < 1 or attempts > 100:

        await callback.answer(
            "Allowed range: 1-100.",
            show_alert=True
        )

        return

    config = load_protection_config()

    config["attempts"] = attempts

    if save_protection_config(
        config
    ):

        await callback.message.edit_text(

            build_protection_text(),

            reply_markup=protection_keyboard()
        )

        await callback.answer(
            f"Threshold changed to {attempts}."
        )

    else:

        await callback.answer(
            "Failed to save settings.",
            show_alert=True
        )


# ============================================================
# DURATION CALLBACK
# ============================================================

async def callback_protection_duration(
    callback: CallbackQuery
):

    if not is_owner(
        callback.message.chat.id
    ):

        await callback.answer(
            "Access denied.",
            show_alert=True
        )

        return

    value = callback.data.split(
        ":",
        1
    )[1]

    if value == "custom":

        USER_ACTIONS[
            callback.message.chat.id
        ] = "protection_custom_duration"

        await callback.message.edit_text(

            "✏️ <b>Custom duration</b>\n\n"
            "Send the duration in minutes.\n\n"
            "Allowed: <b>1-43200 minutes</b>.\n\n"
            "Example:\n"
            "<code>15</code> = 15 minutes\n"
            "<code>120</code> = 2 hours\n"
            "<code>1440</code> = 1 day",

            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text="❌ Cancel",
                            callback_data="protection:show"
                        )
                    ]
                ]
            )
        )

        await callback.answer()

        return

    try:

        duration = int(
            value
        )

    except Exception:

        await callback.answer(
            "Invalid value.",
            show_alert=True
        )

        return

    if duration < 60 or duration > 30 * 24 * 60 * 60:

        await callback.answer(
            "Invalid duration.",
            show_alert=True
        )

        return

    config = load_protection_config()

    config["duration"] = duration

    if save_protection_config(
        config
    ):

        await callback.message.edit_text(

            build_protection_text(),

            reply_markup=protection_keyboard()
        )

        await callback.answer(
            "Duration changed."
        )

    else:

        await callback.answer(
            "Failed to save settings.",
            show_alert=True
        )


# ============================================================
# PERMANENT CALLBACK
# ============================================================

async def callback_protection_permanent(
    callback: CallbackQuery
):

    if not is_owner(
        callback.message.chat.id
    ):

        await callback.answer(
            "Access denied.",
            show_alert=True
        )

        return

    value = callback.data.split(
        ":",
        1
    )[1]

    config = load_protection_config()

    if value == "on":

        config["permanent"] = True

    elif value == "off":

        config["permanent"] = False

    else:

        await callback.answer(
            "Invalid value.",
            show_alert=True
        )

        return

    if save_protection_config(
        config
    ):

        await callback.message.edit_text(

            build_protection_text(),

            reply_markup=protection_keyboard()
        )

        await callback.answer()

    else:

        await callback.answer(
            "Failed to save settings.",
            show_alert=True
        )


# ============================================================
# WHITELIST CALLBACK
# ============================================================

async def callback_protection_whitelist(
    callback: CallbackQuery
):

    if not is_owner(
        callback.message.chat.id
    ):

        await callback.answer(
            "Access denied.",
            show_alert=True
        )

        return

    action = callback.data.split(
        ":",
        1
    )[1]

    if action == "add":

        USER_ACTIONS[
            callback.message.chat.id
        ] = "protection_whitelist_add"

        await callback.message.edit_text(

            "➕ <b>Add IP to whitelist</b>\n\n"
            "Send the IP address that should never "
            "be automatically blocked.",

            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text="❌ Cancel",
                            callback_data="protection:whitelist"
                        )
                    ]
                ]
            )
        )

    elif action == "remove":

        USER_ACTIONS[
            callback.message.chat.id
        ] = "protection_whitelist_remove"

        await callback.message.edit_text(

            "➖ <b>Remove IP from whitelist</b>\n\n"
            "Send the IP address to remove.",

            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text="❌ Cancel",
                            callback_data="protection:whitelist"
                        )
                    ]
                ]
            )
        )

    elif action == "list":

        config = load_protection_config()

        whitelist = config.get(
            "whitelist",
            []
        )

        if whitelist:

            lines = [
                "🌐 <b>Whitelist</b>",
                ""
            ]

            for ip in whitelist:

                lines.append(
                    f"• <code>{html.escape(ip)}</code>"
                )

            text = "\n".join(
                lines
            )

        else:

            text = (
                "🌐 <b>Whitelist</b>\n\n"
                "No IP addresses are whitelisted."
            )

        await callback.message.edit_text(

            text,

            reply_markup=protection_whitelist_keyboard()
        )

    await callback.answer()


# ============================================================
# IP MENU
# ============================================================

async def callback_ip(
    callback: CallbackQuery
):

    if not is_owner(
        callback.message.chat.id
    ):

        await callback.answer(
            "Access denied.",
            show_alert=True
        )

        return

    action = callback.data.split(
        ":",
        1
    )[1]

    chat_id = callback.message.chat.id

    if action == "block":

        USER_ACTIONS[
            chat_id
        ] = "block"

        await callback.message.edit_text(

            "🚫 <b>Block IP</b>\n\n"
            "Send the IP address you want to block.",

            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text="❌ Cancel",
                            callback_data="menu:ip"
                        )
                    ]
                ]
            )
        )

    elif action == "unblock":

        USER_ACTIONS[
            chat_id
        ] = "unblock"

        await callback.message.edit_text(

            "✅ <b>Unblock IP</b>\n\n"
            "Send the IP address you want to unblock.",

            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text="❌ Cancel",
                            callback_data="menu:ip"
                        )
                    ]
                ]
            )
        )

    elif action == "check":

        USER_ACTIONS[
            chat_id
        ] = "check"

        await callback.message.edit_text(

            "🔍 <b>Check IP</b>\n\n"
            "Send the IP address you want to check.",

            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text="❌ Cancel",
                            callback_data="menu:ip"
                        )
                    ]
                ]
            )
        )

    elif action == "list":

        await callback.message.edit_text(

            build_blocked_text(
                LANGUAGE
            ),

            reply_markup=ip_keyboard()
        )

    await callback.answer()


# ============================================================
# CONFIRM
# ============================================================

async def callback_confirm(
    callback: CallbackQuery
):

    if not is_owner(
        callback.message.chat.id
    ):

        await callback.answer(
            "Access denied.",
            show_alert=True
        )

        return

    chat_id = callback.message.chat.id

    data = USER_ACTIONS.get(
        chat_id
    )

    if not data:

        await callback.answer(
            "Action expired.",
            show_alert=True
        )

        return

    try:

        action, ip = data.split(
            ":",
            1
        )

    except ValueError:

        USER_ACTIONS.pop(
            chat_id,
            None
        )

        await callback.answer(
            "Invalid action.",
            show_alert=True
        )

        return

    USER_ACTIONS.pop(
        chat_id,
        None
    )

    if action == "block":

        if ip in get_server_ips():

            await callback.message.edit_text(

                f"⚠️ IP <code>{html.escape(ip)}</code> "
                "is one of the server IP addresses and "
                "cannot be blocked.",

                reply_markup=ip_keyboard()
            )

            await callback.answer()

            return

        success = ufw_block_ip(
            ip
        )

        if success:

            text = (
                f"✅ IP <code>{html.escape(ip)}</code> "
                "has been blocked."
            )

        else:

            text = (
                f"❌ Failed to block IP "
                f"<code>{html.escape(ip)}</code>."
            )

        await callback.message.edit_text(

            text,

            reply_markup=ip_keyboard()
        )

    elif action == "unblock":

        success = ufw_unblock_ip(
            ip
        )

        if success:

            text = (
                f"✅ IP <code>{html.escape(ip)}</code> "
                "has been unblocked."
            )

        else:

            text = (
                f"❌ Failed to unblock IP "
                f"<code>{html.escape(ip)}</code>."
            )

        await callback.message.edit_text(

            text,

            reply_markup=ip_keyboard()
        )

    await callback.answer()


# ============================================================
# TEXT ACTIONS
# ============================================================

async def handle_text(
    message: Message
):

    if not is_owner(
        message.chat.id
    ):

        await message.answer(
            "⛔ Access denied."
        )

        return

    chat_id = message.chat.id

    action = USER_ACTIONS.get(
        chat_id
    )

    if not action:

        await message.answer(

            "🛡️ <b>ServerGuard</b>\n\n"
            "Please use the menu.",

            reply_markup=main_keyboard()
        )

        return

    text_value = (
        message.text or ""
    ).strip()

    # ========================================================
    # CUSTOM ATTEMPTS
    # ========================================================

    if action == "protection_custom_attempts":

        try:

            attempts = int(
                text_value
            )

        except Exception:

            await message.answer(
                "❌ Enter a number from 1 to 100."
            )

            return

        if attempts < 1 or attempts > 100:

            await message.answer(
                "❌ Allowed range: 1-100."
            )

            return

        config = load_protection_config()

        config["attempts"] = attempts

        USER_ACTIONS.pop(
            chat_id,
            None
        )

        if save_protection_config(
            config
        ):

            await message.answer(

                build_protection_text(),

                reply_markup=protection_keyboard()
            )

        else:

            await message.answer(
                "❌ Failed to save settings."
            )

        return

    # ========================================================
    # CUSTOM DURATION
    # ========================================================

    if action == "protection_custom_duration":

        try:

            minutes = int(
                text_value
            )

        except Exception:

            await message.answer(
                "❌ Enter the duration in minutes."
            )

            return

        if minutes < 1 or minutes > 43200:

            await message.answer(
                "❌ Allowed range: 1-43200 minutes."
            )

            return

        config = load_protection_config()

        config["duration"] = (
            minutes * 60
        )

        USER_ACTIONS.pop(
            chat_id,
            None
        )

        if save_protection_config(
            config
        ):

            await message.answer(

                build_protection_text(),

                reply_markup=protection_keyboard()
            )

        else:

            await message.answer(
                "❌ Failed to save settings."
            )

        return

    # ========================================================
    # WHITELIST ADD
    # ========================================================

    if action == "protection_whitelist_add":

        ip = validate_ip(
            text_value
        )

        if not ip:

            await message.answer(
                "❌ Invalid IP address."
            )

            return

        if ip in get_server_ips():

            await message.answer(
                "⚠️ This is one of the server IPs. "
                "It does not need to be added to whitelist."
            )

            USER_ACTIONS.pop(
                chat_id,
                None
            )

            return

        config = load_protection_config()

        whitelist = config.get(
            "whitelist",
            []
        )

        if ip not in whitelist:

            whitelist.append(
                ip
            )

        config["whitelist"] = whitelist

        USER_ACTIONS.pop(
            chat_id,
            None
        )

        if save_protection_config(
            config
        ):

            await message.answer(

                f"✅ IP <code>{html.escape(ip)}</code> "
                "added to whitelist.",

                reply_markup=protection_whitelist_keyboard()
            )

        else:

            await message.answer(
                "❌ Failed to save whitelist."
            )

        return

    # ========================================================
    # WHITELIST REMOVE
    # ========================================================

    if action == "protection_whitelist_remove":

        ip = validate_ip(
            text_value
        )

        if not ip:

            await message.answer(
                "❌ Invalid IP address."
            )

            return

        config = load_protection_config()

        whitelist = config.get(
            "whitelist",
            []
        )

        if ip in whitelist:

            whitelist.remove(
                ip
            )

        else:

            await message.answer(

                f"ℹ️ IP <code>{html.escape(ip)}</code> "
                "is not in whitelist.",

                reply_markup=protection_whitelist_keyboard()
            )

            USER_ACTIONS.pop(
                chat_id,
                None
            )

            return

        config["whitelist"] = whitelist

        USER_ACTIONS.pop(
            chat_id,
            None
        )

        if save_protection_config(
            config
        ):

            await message.answer(

                f"✅ IP <code>{html.escape(ip)}</code> "
                "removed from whitelist.",

                reply_markup=protection_whitelist_keyboard()
            )

        else:

            await message.answer(
                "❌ Failed to save whitelist."
            )

        return

    # ========================================================
    # NORMAL IP ACTIONS
    # ========================================================

    ip = validate_ip(
        text_value
    )

    if not ip:

        await message.answer(
            "❌ Invalid IP address."
        )

        return

    USER_ACTIONS.pop(
        chat_id,
        None
    )

    if action == "check":

        if ufw_is_blocked(
            ip
        ):

            state = "BLOCKED"

        else:

            state = "NOT BLOCKED"

        await message.answer(

            "🌐 <b>IP Status</b>\n\n"
            f"<b>IP:</b> <code>{html.escape(ip)}</code>\n"
            f"<b>Status:</b> {state}",

            reply_markup=ip_keyboard()
        )

        return

    if action == "block":

        if ip in get_server_ips():

            await message.answer(

                f"⚠️ IP <code>{html.escape(ip)}</code> "
                "is one of the server IP addresses and "
                "cannot be blocked.",

                reply_markup=ip_keyboard()
            )

            return

        if ufw_is_blocked(
            ip
        ):

            await message.answer(

                f"ℹ️ IP <code>{html.escape(ip)}</code> "
                "is already blocked.",

                reply_markup=ip_keyboard()
            )

            return

        USER_ACTIONS[
            chat_id
        ] = f"block:{ip}"

        await message.answer(

            f"⚠️ Are you sure you want to block "
            f"<code>{html.escape(ip)}</code>?",

            reply_markup=confirm_keyboard(
                action="block"
            )
        )

        return

    if action == "unblock":

        USER_ACTIONS[
            chat_id
        ] = f"unblock:{ip}"

        await message.answer(

            f"⚠️ Are you sure you want to unblock "
            f"<code>{html.escape(ip)}</code>?",

            reply_markup=confirm_keyboard(
                action="unblock"
            )
        )


# ============================================================
# REGISTER
# ============================================================

def register_handlers(
    dp: Dispatcher
):

    # ========================================================
    # COMMANDS
    # ========================================================

    dp.message.register(
        cmd_start,
        CommandStart()
    )

    dp.message.register(
        cmd_status,
        Command("status")
    )

    dp.message.register(
        cmd_blocked,
        Command("blocked")
    )

    dp.message.register(
        cmd_events,
        Command("events")
    )

    dp.message.register(
        cmd_fileguard,
        Command("fileguard")
    )

    dp.message.register(
        cmd_timezone,
        Command("timezone")
    )

    dp.message.register(
        cmd_protection,
        Command("protection")
    )

    dp.message.register(
        cmd_ip,
        Command("ip")
    )

    # ========================================================
    # SETTINGS
    # ========================================================

    dp.callback_query.register(
        callback_settings,
        F.data.startswith(
            "settings:"
        )
    )

    # ========================================================
    # PROTECTION
    # ========================================================

    dp.callback_query.register(
        callback_protection,
        F.data.startswith(
            "protection:"
        )
    )

    dp.callback_query.register(
        callback_protection_attempts,
        F.data.startswith(
            "protection_attempts:"
        )
    )

    dp.callback_query.register(
        callback_protection_duration,
        F.data.startswith(
            "protection_duration:"
        )
    )

    dp.callback_query.register(
        callback_protection_permanent,
        F.data.startswith(
            "protection_permanent:"
        )
    )

    dp.callback_query.register(
        callback_protection_whitelist,
        F.data.startswith(
            "protection_whitelist:"
        )
    )

    # ========================================================
    # IP
    # ========================================================

    dp.callback_query.register(
        callback_ip,
        F.data.startswith(
            "ip:"
        )
    )

    dp.callback_query.register(
        callback_confirm,
        F.data.startswith(
            "confirm:"
        )
    )

    # ========================================================
    # MENU
    # ========================================================

    dp.callback_query.register(
        callback_menu,
        F.data.startswith(
            "menu:"
        )
    )

    # ========================================================
    # TEXT
    # ========================================================

    dp.message.register(
        handle_text
    )