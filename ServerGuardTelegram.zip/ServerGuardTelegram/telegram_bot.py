#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ServerGuard Telegram Bot
========================

Works together with:
  * TelegramBot.cpp
  * Brute Force Guard
  * Port & Service Monitor

Automatic notifications:
  * IP blocked
  * IP unblocked
  * SSH login
  * New SSH IP
  * Failed SSH attempts
  * New listening port
  * Closed listening port
  * Port process changed
  * New incoming network connection
  * Service started
  * Service stopped / removed
  * Service changed
  * Daily report
  * Queue messages

Network notification policy:
  * New incoming connections -> SEND
  * Outgoing connections -> IGNORE
  * Connection closed -> IGNORE
  * LAST-ACK -> IGNORE
  * TIME-WAIT -> IGNORE
  * CLOSE-WAIT -> IGNORE
"""

import asyncio
import hmac
import html
import ipaddress
import json
import logging
import math
import os
import shutil
import socket
import sys
import time

from collections import Counter, deque
from datetime import datetime, timezone
from pathlib import Path

import aiohttp

from aiogram import (
    BaseMiddleware,
    Bot,
    Dispatcher,
    F,
    Router,
)

from aiogram.client.default import DefaultBotProperties

from aiogram.enums import ParseMode

from aiogram.exceptions import (
    TelegramAPIError,
    TelegramBadRequest,
)

from aiogram.filters import (
    Command,
    CommandObject,
)

from aiogram.types import (
    BotCommand,
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)


# ============================================================
# PATHS
# ============================================================

BASE_DIR = Path(
    os.environ.get(
        "SERVERGUARD_DIR",
        "/opt/serverguard"
    )
)

TELEGRAM_DIR = (
    BASE_DIR / "telegram"
)

CONFIG_FILE = (
    TELEGRAM_DIR / "telegram.conf"
)

VERIFICATION_FILE = (
    TELEGRAM_DIR / "verification.json"
)

OWNER_FILE = (
    TELEGRAM_DIR / "owner.json"
)

QUEUE_DIR = (
    TELEGRAM_DIR / "queue"
)

DATA_DIR = (
    BASE_DIR / "data"
)


# ============================================================
# BRUTE FORCE GUARD FILES
# ============================================================

PROTECTION_CONFIG_FILE = (
    DATA_DIR / "protection_config.json"
)

EVENTS_FILE = (
    DATA_DIR / "ssh_events.json"
)

BLOCKS_FILE = (
    DATA_DIR / "blocked_ips.json"
)

STATS_FILE = (
    DATA_DIR / "stats.json"
)


# ============================================================
# PORT & SERVICE MONITOR FILES
# ============================================================

PORT_MONITOR_EVENTS_FILE = (
    DATA_DIR / "port_monitor_events.json"
)

NETWORK_MONITOR_EVENTS_FILE = (
    DATA_DIR / "network_monitor_events.json"
)

SERVICE_MONITOR_EVENTS_FILE = (
    DATA_DIR / "service_monitor_events.json"
)


# ============================================================
# SETTINGS
# ============================================================

POLL_INTERVAL = 2

QUEUE_INTERVAL = 3

BLOCKS_PER_PAGE = 8

MAX_LIST_LINES = 15

REG_WINDOW = 900

REG_USER_LIMIT = 5

REG_GLOBAL_LIMIT = 15


# ============================================================
# DEFAULT PROTECTION
# ============================================================

DEFAULT_PROTECTION = {
    "enabled": True,
    "attempts": 5,
    "duration": 600,
    "permanent": False,
    "mode": "ip",
    "whitelist": [],
}


# ============================================================
# DEFAULT TELEGRAM SETTINGS
# ============================================================

DEFAULT_SETTINGS = {
    "notify_block": True,
    "notify_unblock": True,

    "notify_login": True,
    "notify_new_ip": True,
    "notify_failed": False,

    "notify_port": True,
    "notify_network": True,
    "notify_service": True,

    "geo": True,

    "daily_report": True,

    "report_hour": 9,

    "last_report": "",
}


# ============================================================
# NOTIFICATION LABELS
# ============================================================

NOTIFY_LABELS = {

    "notify_block":
        "🚫 Blocks",

    "notify_unblock":
        "✅ Unblocks",

    "notify_login":
        "🔑 All successful logins",

    "notify_new_ip":
        "🆕 Login from a new IP",

    "notify_failed":
        "⚠️ Failed attempts",

    "notify_port":
        "🌐 Port changes",

    "notify_network":
        "🔗 Network connections",

    "notify_service":
        "🔧 Service changes",

    "geo":
        "🌍 IP geolocation",

    "daily_report":
        "📅 Daily report",
}


# ============================================================
# LOGGING
# ============================================================

logging.basicConfig(
    level=logging.INFO,
    format="[ServerGuard-TG] %(levelname)s %(message)s",
    stream=sys.stdout,
)

log = logging.getLogger(
    "sg-telegram"
)


# ============================================================
# GLOBAL OBJECTS
# ============================================================

router = Router()

FILE_LOCK = asyncio.Lock()

OWNER: dict = {}

USER_FAILS: dict = {}

GLOBAL_FAILS: deque = deque()

SUPPRESS_BLOCK: set = set()

SUPPRESS_UNBLOCK: set = set()

GEO_CACHE: dict = {}


# ============================================================
# BASIC HELPERS
# ============================================================

def esc(value) -> str:

    return html.escape(
        str(value),
        quote=False
    )


def to_bool(value) -> bool:

    if isinstance(value, str):

        return value.strip().lower() in (
            "1",
            "true",
            "yes",
            "on",
            "enabled",
        )

    return bool(value)


def to_int(
    value,
    default=0
) -> int:

    try:

        return int(value)

    except Exception:

        return default


def utc_iso(
    ts=None
) -> str:

    if ts is None:

        ts = time.time()

    return datetime.fromtimestamp(
        ts,
        tz=timezone.utc
    ).isoformat()


def fmt_ts(ts) -> str:

    try:

        return datetime.fromtimestamp(
            int(ts)
        ).strftime(
            "%d.%m %H:%M:%S"
        )

    except Exception:

        return "?"


def fmt_dur(seconds) -> str:

    seconds = to_int(
        seconds
    )

    if seconds < 60:

        return f"{seconds} s"

    days, rem = divmod(
        seconds,
        86400
    )

    hours, rem = divmod(
        rem,
        3600
    )

    minutes = rem // 60

    parts = []

    if days:

        parts.append(
            f"{days} d"
        )

    if hours:

        parts.append(
            f"{hours} h"
        )

    if minutes:

        parts.append(
            f"{minutes} min"
        )

    return (
        " ".join(parts)
        or "0 min"
    )


def block_term(
    rec: dict
) -> str:

    if rec.get("permanent"):

        return "♾ permanent"

    start = to_int(
        rec.get("blocked_at"),
        0
    )

    end = to_int(
        rec.get("expires_at"),
        0
    )

    if (
        start
        and end
        and end > start
    ):

        seconds = end - start

        if seconds >= 60:

            seconds = (
                round(seconds / 60)
                * 60
            )

        return fmt_dur(
            seconds
        )

    duration = to_int(
        rec.get("duration"),
        0
    )

    if duration > 0:

        return fmt_dur(
            duration
        )

    if end:

        left = (
            end - time.time()
        )

        if left > 0:

            return (
                fmt_dur(left)
                + " left"
            )

    return "unknown"


def parse_ip(value):

    try:

        return str(
            ipaddress.ip_address(
                str(value).strip()
            )
        )

    except ValueError:

        return None


def ev_time(event) -> int:

    return to_int(
        event.get("time"),
        0
    )


# ============================================================
# JSON
# ============================================================

def load_json(
    path: Path,
    default
):

    try:

        if not path.exists():

            return default

        with path.open(
            "r",
            encoding="utf-8"
        ) as file:

            return json.load(file)

    except Exception as e:

        log.warning(
            "JSON load error %s: %s",
            path,
            e
        )

        return default


def save_json(
    path: Path,
    data,
    private=False
) -> bool:

    tmp = path.with_name(
        path.name + ".tg.tmp"
    )

    try:

        path.parent.mkdir(
            parents=True,
            exist_ok=True
        )

        with tmp.open(
            "w",
            encoding="utf-8"
        ) as file:

            json.dump(
                data,
                file,
                indent=2,
                ensure_ascii=False
            )

            file.write("\n")

        if private:

            os.chmod(
                tmp,
                0o600
            )

        tmp.replace(
            path
        )

        return True

    except Exception as e:

        log.error(
            "JSON save error %s: %s",
            path,
            e
        )

        try:

            if tmp.exists():

                tmp.unlink()

        except Exception:

            pass

        return False


def mtime_ns(path: Path):

    try:

        return path.stat().st_mtime_ns

    except Exception:

        return None


# ============================================================
# GUARD DATA
# ============================================================

def load_config() -> dict:

    cfg = dict(
        DEFAULT_PROTECTION
    )

    data = load_json(
        PROTECTION_CONFIG_FILE,
        {}
    )

    if isinstance(data, dict):

        cfg.update(
            data
        )

    cfg["enabled"] = to_bool(
        cfg.get(
            "enabled",
            True
        )
    )

    cfg["permanent"] = to_bool(
        cfg.get(
            "permanent",
            False
        )
    )

    cfg["attempts"] = max(
        1,
        min(
            to_int(
                cfg.get(
                    "attempts"
                ),
                5
            ),
            100
        )
    )

    cfg["duration"] = max(
        60,
        min(
            to_int(
                cfg.get(
                    "duration"
                ),
                600
            ),
            30 * 24 * 3600
        )
    )

    wl = cfg.get(
        "whitelist",
        []
    )

    clean = []

    if isinstance(
        wl,
        list
    ):

        for ip in wl:

            ip = str(
                ip
            ).strip()

            if (
                ip
                and ip not in clean
            ):

                clean.append(
                    ip
                )

    cfg["whitelist"] = clean

    return cfg


def update_protection(
    changes: dict
) -> bool:

    data = load_json(
        PROTECTION_CONFIG_FILE,
        None
    )

    if not isinstance(
        data,
        dict
    ):

        data = dict(
            DEFAULT_PROTECTION
        )

    data.update(
        changes
    )

    return save_json(
        PROTECTION_CONFIG_FILE,
        data
    )


def load_events() -> list:

    data = load_json(
        EVENTS_FILE,
        []
    )

    if not isinstance(
        data,
        list
    ):

        return []

    return [
        e
        for e in data
        if isinstance(
            e,
            dict
        )
    ]


def load_blocks() -> dict:

    data = load_json(
        BLOCKS_FILE,
        {}
    )

    if not isinstance(
        data,
        dict
    ):

        return {}

    return {
        ip: rec
        for ip, rec in data.items()
        if isinstance(
            rec,
            dict
        )
    }


def save_blocks(
    blocks: dict
) -> bool:

    return save_json(
        BLOCKS_FILE,
        blocks
    )


def load_stats() -> dict:

    data = load_json(
        STATS_FILE,
        {}
    )

    return (
        data
        if isinstance(
            data,
            dict
        )
        else {}
    )


def bump_stat(
    name: str
):

    stats = load_stats()

    stats[name] = (
        to_int(
            stats.get(
                name,
                0
            )
        )
        + 1
    )

    save_json(
        STATS_FILE,
        stats
    )


# ============================================================
# PORT / SERVICE MONITOR DATA
# ============================================================

def load_monitor_events(
    path: Path
) -> list:

    data = load_json(
        path,
        []
    )

    if not isinstance(
        data,
        list
    ):

        return []

    return [
        event
        for event in data
        if isinstance(
            event,
            dict
        )
    ]


def monitor_event_key(
    event: dict
) -> str:

    important = (
        "time",
        "timestamp",
        "type",
        "event",
        "action",

        "protocol",

        "port",
        "local_port",
        "remote_port",

        "address",
        "local_address",
        "remote_address",

        "local",
        "remote",

        "process",
        "process_name",

        "pid",

        "user",
        "username",

        "service",
        "systemd_service",
        "unit",

        "state",

        "old_state",
        "new_state",

        "old_process",
        "new_process",

        "old_pid",
        "new_pid",

        "old_user",
        "new_user",

        "old_service",
        "new_service",
    )

    return "|".join(
        str(
            event.get(
                key,
                ""
            )
        )
        for key in important
    )


def monitor_event_time(
    event: dict
) -> int:

    value = event.get(
        "time"
    )

    if value is None:

        value = event.get(
            "timestamp"
        )

    return to_int(
        value,
        int(
            time.time()
        )
    )


def monitor_event_type(
    event: dict
) -> str:

    value = event.get(
        "type"
    )

    if value is None:

        value = event.get(
            "event"
        )

    if value is None:

        value = event.get(
            "action"
        )

    return str(
        value or "unknown"
    ).strip().lower()


def monitor_value(
    event: dict,
    *keys,
    default="?"
):

    for key in keys:

        value = event.get(
            key
        )

        if (
            value is not None
            and str(value) != ""
        ):

            return value

    return default


def format_monitor_port(
    event: dict
) -> str:

    protocol = str(
        monitor_value(
            event,
            "protocol",
            default="tcp"
        )
    ).lower()

    address = monitor_value(
        event,
        "address",
        "local_address",
        "local",
        default="0.0.0.0"
    )

    port = monitor_value(
        event,
        "port",
        "local_port",
        default="?"
    )

    process = monitor_value(
        event,
        "process",
        "process_name",
        default=""
    )

    pid = monitor_value(
        event,
        "pid",
        default=""
    )

    user = monitor_value(
        event,
        "user",
        "username",
        default=""
    )

    service = monitor_value(
        event,
        "service",
        "systemd_service",
        "unit",
        default=""
    )

    lines = [
        f"🌐 <code>{esc(protocol.upper())}</code> "
        f"<code>{esc(address)}:{esc(port)}</code>"
    ]

    if process:

        process_line = (
            f"⚙️ Process: "
            f"<code>{esc(process)}</code>"
        )

        if pid:

            process_line += (
                f" · PID "
                f"<code>{esc(pid)}</code>"
            )

        lines.append(
            process_line
        )

    if user:

        lines.append(
            f"👤 User: "
            f"<code>{esc(user)}</code>"
        )

    if service:

        lines.append(
            f"🔧 Service: "
            f"<code>{esc(service)}</code>"
        )

    return "\n".join(
        lines
    )


def format_monitor_connection(
    event: dict
) -> str:

    protocol = str(
        monitor_value(
            event,
            "protocol",
            default="tcp"
        )
    ).upper()

    state = str(
        monitor_value(
            event,
            "state",
            default="?"
        )
    )

    local_address = monitor_value(
        event,
        "local_address",
        "local",
        default="?"
    )

    local_port = monitor_value(
        event,
        "local_port",
        "port",
        default="?"
    )

    remote_address = monitor_value(
        event,
        "remote_address",
        "remote",
        default="?"
    )

    remote_port = monitor_value(
        event,
        "remote_port",
        default="?"
    )

    process = monitor_value(
        event,
        "process",
        "process_name",
        default=""
    )

    pid = monitor_value(
        event,
        "pid",
        default=""
    )

    user = monitor_value(
        event,
        "user",
        "username",
        default=""
    )

    lines = [
        f"🌐 <b>{esc(protocol)}</b> "
        f"<code>{esc(local_address)}:{esc(local_port)}</code>",
        f"↔️ <code>{esc(remote_address)}:{esc(remote_port)}</code>",
        f"📌 State: <b>{esc(state)}</b>",
    ]

    if process:

        line = (
            f"⚙️ Process: "
            f"<code>{esc(process)}</code>"
        )

        if pid:

            line += (
                f" · PID "
                f"<code>{esc(pid)}</code>"
            )

        lines.append(
            line
        )

    if user:

        lines.append(
            f"👤 User: "
            f"<code>{esc(user)}</code>"
        )

    return "\n".join(
        lines
    )


def format_monitor_service(
    event: dict
) -> str:

    service = monitor_value(
        event,
        "service",
        "systemd_service",
        "unit",
        default="?"
    )

    state = monitor_value(
        event,
        "state",
        "new_state",
        default=""
    )

    old_state = monitor_value(
        event,
        "old_state",
        default=""
    )

    new_state = monitor_value(
        event,
        "new_state",
        default=""
    )

    process = monitor_value(
        event,
        "process",
        "process_name",
        default=""
    )

    pid = monitor_value(
        event,
        "pid",
        default=""
    )

    lines = [
        f"🔧 Service: "
        f"<code>{esc(service)}</code>"
    ]

    if (
        old_state
        and new_state
    ):

        lines.append(
            f"🔄 State: "
            f"<code>{esc(old_state)}</code> "
            f"→ "
            f"<code>{esc(new_state)}</code>"
        )

    elif state:

        lines.append(
            f"📌 State: "
            f"<b>{esc(state)}</b>"
        )

    if process:

        line = (
            f"⚙️ Process: "
            f"<code>{esc(process)}</code>"
        )

        if pid:

            line += (
                f" · PID "
                f"<code>{esc(pid)}</code>"
            )

        lines.append(
            line
        )

    return "\n".join(
        lines
    )


# ============================================================
# NETWORK FILTER
# ============================================================

IGNORED_NETWORK_STATES = {
    "last-ack",
    "time-wait",
    "close-wait",
    "fin-wait-1",
    "fin-wait-2",
    "closing",
    "closed",
    "listen",
}


def clean_endpoint(value):
    """
    Converts an endpoint into a clean string.

    Examples:
        1.2.3.4:22
        [::1]:443
        *
        0.0.0.0
    """

    if value is None:

        return ""

    text = str(
        value
    ).strip()

    if not text:

        return ""

    return text


def endpoint_host(
    value
):
    """
    Extract host part from an endpoint.

    Supports:
        1.2.3.4:22
        [2001:db8::1]:443
        2001:db8::1
        *
    """

    value = clean_endpoint(
        value
    )

    if not value:

        return ""

    if value == "*":

        return ""

    if value.startswith("["):

        end = value.find("]")

        if end > 0:

            return value[1:end]

    if value.count(":") == 1:

        host, _ = value.rsplit(
            ":",
            1
        )

        return host

    try:

        ipaddress.ip_address(
            value
        )

        return value

    except ValueError:

        pass

    return value


def endpoint_port(
    value
):
    """
    Extract port from:
        1.2.3.4:22
        [::1]:443
        22
    """

    if value is None:

        return None

    text = str(
        value
    ).strip()

    if not text:

        return None

    if text.isdigit():

        return to_int(
            text,
            None
        )

    if text.startswith("["):

        end = text.find("]")

        if (
            end >= 0
            and len(text) > end + 2
            and text[end + 1] == ":"
        ):

            port = text[
                end + 2:
            ]

            if port.isdigit():

                return to_int(
                    port,
                    None
                )

        return None

    if ":" in text:

        host, port = text.rsplit(
            ":",
            1
        )

        if port.isdigit():

            return to_int(
                port,
                None
            )

    return None


def event_local_port(
    event: dict
):
    """
    Get local/server port.

    Supports both:
        local_port
    and:
        local = 1.2.3.4:22
    """

    value = event.get(
        "local_port"
    )

    if (
        value is not None
        and str(value).strip()
    ):

        return to_int(
            value,
            None
        )

    value = event.get(
        "port"
    )

    if (
        value is not None
        and str(value).strip()
    ):

        return to_int(
            value,
            None
        )

    local = event.get(
        "local"
    )

    if local:

        return endpoint_port(
            local
        )

    local = event.get(
        "local_address"
    )

    if local:

        return endpoint_port(
            local
        )

    return None


def event_remote_port(
    event: dict
):
    """
    Get remote/client port.
    """

    value = event.get(
        "remote_port"
    )

    if (
        value is not None
        and str(value).strip()
    ):

        return to_int(
            value,
            None
        )

    remote = event.get(
        "remote"
    )

    if remote:

        return endpoint_port(
            remote
        )

    remote = event.get(
        "remote_address"
    )

    if remote:

        return endpoint_port(
            remote
        )

    return None


def event_local_host(
    event: dict
):

    value = event.get(
        "local_address"
    )

    if value:

        return endpoint_host(
            value
        )

    value = event.get(
        "local"
    )

    if value:

        return endpoint_host(
            value
        )

    return ""


def event_remote_host(
    event: dict
):

    value = event.get(
        "remote_address"
    )

    if value:

        return endpoint_host(
            value
        )

    value = event.get(
        "remote"
    )

    if value:

        return endpoint_host(
            value
        )

    return ""


def is_ignored_network_state(
    event: dict
) -> bool:

    state = str(
        monitor_value(
            event,
            "state",
            default=""
        )
    ).strip().lower()

    return state in (
        IGNORED_NETWORK_STATES
    )


def is_incoming_network_connection(
    event: dict
) -> bool:
    """
    Determine whether a network event is an
    incoming connection to the server.

    Example:

        Server: 91.219.60.40:22
        Client: 121.184.144.232:9438

    local_port = 22
    remote_port = 9438

    => incoming

    Outgoing example:

        Server: 91.219.60.40:54808
        Remote: 149.154.166.110:443

    local_port = 54808
    remote_port = 443

    => outgoing
    """

    local_port = event_local_port(
        event
    )

    remote_port = event_remote_port(
        event
    )

    if (
        local_port is None
        or remote_port is None
    ):

        return False

    # --------------------------------------------------------
    # Well-known server ports.
    #
    # If the monitor does not provide enough information
    # to determine the direction, these are treated as
    # server-side listening ports.
    # --------------------------------------------------------

    server_ports = {
        20,
        21,
        22,
        23,
        25,
        53,
        80,
        110,
        111,
        123,
        135,
        139,
        143,
        443,
        445,
        465,
        587,
        993,
        995,
        1433,
        2049,
        2375,
        2376,
        3000,
        3306,
        3389,
        5000,
        5432,
        5672,
        6379,
        6443,
        8000,
        8080,
        8443,
        9000,
        9090,
        10000,
    }

    # --------------------------------------------------------
    # Classic client/server direction:
    #
    # Incoming:
    #   local port 22
    #   remote port 9438
    #
    # Outgoing:
    #   local port 54808
    #   remote port 443
    # --------------------------------------------------------

    if (
        local_port in server_ports
        and remote_port >= 1024
    ):

        return True

    # --------------------------------------------------------
    # If local port is ephemeral and remote port is a
    # well-known server port, this is normally outgoing.
    # --------------------------------------------------------

    if (
        local_port >= 1024
        and remote_port in server_ports
    ):

        return False

    # --------------------------------------------------------
    # For two unusual ports we cannot safely determine
    # direction. Do not send the event.
    # --------------------------------------------------------

    return False


def should_send_network_event(
    event: dict,
    event_type: str
) -> bool:
    """
    Final Telegram network notification filter.

    Only NEW incoming connections are allowed.

    Everything else is ignored.
    """

    event_type = str(
        event_type or ""
    ).strip().lower()

    # --------------------------------------------------------
    # Never send connection_closed.
    # --------------------------------------------------------

    if event_type in {
        "connection_closed",
        "closed",
        "network_connection_closed",
        "connection_close",
    }:

        return False

    # --------------------------------------------------------
    # Only new connections are interesting.
    # --------------------------------------------------------

    if event_type != "new_connection":

        return False

    # --------------------------------------------------------
    # Ignore normal TCP closing states.
    # --------------------------------------------------------

    if is_ignored_network_state(
        event
    ):

        return False

    # --------------------------------------------------------
    # Only incoming connections.
    # --------------------------------------------------------

    if not is_incoming_network_connection(
        event
    ):

        return False

    return True


# ============================================================
# OWNER / SETTINGS
# ============================================================

def load_owner():

    data = load_json(
        OWNER_FILE,
        {}
    )

    OWNER.clear()

    if (
        isinstance(
            data,
            dict
        )
        and data.get(
            "user_id"
        )
    ):

        OWNER.update(
            data
        )


def save_owner():

    save_json(
        OWNER_FILE,
        OWNER,
        private=True
    )


def is_owner(
    user_id
) -> bool:

    return (
        bool(OWNER)
        and OWNER.get(
            "user_id"
        ) == user_id
    )


def settings() -> dict:

    result = dict(
        DEFAULT_SETTINGS
    )

    stored = OWNER.get(
        "settings"
    )

    if isinstance(
        stored,
        dict
    ):

        result.update(
            stored
        )

    return result


def set_setting(
    key,
    value
):

    if not OWNER:

        return

    OWNER.setdefault(
        "settings",
        {}
    )[key] = value

    save_owner()


def known_ips() -> set:

    stored = OWNER.get(
        "known_ips"
    )

    return (
        set(stored)
        if isinstance(
            stored,
            list
        )
        else set()
    )


def remember_ip(
    ip: str
):

    if not OWNER:

        return

    stored = OWNER.get(
        "known_ips"
    )

    if not isinstance(
        stored,
        list
    ):

        stored = []

    if ip not in stored:

        stored.append(
            ip
        )

        OWNER["known_ips"] = (
            stored[-1000:]
        )

        save_owner()


def seed_known_ips():

    if not OWNER:

        return

    stored = OWNER.get(
        "known_ips"
    )

    stored = (
        list(stored)
        if isinstance(
            stored,
            list
        )
        else []
    )

    changed = False

    for event in load_events():

        if event.get(
            "type"
        ) != "success":

            continue

        ip = event.get(
            "ip"
        )

        if (
            ip
            and ip not in stored
        ):

            stored.append(
                ip
            )

            changed = True

    if changed:

        OWNER["known_ips"] = (
            stored[-1000:]
        )

        save_owner()


def read_token() -> str:

    token = os.environ.get(
        "BOT_TOKEN",
        ""
    ).strip()

    try:

        if CONFIG_FILE.exists():

            for line in CONFIG_FILE.read_text(
                encoding="utf-8"
            ).splitlines():

                line = line.strip()

                if line.startswith(
                    "BOT_TOKEN="
                ):

                    token = (
                        line.split(
                            "=",
                            1
                        )[1]
                        .strip()
                        .strip('"')
                        .strip("'")
                    )

                    break

    except Exception as e:

        log.error(
            "Cannot read %s: %s",
            CONFIG_FILE,
            e
        )

    return token


# ============================================================
# SYSTEM COMMANDS
# ============================================================

async def run_cmd(
    *args,
    timeout=15
):

    proc = None

    try:

        proc = await asyncio.create_subprocess_exec(
            *args,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )

        out, _ = await asyncio.wait_for(
            proc.communicate(),
            timeout=timeout
        )

        return (
            proc.returncode,
            out.decode(
                "utf-8",
                "replace"
            )
        )

    except FileNotFoundError:

        return (
            127,
            f"{args[0]}: command not found"
        )

    except asyncio.TimeoutError:

        try:

            if proc:

                proc.kill()

        except Exception:

            pass

        return (
            124,
            "timeout"
        )

    except Exception as e:

        return (
            1,
            str(e)
        )


async def local_ips() -> set:

    ips = {
        "127.0.0.1",
        "::1"
    }

    rc, out = await run_cmd(
        "hostname",
        "-I",
        timeout=5
    )

    if rc == 0:

        ips.update(
            out.split()
        )

    return ips


def _rule_missing(
    text: str
) -> bool:

    low = text.lower()

    return (
        "non-existent" in low
        or "could not delete" in low
        or "not found" in low
    )


async def do_unblock(
    ip: str
):

    for _ in range(5):

        rc, out = await run_cmd(
            "ufw",
            "delete",
            "deny",
            "from",
            ip
        )

        if _rule_missing(out):

            break

        if rc != 0:

            return (
                False,
                out.strip()[:300]
                or "ufw error"
            )

    async with FILE_LOCK:

        blocks = load_blocks()

        rec = blocks.pop(
            ip,
            None
        )

        if rec is not None:

            SUPPRESS_UNBLOCK.add(
                ip
            )

            save_blocks(
                blocks
            )

            bump_stat(
                "unblocked"
            )

    return (
        True,
        "OK"
    )


async def do_block(
    ip: str,
    permanent: bool,
    duration: int,
    reason: str
):

    ip = parse_ip(
        ip
    )

    if not ip:

        return (
            False,
            "Invalid IP address"
        )

    cfg = load_config()

    if ip in cfg["whitelist"]:

        return (
            False,
            "IP is in the whitelist"
        )

    if ip in await local_ips():

        return (
            False,
            "This is the server's own IP"
        )

    rc, out = await run_cmd(
        "ufw",
        "insert",
        "1",
        "deny",
        "from",
        ip
    )

    if rc != 0:

        return (
            False,
            out.strip()[:300]
            or "ufw error"
        )

    now = int(
        time.time()
    )

    duration = max(
        60,
        int(duration)
    )

    expires = (
        None
        if permanent
        else now + duration
    )

    async with FILE_LOCK:

        blocks = load_blocks()

        blocks[ip] = {
            "ip": ip,
            "blocked_at": now,
            "blocked_at_iso": utc_iso(now),
            "failed_attempts": 0,
            "permanent": bool(
                permanent
            ),
            "duration": duration,
            "expires_at": expires,
            "expires_at_iso": (
                None
                if expires is None
                else utc_iso(expires)
            ),
            "reason": reason,
        }

        SUPPRESS_BLOCK.add(
            (
                ip,
                now
            )
        )

        save_blocks(
            blocks
        )

        bump_stat(
            "blocked"
        )

    return (
        True,
        "OK"
    )


def whitelist_add(
    ip: str
) -> bool:

    cfg = load_config()

    wl = cfg["whitelist"]

    if ip in wl:

        return False

    wl.append(
        ip
    )

    update_protection(
        {
            "whitelist": wl
        }
    )

    return True


def whitelist_remove(
    ip: str
) -> bool:

    cfg = load_config()

    wl = cfg["whitelist"]

    if ip not in wl:

        return False

    wl.remove(
        ip
    )

    update_protection(
        {
            "whitelist": wl
        }
    )

    return True


# ============================================================
# GEO
# ============================================================

async def geo_lookup(
    ip: str,
    force=False
) -> str:

    if (
        not force
        and not settings().get(
            "geo",
            True
        )
    ):

        return ""

    try:

        addr = ipaddress.ip_address(
            ip
        )

    except ValueError:

        return ""

    if (
        addr.is_private
        or addr.is_loopback
        or addr.is_link_local
    ):

        return "🏠 local address"

    if ip in GEO_CACHE:

        return GEO_CACHE[ip]

    result = ""

    try:

        timeout = aiohttp.ClientTimeout(
            total=4
        )

        async with aiohttp.ClientSession(
            timeout=timeout
        ) as session:

            async with session.get(
                f"http://ip-api.com/json/{ip}",
                params={
                    "fields":
                        "status,country,"
                        "regionName,city,isp,"
                        "org,proxy,hosting",

                    "lang":
                        "en",
                },
            ) as resp:

                data = await resp.json(
                    content_type=None
                )

        if data.get(
            "status"
        ) == "success":

            place = ", ".join(
                x
                for x in (
                    data.get(
                        "country"
                    ),
                    data.get(
                        "city"
                    ),
                )
                if x
            )

            provider = (
                data.get(
                    "isp"
                )
                or data.get(
                    "org"
                )
                or ""
            )

            result = (
                "🌍 "
                + esc(
                    place
                    or "?"
                )
            )

            if provider:

                result += (
                    " · "
                    + esc(
                        provider
                    )
                )

            if (
                data.get(
                    "hosting"
                )
                or data.get(
                    "proxy"
                )
            ):

                result += (
                    "\n🕵️ hosting / "
                    "VPN / proxy"
                )

    except Exception as e:

        log.debug(
            "geo error %s: %s",
            ip,
            e
        )

        return ""

    if len(
        GEO_CACHE
    ) > 500:

        GEO_CACHE.clear()

    GEO_CACHE[ip] = result

    return result


# ============================================================
# KEYBOARDS
# ============================================================

def btn(
    text,
    data
) -> InlineKeyboardButton:

    return InlineKeyboardButton(
        text=text,
        callback_data=data
    )


def kb(rows) -> InlineKeyboardMarkup:

    return InlineKeyboardMarkup(
        inline_keyboard=rows
    )


BACK_ROW = [
    btn(
        "⬅️ Menu",
        "m"
    )
]


# ============================================================
# VIEWS
# ============================================================

def view_menu():

    cfg = load_config()

    blocks = load_blocks()

    text = (
        "🛡 <b>ServerGuard</b>\n\n"
        f"SSH protection: "
        f"{'✅ enabled' if cfg['enabled'] else '❌ disabled'}\n"
        f"Active blocks: "
        f"<b>{len(blocks)}</b>\n\n"
        "Choose an action:"
    )

    markup = kb([
        [
            btn(
                "📊 Status",
                "st"
            ),
            btn(
                "🚫 Blocks",
                "bp:0"
            ),
        ],
        [
            btn(
                "📜 Events",
                "ev:all"
            ),
            btn(
                "🔑 Logins",
                "ev:success"
            ),
        ],
        [
            btn(
                "🏴‍☠️ Top attackers",
                "tp:24"
            ),
            btn(
                "🖥 Server",
                "sv"
            ),
        ],
        [
            btn(
                "🛡 Protection",
                "pr"
            ),
            btn(
                "✅ Whitelist",
                "wl"
            ),
        ],
        [
            btn(
                "🔔 Notifications",
                "nt"
            ),
            btn(
                "🧾 SSH logs",
                "lg"
            ),
        ],
    ])

    return (
        text,
        markup
    )


def view_status():

    cfg = load_config()

    blocks = load_blocks()

    stats = load_stats()

    events = load_events()

    cutoff = (
        time.time()
        - 86400
    )

    failed24 = [
        e
        for e in events
        if (
            e.get("type")
            == "failed"
            and ev_time(e)
            >= cutoff
        )
    ]

    success24 = [
        e
        for e in events
        if (
            e.get("type")
            == "success"
            and ev_time(e)
            >= cutoff
        )
    ]

    attackers24 = {
        e.get("ip")
        for e in failed24
    }

    block_type = (
        "permanent"
        if cfg["permanent"]
        else fmt_dur(
            cfg["duration"]
        )
    )

    permanent_count = sum(
        1
        for r in blocks.values()
        if r.get(
            "permanent"
        )
    )

    text = (
        "📊 <b>ServerGuard status</b>\n\n"
        f"Protection: "
        f"{'✅ ON' if cfg['enabled'] else '❌ OFF'}\n"
        f"Threshold: "
        f"<b>{cfg['attempts']}</b> attempts → "
        f"block <b>{block_type}</b>\n"
        f"Whitelist: "
        f"{len(cfg['whitelist'])} IP(s)\n\n"
        f"🚫 Active blocks: "
        f"<b>{len(blocks)}</b> "
        f"(permanent: {permanent_count})\n\n"
        "<b>Last 24 hours</b>\n"
        f"⚠️ Failed attempts: "
        f"<b>{len(failed24)}</b> "
        f"(unique IPs: "
        f"{len(attackers24)})\n"
        f"🔑 Successful logins: "
        f"<b>{len(success24)}</b>\n\n"
        "<b>All time</b>\n"
        f"⚠️ Failed: "
        f"{to_int(stats.get('failed'))}\n"
        f"🔑 Successful: "
        f"{to_int(stats.get('success'))}\n"
        f"🚫 Blocks: "
        f"{to_int(stats.get('blocked'))}\n"
        f"✅ Unblocks: "
        f"{to_int(stats.get('unblocked'))}"
    )

    markup = kb([
        [
            btn(
                "🔄 Refresh",
                "st"
            ),
            btn(
                "🚫 Blocks",
                "bp:0"
            ),
        ],
        BACK_ROW,
    ])

    return (
        text,
        markup
    )


def view_blocks(
    page=0
):

    blocks = load_blocks()

    items = sorted(
        blocks.items(),
        key=lambda kv:
            to_int(
                kv[1].get(
                    "blocked_at"
                ),
                0
            ),
        reverse=True
    )

    total = len(
        items
    )

    pages = max(
        1,
        math.ceil(
            total
            / BLOCKS_PER_PAGE
        )
    )

    page = max(
        0,
        min(
            page,
            pages - 1
        )
    )

    chunk = items[
        page * BLOCKS_PER_PAGE:
        (page + 1)
        * BLOCKS_PER_PAGE
    ]

    now = time.time()

    lines = [
        f"🚫 <b>Active blocks</b> "
        f"({total})"
    ]

    if pages > 1:

        lines[0] += (
            f" · page "
            f"{page + 1}/{pages}"
        )

    lines.append("")

    if not chunk:

        lines.append(
            "No blocked IPs right now 🎉"
        )

    for ip, rec in chunk:

        if rec.get(
            "permanent"
        ):

            left = (
                "♾ permanent"
            )

        else:

            exp = to_int(
                rec.get(
                    "expires_at"
                ),
                0
            )

            left = (
                fmt_dur(
                    max(
                        0,
                        exp - now
                    )
                )
                + " left"
            )

        lines.append(
            f"• <code>{esc(ip)}</code> "
            f"— {left}\n"
            f"   attempts: "
            f"{to_int(rec.get('failed_attempts'))} "
            f"· since "
            f"{fmt_ts(rec.get('blocked_at'))}"
        )

    rows = []

    pair = []

    for ip, _ in chunk:

        pair.append(
            btn(
                f"🔓 {ip}",
                f"ub:{ip}"
            )
        )

        if len(pair) == 2:

            rows.append(
                pair
            )

            pair = []

    if pair:

        rows.append(
            pair
        )

    nav = []

    if page > 0:

        nav.append(
            btn(
                "◀️",
                f"bp:{page - 1}"
            )
        )

    nav.append(
        btn(
            "🔄",
            f"bp:{page}"
        )
    )

    if page < pages - 1:

        nav.append(
            btn(
                "▶️",
                f"bp:{page + 1}"
            )
        )

    rows.append(
        nav
    )

    if total:

        rows.append([
            btn(
                "🔓 Unblock all",
                "ua"
            )
        ])

    rows.append(
        BACK_ROW
    )

    return (
        "\n".join(lines),
        kb(rows)
    )


def view_unblock_all_confirm():

    total = len(
        load_blocks()
    )

    text = (
        "⚠️ Remove the block from "
        f"all IPs (<b>{total}</b>)?"
    )

    return (
        text,
        kb([
            [
                btn(
                    "✅ Yes, unblock all",
                    "uay"
                ),
                btn(
                    "❌ Cancel",
                    "bp:0"
                ),
            ]
        ])
    )


def view_events(
    kind="all"
):

    events = load_events()

    if kind in (
        "failed",
        "success"
    ):

        events = [
            e
            for e in events
            if e.get(
                "type"
            ) == kind
        ]

    last = events[
        -MAX_LIST_LINES:
    ][::-1]

    titles = {
        "all":
            "Recent events",

        "failed":
            "Failed attempts",

        "success":
            "Successful logins",
    }

    lines = [
        f"📜 <b>{titles.get(kind, 'Events')}</b> "
        "(server time)",
        "",
    ]

    if not last:

        lines.append(
            "Nothing here yet."
        )

    for e in last:

        ip = esc(
            e.get(
                "ip",
                "?"
            )
        )

        user = esc(
            e.get(
                "username",
                "?"
            )
        )

        if e.get(
            "type"
        ) == "success":

            method = esc(
                e.get(
                    "auth_method",
                    ""
                )
            )

            lines.append(
                f"🟢 "
                f"{fmt_ts(e.get('time'))} "
                f"<b>{user}</b> ← "
                f"<code>{ip}</code> "
                f"({method})"
            )

        else:

            lines.append(
                f"🔴 "
                f"{fmt_ts(e.get('time'))} "
                f"<b>{user}</b> ← "
                f"<code>{ip}</code>"
            )

    markup = kb([
        [
            btn(
                "All",
                "ev:all"
            ),
            btn(
                "🔴 Failed",
                "ev:failed"
            ),
            btn(
                "🟢 Success",
                "ev:success"
            ),
        ],
        [
            btn(
                "🔄 Refresh",
                f"ev:{kind}"
            )
        ],
        BACK_ROW,
    ])

    return (
        "\n".join(lines),
        markup
    )


def view_top(
    hours=24
):

    hours = (
        168
        if hours >= 168
        else 24
    )

    cutoff = (
        time.time()
        - hours * 3600
    )

    failed = [
        e
        for e in load_events()
        if (
            e.get("type")
            == "failed"
            and ev_time(e)
            >= cutoff
        )
    ]

    blocks = load_blocks()

    ips = Counter(
        e.get(
            "ip",
            "?"
        )
        for e in failed
    )

    users = Counter(
        e.get(
            "username",
            "?"
        )
        for e in failed
    )

    label = (
        "24 hours"
        if hours == 24
        else "7 days"
    )

    lines = [
        f"🏴‍☠️ <b>Top attackers, "
        f"last {label}</b>",
        "",
    ]

    if not ips:

        lines.append(
            "No attacks recorded ✅"
        )

    else:

        lines.append(
            f"Total attempts: "
            f"<b>{len(failed)}</b> "
            f"from <b>{len(ips)}</b> IP(s)\n"
        )

        for ip, count in ips.most_common(
            10
        ):

            tried = Counter(
                e.get(
                    "username",
                    "?"
                )
                for e in failed
                if e.get(
                    "ip"
                ) == ip
            )

            names = ", ".join(
                esc(n)
                for n, _
                in tried.most_common(3)
            )

            flag = (
                "🚫"
                if ip in blocks
                else "▫️"
            )

            lines.append(
                f"{flag} "
                f"<code>{esc(ip)}</code> "
                f"— <b>{count}</b> "
                f"({names})"
            )

        lines.append(
            "\n<b>Most tried usernames:</b>"
        )

        lines.append(
            ", ".join(
                f"{esc(u)} ×{c}"
                for u, c
                in users.most_common(8)
            )
        )

    other = (
        168
        if hours == 24
        else 24
    )

    rows = []

    top_ips = [
        ip
        for ip, _
        in ips.most_common(6)
    ]

    pair = []

    for ip in top_ips:

        pair.append(
            btn(
                f"🔎 {ip}",
                f"ip:{ip}"
            )
        )

        if len(pair) == 2:

            rows.append(
                pair
            )

            pair = []

    if pair:

        rows.append(
            pair
        )

    rows.append([
        btn(
            "7 days"
            if hours == 24
            else "24 hours",
            f"tp:{other}"
        ),
        btn(
            "🔄",
            f"tp:{hours}"
        ),
    ])

    rows.append(
        BACK_ROW
    )

    return (
        "\n".join(lines),
        kb(rows)
    )


def server_info() -> str:

    lines = [
        "🖥 <b>Server</b>",
        "",
    ]

    try:

        lines.append(
            f"Host: "
            f"<code>{esc(socket.gethostname())}</code>"
        )

    except Exception:

        pass

    try:

        with open(
            "/proc/uptime"
        ) as f:

            seconds = float(
                f.read().split()[0]
            )

        lines.append(
            f"Uptime: "
            f"{fmt_dur(seconds)}"
        )

    except Exception:

        pass

    try:

        l1, l5, l15 = (
            os.getloadavg()
        )

        lines.append(
            f"Load: "
            f"{l1:.2f} / "
            f"{l5:.2f} / "
            f"{l15:.2f} "
            f"(cores: "
            f"{os.cpu_count()})"
        )

    except Exception:

        pass

    try:

        mem = {}

        with open(
            "/proc/meminfo"
        ) as f:

            for line in f:

                key, _, val = (
                    line.partition(":")
                )

                mem[key] = (
                    int(
                        val.split()[0]
                    )
                    * 1024
                )

        total = mem[
            "MemTotal"
        ]

        avail = mem.get(
            "MemAvailable",
            mem.get(
                "MemFree",
                0
            )
        )

        used = (
            total - avail
        )

        lines.append(
            f"RAM: "
            f"{used / 2**30:.2f} / "
            f"{total / 2**30:.2f} GB "
            f"({used * 100 // total}%)"
        )

    except Exception:

        pass

    try:

        usage = shutil.disk_usage(
            "/"
        )

        lines.append(
            f"Disk /: "
            f"{usage.used / 2**30:.1f} / "
            f"{usage.total / 2**30:.1f} GB "
            f"({usage.used * 100 // usage.total}%)"
        )

    except Exception:

        pass

    lines.append(
        f"Server time: "
        f"{datetime.now().strftime('%d.%m.%Y %H:%M:%S')}"
    )

    return "\n".join(
        lines
    )


def view_server():

    return (
        server_info(),
        kb([
            [
                btn(
                    "🔄 Refresh",
                    "sv"
                )
            ],
            BACK_ROW,
        ])
    )


async def view_logs():

    rc, out = await run_cmd(
        "journalctl",
        "-u",
        "ssh",
        "-u",
        "sshd",
        "-n",
        "25",
        "--no-pager",
        "-o",
        "short-iso"
    )

    out = out.strip()

    if (
        rc != 0
        or not out
    ):

        body = (
            out
            or "Logs are not available."
        )

    else:

        body = out[
            -3400:
        ]

    text = (
        "🧾 <b>SSH logs "
        "(latest lines)</b>\n"
        "<pre>"
        + esc(body)
        + "</pre>"
    )

    return (
        text,
        kb([
            [
                btn(
                    "🔄 Refresh",
                    "lg"
                )
            ],
            BACK_ROW,
        ])
    )


def view_protection():

    cfg = load_config()

    block_type = (
        "♾ permanent"
        if cfg["permanent"]
        else fmt_dur(
            cfg["duration"]
        )
    )

    text = (
        "🛡 <b>SSH protection</b>\n\n"
        f"Status: "
        f"{'✅ ON' if cfg['enabled'] else '❌ OFF'}\n"
        f"Threshold: "
        f"<b>{cfg['attempts']}</b> "
        f"failed attempts\n"
        f"Block duration: "
        f"<b>{block_type}</b>\n"
        f"Whitelist: "
        f"{len(cfg['whitelist'])} IP(s)\n\n"
        "<i>The guard applies changes "
        "within about 5 seconds.</i>"
    )

    attempts_row = [
        btn(
            f"● {n}"
            if cfg["attempts"] == n
            else str(n),
            f"pr:at:{n}"
        )
        for n in (
            3,
            5,
            10,
            20
        )
    ]

    durations = (
        (600, "10m"),
        (3600, "1h"),
        (21600, "6h"),
        (86400, "24h"),
        (604800, "7d"),
    )

    duration_row = [
        btn(
            f"● {label}"
            if (
                cfg["duration"] == sec
                and not cfg["permanent"]
            )
            else label,
            f"pr:du:{sec}"
        )
        for sec, label
        in durations
    ]

    markup = kb([
        [
            btn(
                "❌ Disable protection"
                if cfg["enabled"]
                else "✅ Enable protection",
                "pr:en"
            )
        ],
        [
            btn(
                "Attempts:",
                "noop"
            )
        ]
        + attempts_row,

        [
            btn(
                "Duration:",
                "noop"
            )
        ]
        + duration_row,

        [
            btn(
                "♾ Permanent: "
                + (
                    "ON"
                    if cfg["permanent"]
                    else "OFF"
                ),
                "pr:pm"
            )
        ],

        BACK_ROW,
    ])

    return (
        text,
        markup
    )


def view_whitelist():

    cfg = load_config()

    wl = cfg[
        "whitelist"
    ]

    lines = [
        "✅ <b>Whitelist</b>",
        "",
    ]

    if not wl:

        lines.append(
            "The list is empty."
        )

    for ip in wl:

        lines.append(
            f"• <code>{esc(ip)}</code>"
        )

    lines.append(
        "\nAdd: "
        "<code>/whitelist add 1.2.3.4</code>"
        "\nor just send an IP address "
        "to the bot."
    )

    rows = []

    pair = []

    for ip in wl[:20]:

        pair.append(
            btn(
                f"🗑 {ip}",
                f"wd:{ip}"
            )
        )

        if len(pair) == 2:

            rows.append(
                pair
            )

            pair = []

    if pair:

        rows.append(
            pair
        )

    rows.append(
        BACK_ROW
    )

    return (
        "\n".join(lines),
        kb(rows)
    )


def view_notify():

    s = settings()

    text = (
        "🔔 <b>Notifications</b>\n\n"
        "Tap to turn a notification "
        "on or off.\n"
        f"The daily report is sent at "
        f"<b>{to_int(s['report_hour']):02d}:00</b> "
        "(server time)."
    )

    rows = []

    for key, label in (
        NOTIFY_LABELS.items()
    ):

        rows.append([
            btn(
                f"{'✅' if s.get(key) else '❌'} "
                f"{label}",
                f"nt:{key}"
            )
        ])

    hour_row = [
        btn(
            "🕘 Report at:",
            "noop"
        )
    ]

    for h in (
        6,
        9,
        18,
        22
    ):

        hour_row.append(
            btn(
                f"● {h}"
                if to_int(
                    s["report_hour"]
                ) == h
                else str(h),
                f"nt:hr:{h}"
            )
        )

    rows.append(
        hour_row
    )

    rows.append(
        BACK_ROW
    )

    return (
        text,
        kb(rows)
    )


async def view_ip(
    ip: str
):

    geo = await geo_lookup(
        ip,
        force=True
    )

    blocks = load_blocks()

    cfg = load_config()

    rec = blocks.get(
        ip
    )

    in_wl = (
        ip
        in cfg["whitelist"]
    )

    cutoff = (
        time.time()
        - 7 * 86400
    )

    events = [
        e
        for e in load_events()
        if (
            e.get("ip") == ip
            and ev_time(e)
            >= cutoff
        )
    ]

    failed = [
        e
        for e in events
        if e.get(
            "type"
        ) == "failed"
    ]

    success = [
        e
        for e in events
        if e.get(
            "type"
        ) == "success"
    ]

    users = Counter(
        e.get(
            "username",
            "?"
        )
        for e in failed
    )

    lines = [
        f"🔎 <b>IP</b> "
        f"<code>{esc(ip)}</code>",
        "",
    ]

    if geo:

        lines.append(
            geo
        )

    if rec:

        if rec.get(
            "permanent"
        ):

            lines.append(
                "Status: 🚫 blocked "
                "<b>permanently</b>"
            )

        else:

            left = max(
                0,
                to_int(
                    rec.get(
                        "expires_at"
                    )
                )
                - time.time()
            )

            lines.append(
                "Status: 🚫 blocked, "
                f"<b>{fmt_dur(left)}</b> "
                "left"
            )

    else:

        lines.append(
            "Status: not blocked"
        )

    lines.append(
        f"Whitelist: "
        f"{'✅ yes' if in_wl else 'no'}"
    )

    lines.append(
        f"\nLast 7 days: "
        f"🔴 {len(failed)} failed · "
        f"🟢 {len(success)} logins"
    )

    if events:

        lines.append(
            "Last activity: "
            f"{fmt_ts(max(ev_time(e) for e in events))}"
        )

    if users:

        lines.append(
            "Usernames: "
            + ", ".join(
                esc(u)
                for u, _
                in users.most_common(8)
            )
        )

    row1 = []

    row1.append(
        btn(
            "🔓 Unblock",
            f"ub:{ip}"
        )
        if rec
        else btn(
            "🚫 Block",
            f"bk:{ip}"
        )
    )

    row1.append(
        btn(
            "🗑 Remove from whitelist",
            f"wd:{ip}"
        )
        if in_wl
        else btn(
            "✅ Add to whitelist",
            f"wa:{ip}"
        )
    )

    markup = kb([
        row1,
        [
            btn(
                "🔄 Refresh",
                f"ip:{ip}"
            )
        ],
        BACK_ROW,
    ])

    return (
        "\n".join(lines),
        markup
    )


def build_report(
    hours=24
) -> str:

    now = time.time()

    cutoff = (
        now
        - hours * 3600
    )

    events = load_events()

    failed = [
        e
        for e in events
        if (
            e.get("type")
            == "failed"
            and ev_time(e)
            >= cutoff
        )
    ]

    success = [
        e
        for e in events
        if (
            e.get("type")
            == "success"
            and ev_time(e)
            >= cutoff
        )
    ]

    blocks = load_blocks()

    new_blocks = [
        r
        for r in blocks.values()
        if to_int(
            r.get(
                "blocked_at"
            )
        ) >= cutoff
    ]

    lines = [
        "📅 <b>ServerGuard report, "
        "last 24 hours</b>",
        "",
        f"⚠️ Failed attempts: "
        f"<b>{len(failed)}</b>",
        f"🌐 Unique attacking IPs: "
        f"<b>{len({e.get('ip') for e in failed})}</b>",
        f"🔑 Successful logins: "
        f"<b>{len(success)}</b>",
        f"🚫 New blocks "
        f"(still active): "
        f"<b>{len(new_blocks)}</b>",
        f"🚫 Total active blocks: "
        f"<b>{len(blocks)}</b>",
    ]

    top = Counter(
        e.get(
            "ip",
            "?"
        )
        for e in failed
    ).most_common(5)

    if top:

        lines.append(
            "\n<b>Top attackers:</b>"
        )

        for ip, count in top:

            lines.append(
                f"• <code>{esc(ip)}</code> "
                f"— {count}"
            )

    if success:

        ips = Counter(
            e.get(
                "ip",
                "?"
            )
            for e in success
        )

        lines.append(
            "\n<b>Logins:</b>"
        )

        for ip, count in ips.most_common(5):

            lines.append(
                f"• <code>{esc(ip)}</code> "
                f"×{count}"
            )

    return "\n".join(
        lines
    )


# ============================================================
# HELP
# ============================================================

HELP_TEXT = (
    "❓ <b>Commands</b>\n\n"

    "/menu — main menu\n"
    "/status — status and statistics\n"
    "/blocks — active blocks\n"
    "/events — recent events\n"
    "/top — top attackers\n"
    "/server — server status\n"

    "/ip <code>1.2.3.4</code> "
    "— IP information\n"

    "/block <code>1.2.3.4</code> "
    "[minutes | perm] — block an IP\n"

    "/unblock <code>1.2.3.4</code> "
    "— unblock an IP\n"

    "/whitelist "
    "[add|del <code>IP</code>] "
    "— manage the whitelist\n\n"

    "You can also just send an IP address "
    "— the bot will show a card with buttons.\n\n"

    "📥 <b>Message queue</b>\n"

    "Any script on the server can drop a "
    "<code>.txt</code> or <code>.json</code> "
    "file into "

    f"<code>{esc(QUEUE_DIR)}</code> "

    "(<code>{\"text\": \"...\"}</code>) "
    "and the bot will deliver it to you."
)


# ============================================================
# RENDER
# ============================================================

async def render(
    target,
    text: str,
    markup=None
):

    if isinstance(
        target,
        CallbackQuery
    ):

        try:

            await target.message.edit_text(
                text,
                reply_markup=markup
            )

        except TelegramBadRequest as e:

            if (
                "not modified"
                not in str(e).lower()
            ):

                await target.message.answer(
                    text,
                    reply_markup=markup
                )

    else:

        await target.answer(
            text,
            reply_markup=markup
        )


async def notify(
    bot: Bot,
    text: str,
    markup=None
) -> bool:

    chat_id = OWNER.get(
        "chat_id"
    )

    if not chat_id:

        return False

    try:

        await bot.send_message(
            chat_id,
            text[:4000],
            reply_markup=markup
        )

        return True

    except TelegramAPIError as e:

        log.warning(
            "Cannot send notification: %s",
            e
        )

        return False


# ============================================================
# ACCESS
# ============================================================

class AccessMiddleware(
    BaseMiddleware
):

    async def __call__(
        self,
        handler,
        event,
        data
    ):

        if isinstance(
            event,
            Message
        ):

            user = event.from_user

            if (
                user is None
                or event.chat.type
                != "private"
            ):

                return None

            if is_owner(
                user.id
            ):

                return await handler(
                    event,
                    data
                )

            if (
                event.text or ""
            ).startswith(
                "/start"
            ):

                return await handler(
                    event,
                    data
                )

            return None

        if isinstance(
            event,
            CallbackQuery
        ):

            if is_owner(
                event.from_user.id
            ):

                return await handler(
                    event,
                    data
                )

            try:

                await event.answer(
                    "⛔ Access denied",
                    show_alert=True
                )

            except TelegramAPIError:

                pass

            return None

        return await handler(
            event,
            data
        )


router.message.outer_middleware(
    AccessMiddleware()
)

router.callback_query.outer_middleware(
    AccessMiddleware()
)


# ============================================================
# REGISTRATION
# ============================================================

def reg_wait_seconds(
    user_id: int
) -> int:

    now = time.time()

    mine = [
        t
        for t in USER_FAILS.get(
            user_id,
            []
        )
        if now - t < REG_WINDOW
    ]

    USER_FAILS[user_id] = mine

    while (
        GLOBAL_FAILS
        and now - GLOBAL_FAILS[0]
        >= REG_WINDOW
    ):

        GLOBAL_FAILS.popleft()

    if len(mine) >= REG_USER_LIMIT:

        return int(
            REG_WINDOW
            - (
                now - mine[0]
            )
        )

    if (
        len(GLOBAL_FAILS)
        >= REG_GLOBAL_LIMIT
    ):

        return int(
            REG_WINDOW
            - (
                now - GLOBAL_FAILS[0]
            )
        )

    return 0


def reg_register_fail(
    user_id: int
):

    now = time.time()

    USER_FAILS.setdefault(
        user_id,
        []
    ).append(
        now
    )

    GLOBAL_FAILS.append(
        now
    )


NOT_REGISTERED_TEXT = (
    "👋 This is the "
    "<b>ServerGuard</b> bot.\n\n"

    "To register:\n"

    "1. On the server open "
    "ServerGuard → Telegram bot → "
    "<b>Generate verification code</b>\n"

    "2. Send it here: "
    "<code>/start CODE</code>\n\n"

    "The code is valid for 5 minutes."
)


async def try_register(
    message: Message,
    code: str
):

    user = message.from_user

    wait = reg_wait_seconds(
        user.id
    )

    if wait:

        await message.answer(
            "⏳ Too many wrong attempts. "
            f"Try again in {fmt_dur(wait)}."
        )

        return

    ver = load_json(
        VERIFICATION_FILE,
        None
    )

    if (
        not isinstance(
            ver,
            dict
        )
        or not ver.get(
            "code"
        )
    ):

        await message.answer(
            "❌ There is no active code. "
            "Generate a new one on the server "
            "(Telegram bot → "
            "Generate verification code)."
        )

        return

    if (
        time.time()
        > to_int(
            ver.get(
                "expires_at"
            ),
            0
        )
    ):

        try:

            VERIFICATION_FILE.unlink()

        except Exception:

            pass

        await message.answer(
            "⌛ The code has expired. "
            "Generate a new one on the server."
        )

        return

    if not hmac.compare_digest(
        str(ver["code"]),
        code
    ):

        reg_register_fail(
            user.id
        )

        try:

            await message.delete()

        except TelegramAPIError:

            pass

        left = max(
            0,
            REG_USER_LIMIT
            - len(
                USER_FAILS.get(
                    user.id,
                    []
                )
            )
        )

        await message.answer(
            f"❌ Wrong code. "
            f"Attempts left: {left}"
        )

        return

    try:

        await message.delete()

    except TelegramAPIError:

        pass

    previous = dict(
        OWNER
    )

    new_owner = {

        "user_id":
            user.id,

        "chat_id":
            message.chat.id,

        "username":
            user.username or "",

        "first_name":
            user.full_name or "",

        "registered_at":
            int(
                time.time()
            ),

        "settings":
            previous.get(
                "settings",
                {}
            )
            if isinstance(
                previous.get(
                    "settings"
                ),
                dict
            )
            else {},

        "known_ips":
            previous.get(
                "known_ips",
                []
            )
            if isinstance(
                previous.get(
                    "known_ips"
                ),
                list
            )
            else [],
    }

    new_owner[
        "settings"
    ][
        "last_report"
    ] = datetime.now().strftime(
        "%Y-%m-%d"
    )

    OWNER.clear()

    OWNER.update(
        new_owner
    )

    save_owner()

    seed_known_ips()

    try:

        VERIFICATION_FILE.unlink()

    except Exception:

        pass

    if (
        previous.get(
            "chat_id"
        )
        and previous.get(
            "user_id"
        ) != user.id
    ):

        try:

            await message.bot.send_message(
                previous["chat_id"],
                "⚠️ Access to this bot "
                "has been transferred to another "
                "account (using a code from the server). "
                "You will no longer receive notifications."
            )

        except TelegramAPIError:

            pass

    log.info(
        "Owner registered: %s (%s)",
        user.id,
        user.username
    )

    await message.answer(
        "✅ <b>Registration complete!</b>\n\n"
        "You will now receive notifications "
        "about blocks, SSH logins, ports, "
        "network connections and services."
    )

    text, markup = view_menu()

    await message.answer(
        text,
        reply_markup=markup
    )


# ============================================================
# COMMAND HANDLERS
# ============================================================

@router.message(
    Command("start")
)
async def cmd_start(
    message: Message,
    command: CommandObject
):

    code = "".join(
        (
            command.args
            or ""
        ).split()
    )

    if not code:

        if is_owner(
            message.from_user.id
        ):

            text, markup = (
                view_menu()
            )

            await message.answer(
                text,
                reply_markup=markup
            )

        else:

            await message.answer(
                NOT_REGISTERED_TEXT
            )

        return

    await try_register(
        message,
        code
    )


@router.message(
    Command("menu")
)
async def cmd_menu(
    message: Message
):

    text, markup = view_menu()

    await message.answer(
        text,
        reply_markup=markup
    )


@router.message(
    Command("help")
)
async def cmd_help(
    message: Message
):

    await message.answer(
        HELP_TEXT,
        reply_markup=kb([
            BACK_ROW
        ])
    )


@router.message(
    Command("status")
)
async def cmd_status(
    message: Message
):

    text, markup = view_status()

    await message.answer(
        text,
        reply_markup=markup
    )


@router.message(
    Command("blocks")
)
async def cmd_blocks(
    message: Message
):

    text, markup = view_blocks(
        0
    )

    await message.answer(
        text,
        reply_markup=markup
    )


@router.message(
    Command("events")
)
async def cmd_events(
    message: Message
):

    text, markup = view_events(
        "all"
    )

    await message.answer(
        text,
        reply_markup=markup
    )


@router.message(
    Command("top")
)
async def cmd_top(
    message: Message
):

    text, markup = view_top(
        24
    )

    await message.answer(
        text,
        reply_markup=markup
    )


@router.message(
    Command("server")
)
async def cmd_server(
    message: Message
):

    text, markup = view_server()

    await message.answer(
        text,
        reply_markup=markup
    )


@router.message(
    Command("ip")
)
async def cmd_ip(
    message: Message,
    command: CommandObject
):

    ip = parse_ip(
        command.args or ""
    )

    if not ip:

        await message.answer(
            "Usage: "
            "<code>/ip 1.2.3.4</code>"
        )

        return

    text, markup = await view_ip(
        ip
    )

    await message.answer(
        text,
        reply_markup=markup
    )


@router.message(
    Command("block")
)
async def cmd_block(
    message: Message,
    command: CommandObject
):

    parts = (
        command.args or ""
    ).split()

    if not parts:

        await message.answer(
            "Usage:\n"
            "<code>/block 1.2.3.4</code> "
            "— using protection settings\n"
            "<code>/block 1.2.3.4 60</code> "
            "— for 60 minutes\n"
            "<code>/block 1.2.3.4 perm</code> "
            "— permanently"
        )

        return

    ip = parse_ip(
        parts[0]
    )

    if not ip:

        await message.answer(
            "❌ Invalid IP address."
        )

        return

    cfg = load_config()

    permanent = cfg[
        "permanent"
    ]

    duration = cfg[
        "duration"
    ]

    if len(parts) > 1:

        arg = parts[1].lower()

        if arg in (
            "perm",
            "permanent",
            "forever"
        ):

            permanent = True

        else:

            minutes = to_int(
                arg,
                0
            )

            if minutes <= 0:

                await message.answer(
                    "❌ Specify the duration "
                    "in minutes or "
                    "<code>perm</code>."
                )

                return

            permanent = False

            duration = (
                minutes * 60
            )

    ok, info = await do_block(
        ip,
        permanent,
        duration,
        "Manual block via Telegram"
    )

    if ok:

        term = (
            "permanently"
            if permanent
            else
            "for "
            + fmt_dur(
                max(
                    60,
                    duration
                )
            )
        )

        await message.answer(
            f"🚫 <code>{esc(ip)}</code> "
            f"blocked {term}."
        )

    else:

        await message.answer(
            f"❌ Failed: "
            f"{esc(info)}"
        )


@router.message(
    Command("unblock")
)
async def cmd_unblock(
    message: Message,
    command: CommandObject
):

    ip = parse_ip(
        command.args or ""
    )

    if not ip:

        await message.answer(
            "Usage: "
            "<code>/unblock 1.2.3.4</code>"
        )

        return

    ok, info = await do_unblock(
        ip
    )

    if ok:

        await message.answer(
            f"✅ <code>{esc(ip)}</code> "
            "unblocked."
        )

    else:

        await message.answer(
            f"❌ Failed: "
            f"{esc(info)}"
        )


@router.message(
    Command("whitelist")
)
async def cmd_whitelist(
    message: Message,
    command: CommandObject
):

    parts = (
        command.args or ""
    ).split()

    if not parts:

        text, markup = (
            view_whitelist()
        )

        await message.answer(
            text,
            reply_markup=markup
        )

        return

    action = parts[0].lower()

    ip = (
        parse_ip(
            parts[1]
        )
        if len(parts) > 1
        else None
    )

    if (
        action
        not in (
            "add",
            "del",
            "remove",
            "rm"
        )
        or not ip
    ):

        await message.answer(
            "Usage:\n"
            "<code>/whitelist add 1.2.3.4</code>\n"
            "<code>/whitelist del 1.2.3.4</code>"
        )

        return

    if action == "add":

        added = whitelist_add(
            ip
        )

        blocked = (
            ip in load_blocks()
        )

        if blocked:

            await do_unblock(
                ip
            )

        await message.answer(
            f"✅ <code>{esc(ip)}</code> "
            + (
                "added to the whitelist."
                if added
                else
                "is already in the whitelist."
            )
            + (
                " Block removed."
                if blocked
                else ""
            )
        )

    else:

        removed = whitelist_remove(
            ip
        )

        await message.answer(
            f"🗑 <code>{esc(ip)}</code> "
            + (
                "removed from the whitelist."
                if removed
                else
                "was not found in the whitelist."
            )
        )


@router.message(
    F.text
)
async def on_text(
    message: Message
):

    ip = parse_ip(
        message.text or ""
    )

    if ip:

        text, markup = await view_ip(
            ip
        )

        await message.answer(
            text,
            reply_markup=markup
        )

        return

    await message.answer(
        "I didn't get that 🤔 "
        "Open /menu or /help."
    )


# ============================================================
# CALLBACKS
# ============================================================

def info_only_markup(
    ip: str
) -> InlineKeyboardMarkup:

    return kb([
        [
            btn(
                "🔎 Info",
                f"ip:{ip}"
            )
        ]
    ])


async def refresh_after(
    cb: CallbackQuery,
    ip: str
):

    head = (
        cb.message.text
        or ""
    )

    if head.startswith(
        "🚫 Active blocks"
    ):

        text, markup = (
            view_blocks(0)
        )

        await render(
            cb,
            text,
            markup
        )

    elif head.startswith(
        "🔎"
    ):

        text, markup = (
            await view_ip(ip)
        )

        await render(
            cb,
            text,
            markup
        )

    elif head.startswith(
        "✅ Whitelist"
    ):

        text, markup = (
            view_whitelist()
        )

        await render(
            cb,
            text,
            markup
        )

    else:

        try:

            await cb.message.edit_reply_markup(
                reply_markup=info_only_markup(
                    ip
                )
            )

        except TelegramAPIError:

            pass


async def handle_callback(
    cb: CallbackQuery
):

    action, _, arg = (
        cb.data or ""
    ).partition(":")

    if action == "noop":

        return None

    if action == "m":

        await render(
            cb,
            *view_menu()
        )

    elif action == "st":

        await render(
            cb,
            *view_status()
        )

    elif action == "bp":

        await render(
            cb,
            *view_blocks(
                to_int(
                    arg,
                    0
                )
            )
        )

    elif action == "ev":

        await render(
            cb,
            *view_events(
                arg
                if arg
                in (
                    "all",
                    "failed",
                    "success"
                )
                else "all"
            )
        )

    elif action == "tp":

        await render(
            cb,
            *view_top(
                to_int(
                    arg,
                    24
                )
            )
        )

    elif action == "sv":

        await render(
            cb,
            *view_server()
        )

    elif action == "lg":

        text, markup = (
            await view_logs()
        )

        await render(
            cb,
            text,
            markup
        )

    elif action == "pr":

        sub, _, val = (
            arg.partition(":")
        )

        cfg = load_config()

        if sub == "en":

            update_protection({
                "enabled":
                    not cfg[
                        "enabled"
                    ]
            })

        elif sub == "pm":

            update_protection({
                "permanent":
                    not cfg[
                        "permanent"
                    ]
            })

        elif sub == "at":

            update_protection({
                "attempts":
                    max(
                        1,
                        min(
                            to_int(
                                val,
                                5
                            ),
                            100
                        )
                    )
            })

        elif sub == "du":

            update_protection({
                "duration":
                    max(
                        60,
                        to_int(
                            val,
                            600
                        )
                    ),
                "permanent":
                    False,
            })

        await render(
            cb,
            *view_protection()
        )

    elif action == "wl":

        await render(
            cb,
            *view_whitelist()
        )

    elif action == "wa":

        ip = parse_ip(
            arg
        )

        if not ip:

            return "Invalid IP address"

        added = whitelist_add(
            ip
        )

        if ip in load_blocks():

            await do_unblock(
                ip
            )

        await refresh_after(
            cb,
            ip
        )

        return (
            "✅ Added to the whitelist"
            if added
            else
            "Already in the whitelist"
        )

    elif action == "wd":

        ip = parse_ip(
            arg
        )

        if not ip:

            return "Invalid IP address"

        removed = whitelist_remove(
            ip
        )

        await refresh_after(
            cb,
            ip
        )

        return (
            "🗑 Removed from the whitelist"
            if removed
            else
            "Not found"
        )

    elif action == "nt":

        if arg.startswith(
            "hr:"
        ):

            hour = max(
                0,
                min(
                    to_int(
                        arg[3:],
                        9
                    ),
                    23
                )
            )

            set_setting(
                "report_hour",
                hour
            )

        elif arg in NOTIFY_LABELS:

            set_setting(
                arg,
                not settings().get(
                    arg,
                    False
                )
            )

        await render(
            cb,
            *view_notify()
        )

    elif action == "ip":

        ip = parse_ip(
            arg
        )

        if not ip:

            return "Invalid IP address"

        text, markup = (
            await view_ip(ip)
        )

        await render(
            cb,
            text,
            markup
        )

    elif action == "ub":

        ip = parse_ip(
            arg
        )

        if not ip:

            return "Invalid IP address"

        ok, info = await do_unblock(
            ip
        )

        if not ok:

            return (
                "❌ "
                + info[:150]
            )

        await refresh_after(
            cb,
            ip
        )

        return "✅ Unblocked"

    elif action == "bk":

        ip = parse_ip(
            arg
        )

        if not ip:

            return "Invalid IP address"

        cfg = load_config()

        ok, info = await do_block(
            ip,
            cfg["permanent"],
            cfg["duration"],
            "Manual block via Telegram"
        )

        if not ok:

            return (
                "❌ "
                + info[:150]
            )

        await refresh_after(
            cb,
            ip
        )

        return "🚫 Blocked"

    elif action == "ua":

        await render(
            cb,
            *view_unblock_all_confirm()
        )

    elif action == "uay":

        blocks = list(
            load_blocks().keys()
        )

        done = 0

        for ip in blocks:

            ok, _ = await do_unblock(
                ip
            )

            done += (
                1
                if ok
                else 0
            )

        await render(
            cb,
            *view_blocks(0)
        )

        return (
            f"✅ Unblocked: "
            f"{done}/{len(blocks)}"
        )

    return None


@router.callback_query()
async def on_callback(
    cb: CallbackQuery
):

    toast = None

    if cb.message is None:

        try:

            await cb.answer()

        except TelegramAPIError:

            pass

        return

    try:

        toast = await handle_callback(
            cb
        )

    except Exception as e:

        log.exception(
            "Callback error: %s",
            e
        )

        toast = (
            "Error, check the logs"
        )

    try:

        await cb.answer(
            toast or ""
        )

    except TelegramAPIError:

        pass


# ============================================================
# BRUTE FORCE WATCHER
# ============================================================

def event_key(
    e: dict
) -> str:

    return "|".join(
        str(
            e.get(
                k,
                ""
            )
        )
        for k in (
            "time",
            "type",
            "ip",
            "username",
            "raw"
        )
    )


class Watcher:

    def __init__(
        self,
        bot: Bot
    ):

        self.bot = bot

        self.events_mtime = (
            mtime_ns(
                EVENTS_FILE
            )
        )

        self.blocks_mtime = (
            mtime_ns(
                BLOCKS_FILE
            )
        )

        self.seen = Counter(
            event_key(e)
            for e in load_events()
        )

        self.prev_blocks = (
            load_blocks()
        )

    async def run(
        self
    ):

        while True:

            await asyncio.sleep(
                POLL_INTERVAL
            )

            try:

                await self.check_blocks()

                await self.check_events()

            except Exception as e:

                log.exception(
                    "Watcher error: %s",
                    e
                )

    async def check_blocks(
        self
    ):

        current_mtime = (
            mtime_ns(
                BLOCKS_FILE
            )
        )

        if (
            current_mtime
            == self.blocks_mtime
        ):

            return

        self.blocks_mtime = (
            current_mtime
        )

        current = load_blocks()

        previous = self.prev_blocks

        self.prev_blocks = current

        s = settings()

        for ip, rec in current.items():

            old = previous.get(
                ip
            )

            stamp = rec.get(
                "blocked_at"
            )

            if (
                old is not None
                and old.get(
                    "blocked_at"
                ) == stamp
            ):

                continue

            if (
                ip,
                stamp
            ) in SUPPRESS_BLOCK:

                SUPPRESS_BLOCK.discard(
                    (
                        ip,
                        stamp
                    )
                )

                continue

            if not (
                OWNER
                and s.get(
                    "notify_block"
                )
            ):

                continue

            await self.send_block(
                ip,
                rec
            )

        for ip, rec in previous.items():

            if ip in current:

                continue

            if ip in SUPPRESS_UNBLOCK:

                SUPPRESS_UNBLOCK.discard(
                    ip
                )

                continue

            if not (
                OWNER
                and s.get(
                    "notify_unblock"
                )
            ):

                continue

            expired = (
                not rec.get(
                    "permanent"
                )
                and to_int(
                    rec.get(
                        "expires_at"
                    ),
                    0
                )
                <= time.time()
                + POLL_INTERVAL
            )

            reason = (
                "the block has expired"
                if expired
                else
                "removed manually on the server"
            )

            await notify(
                self.bot,
                f"✅ <b>IP unblocked</b>\n"
                f"<code>{esc(ip)}</code>\n"
                f"Reason: {reason}",
                info_only_markup(ip)
            )

    async def send_block(
        self,
        ip: str,
        rec: dict
    ):

        geo = await geo_lookup(
            ip
        )

        term = block_term(
            rec
        )

        lines = [
            "🚫 <b>IP blocked</b>",
            "",
            f"🌐 <code>{esc(ip)}</code>",
        ]

        if geo:

            lines.append(
                geo
            )

        lines.append(
            f"⚠️ Failed attempts: "
            f"<b>{to_int(rec.get('failed_attempts'))}</b>"
        )

        lines.append(
            f"⏱ Duration: "
            f"<b>{term}</b>"
        )

        if (
            not rec.get(
                "permanent"
            )
            and rec.get(
                "expires_at"
            )
        ):

            lines.append(
                f"🕒 Until: "
                f"{fmt_ts(rec.get('expires_at'))}"
            )

        if rec.get(
            "reason"
        ):

            lines.append(
                f"📝 "
                f"{esc(rec.get('reason'))}"
            )

        markup = kb([
            [
                btn(
                    "🔓 Unblock",
                    f"ub:{ip}"
                ),
                btn(
                    "✅ Add to whitelist",
                    f"wa:{ip}"
                ),
            ],
            [
                btn(
                    "🔎 Info",
                    f"ip:{ip}"
                )
            ],
        ])

        await notify(
            self.bot,
            "\n".join(lines),
            markup
        )

    async def check_events(
        self
    ):

        current_mtime = (
            mtime_ns(
                EVENTS_FILE
            )
        )

        if (
            current_mtime
            == self.events_mtime
        ):

            return

        self.events_mtime = (
            current_mtime
        )

        events = load_events()

        remaining = Counter(
            self.seen
        )

        new = []

        for e in events:

            key = event_key(
                e
            )

            if remaining[key] > 0:

                remaining[key] -= 1

            else:

                new.append(
                    e
                )

        self.seen = Counter(
            event_key(e)
            for e in events
        )

        if (
            not new
            or not OWNER
        ):

            return

        s = settings()

        failed = [
            e
            for e in new
            if e.get(
                "type"
            ) == "failed"
        ]

        success = [
            e
            for e in new
            if e.get(
                "type"
            ) == "success"
        ]

        if (
            failed
            and s.get(
                "notify_failed"
            )
        ):

            await self.send_failed(
                failed
            )

        for e in success[:5]:

            await self.send_login(
                e,
                s
            )

        if len(success) > 5:

            await notify(
                self.bot,
                f"🔑 …and "
                f"{len(success) - 5} "
                f"more SSH logins."
            )

    async def send_failed(
        self,
        failed: list
    ):

        by_ip = {}

        for e in failed:

            by_ip.setdefault(
                e.get(
                    "ip",
                    "?"
                ),
                []
            ).append(e)

        lines = [
            "⚠️ <b>Failed SSH attempts</b>",
            "",
        ]

        for ip, items in list(
            by_ip.items()
        )[:10]:

            users = ", ".join(
                sorted({
                    esc(
                        i.get(
                            "username",
                            "?"
                        )
                    )
                    for i in items
                })[:4]
            )

            lines.append(
                f"<code>{esc(ip)}</code> "
                f"×{len(items)} "
                f"({users})"
            )

        await notify(
            self.bot,
            "\n".join(lines)
        )

    async def send_login(
        self,
        e: dict,
        s: dict
    ):

        ip = e.get(
            "ip",
            "?"
        )

        is_new = (
            ip not in known_ips()
        )

        if is_new:

            remember_ip(
                ip
            )

        if not (
            s.get(
                "notify_login"
            )
            or (
                is_new
                and s.get(
                    "notify_new_ip"
                )
            )
        ):

            return

        geo = await geo_lookup(
            ip
        )

        lines = [
            "🔑 <b>SSH login</b>",
            "",
            f"👤 <b>{esc(e.get('username', '?'))}</b>",
            f"🌐 <code>{esc(ip)}</code>",
        ]

        if geo:

            lines.append(
                geo
            )

        if e.get(
            "auth_method"
        ):

            lines.append(
                f"🔐 "
                f"{esc(e.get('auth_method'))}"
            )

        lines.append(
            f"🕒 "
            f"{fmt_ts(e.get('time'))}"
        )

        if is_new:

            lines.append(
                "\n🆕 <b>New IP</b> "
                "— no successful login from it before.\n"
                "If this wasn't you, block it!"
            )

        markup = kb([
            [
                btn(
                    "🚫 Block",
                    f"bk:{ip}"
                ),
                btn(
                    "✅ Add to whitelist",
                    f"wa:{ip}"
                ),
            ],
            [
                btn(
                    "🔎 Info",
                    f"ip:{ip}"
                )
            ],
        ])

        await notify(
            self.bot,
            "\n".join(lines),
            markup
        )


# ============================================================
# PORT & SERVICE MONITOR WATCHER
# ============================================================

class PortServiceWatcher:

    def __init__(
        self,
        bot: Bot
    ):

        self.bot = bot

        self.port_mtime = (
            mtime_ns(
                PORT_MONITOR_EVENTS_FILE
            )
        )

        self.network_mtime = (
            mtime_ns(
                NETWORK_MONITOR_EVENTS_FILE
            )
        )

        self.service_mtime = (
            mtime_ns(
                SERVICE_MONITOR_EVENTS_FILE
            )
        )

        self.seen_ports = Counter(
            monitor_event_key(event)
            for event in load_monitor_events(
                PORT_MONITOR_EVENTS_FILE
            )
        )

        self.seen_network = Counter(
            monitor_event_key(event)
            for event in load_monitor_events(
                NETWORK_MONITOR_EVENTS_FILE
            )
        )

        self.seen_services = Counter(
            monitor_event_key(event)
            for event in load_monitor_events(
                SERVICE_MONITOR_EVENTS_FILE
            )
        )

    async def run(
        self
    ):

        while True:

            await asyncio.sleep(
                POLL_INTERVAL
            )

            try:

                await self.check_ports()

                await self.check_network()

                await self.check_services()

            except Exception as e:

                log.exception(
                    "Port/service watcher error: %s",
                    e
                )

    def get_new_events(
        self,
        events: list,
        previous: Counter
    ):

        remaining = Counter(
            previous
        )

        new_events = []

        for event in events:

            key = monitor_event_key(
                event
            )

            if remaining[key] > 0:

                remaining[key] -= 1

            else:

                new_events.append(
                    event
                )

        return (
            new_events,
            Counter(
                monitor_event_key(event)
                for event in events
            )
        )

    # ========================================================
    # PORT EVENTS
    # ========================================================

    async def check_ports(
        self
    ):

        current_mtime = (
            mtime_ns(
                PORT_MONITOR_EVENTS_FILE
            )
        )

        if (
            current_mtime
            == self.port_mtime
        ):

            return

        self.port_mtime = (
            current_mtime
        )

        events = load_monitor_events(
            PORT_MONITOR_EVENTS_FILE
        )

        new_events, self.seen_ports = (
            self.get_new_events(
                events,
                self.seen_ports
            )
        )

        if not new_events:

            return

        if not OWNER:

            return

        if not settings().get(
            "notify_port",
            True
        ):

            return

        for event in new_events:

            event_type = (
                monitor_event_type(
                    event
                )
            )

            await self.send_port_event(
                event,
                event_type
            )

    async def send_port_event(
        self,
        event: dict,
        event_type: str
    ):

        if event_type == "new_port":

            title = (
                "🟢 <b>NEW LISTENING PORT</b>"
            )

            description = (
                "A new listening port "
                "was detected."
            )

        elif event_type == "port_closed":

            title = (
                "🔴 <b>PORT CLOSED</b>"
            )

            description = (
                "A listening port "
                "has disappeared."
            )

        elif (
            event_type
            == "port_process_changed"
        ):

            title = (
                "🔄 <b>PORT PROCESS CHANGED</b>"
            )

            description = (
                "The process/service using "
                "a port has changed."
            )

        else:

            title = (
                "🌐 <b>PORT MONITOR EVENT</b>"
            )

            description = (
                f"Event: "
                f"<code>{esc(event_type)}</code>"
            )

        lines = [
            title,
            "",
            description,
            "",
            format_monitor_port(
                event
            ),
            "",
            f"🕒 "
            f"{fmt_ts(monitor_event_time(event))}",
        ]

        await notify(
            self.bot,
            "\n".join(lines)
        )

    # ========================================================
    # NETWORK EVENTS
    # ========================================================

    async def check_network(
        self
    ):

        current_mtime = (
            mtime_ns(
                NETWORK_MONITOR_EVENTS_FILE
            )
        )

        if (
            current_mtime
            == self.network_mtime
        ):

            return

        self.network_mtime = (
            current_mtime
        )

        events = load_monitor_events(
            NETWORK_MONITOR_EVENTS_FILE
        )

        new_events, self.seen_network = (
            self.get_new_events(
                events,
                self.seen_network
            )
        )

        if not new_events:

            return

        if not OWNER:

            return

        if not settings().get(
            "notify_network",
            True
        ):

            return

        for event in new_events:

            event_type = (
                monitor_event_type(
                    event
                )
            )

            # =================================================
            # IMPORTANT:
            #
            # Only new incoming connections are sent.
            #
            # connection_closed:
            #     ignored
            #
            # LAST-ACK:
            #     ignored
            #
            # TIME-WAIT:
            #     ignored
            #
            # CLOSE-WAIT:
            #     ignored
            #
            # outgoing connections:
            #     ignored
            # =================================================

            if not should_send_network_event(
                event,
                event_type
            ):

                continue

            await self.send_network_event(
                event,
                event_type
            )

    async def send_network_event(
        self,
        event: dict,
        event_type: str
    ):

        # This function is intentionally only used
        # for events that passed should_send_network_event().

        title = (
            "🟢 <b>NEW INCOMING "
            "NETWORK CONNECTION</b>"
        )

        description = (
            "A new incoming network "
            "connection to the server "
            "was detected."
        )

        remote_ip = event_remote_host(
            event
        )

        lines = [
            title,
            "",
            description,
            "",
            format_monitor_connection(
                event
            ),
        ]

        if remote_ip:

            try:

                addr = ipaddress.ip_address(
                    remote_ip
                )

                if (
                    not addr.is_private
                    and not addr.is_loopback
                    and not addr.is_link_local
                ):

                    geo = await geo_lookup(
                        remote_ip
                    )

                    if geo:

                        lines.append(
                            geo
                        )

            except ValueError:

                pass

        lines.extend([
            "",
            f"🕒 "
            f"{fmt_ts(monitor_event_time(event))}",
        ])

        await notify(
            self.bot,
            "\n".join(lines)
        )

    # ========================================================
    # SERVICE EVENTS
    # ========================================================

    async def check_services(
        self
    ):

        current_mtime = (
            mtime_ns(
                SERVICE_MONITOR_EVENTS_FILE
            )
        )

        if (
            current_mtime
            == self.service_mtime
        ):

            return

        self.service_mtime = (
            current_mtime
        )

        events = load_monitor_events(
            SERVICE_MONITOR_EVENTS_FILE
        )

        new_events, self.seen_services = (
            self.get_new_events(
                events,
                self.seen_services
            )
        )

        if not new_events:

            return

        if not OWNER:

            return

        if not settings().get(
            "notify_service",
            True
        ):

            return

        for event in new_events:

            event_type = (
                monitor_event_type(
                    event
                )
            )

            await self.send_service_event(
                event,
                event_type
            )

    async def send_service_event(
        self,
        event: dict,
        event_type: str
    ):

        if event_type == "service_started":

            title = (
                "🟢 <b>SERVICE STARTED</b>"
            )

            description = (
                "A systemd service "
                "has started."
            )

        elif (
            event_type
            == "service_removed"
        ):

            title = (
                "🔴 <b>SERVICE STOPPED / REMOVED</b>"
            )

            description = (
                "A systemd service is "
                "no longer running."
            )

        elif (
            event_type
            == "service_changed"
        ):

            title = (
                "🔄 <b>SERVICE CHANGED</b>"
            )

            description = (
                "A systemd service changed "
                "its state."
            )

        else:

            title = (
                "🔧 <b>SERVICE MONITOR EVENT</b>"
            )

            description = (
                f"Event: "
                f"<code>{esc(event_type)}</code>"
            )

        lines = [
            title,
            "",
            description,
            "",
            format_monitor_service(
                event
            ),
            "",
            f"🕒 "
            f"{fmt_ts(monitor_event_time(event))}",
        ]

        await notify(
            self.bot,
            "\n".join(lines)
        )


# ============================================================
# QUEUE WORKER
# ============================================================

async def queue_worker(
    bot: Bot
):

    while True:

        await asyncio.sleep(
            QUEUE_INTERVAL
        )

        if not OWNER:

            continue

        try:

            files = sorted(
                p
                for p in QUEUE_DIR.glob("*")
                if (
                    p.is_file()
                    and p.suffix
                    in (
                        ".txt",
                        ".json"
                    )
                )
            )

        except Exception:

            continue

        for path in files:

            try:

                if (
                    time.time()
                    - path.stat().st_mtime
                    < 1
                ):

                    continue

                raw = path.read_text(
                    encoding="utf-8",
                    errors="replace"
                )

                use_html = False

                if path.suffix == ".json":

                    data = json.loads(
                        raw
                    )

                    if isinstance(
                        data,
                        dict
                    ):

                        text = str(
                            data.get(
                                "text",
                                ""
                            )
                        ).strip()

                        use_html = to_bool(
                            data.get(
                                "html",
                                False
                            )
                        )

                    else:

                        text = str(
                            data
                        ).strip()

                else:

                    text = raw.strip()

            except Exception as e:

                log.warning(
                    "Bad queue file %s: %s",
                    path,
                    e
                )

                try:

                    path.rename(
                        path.with_name(
                            path.name
                            + ".failed"
                        )
                    )

                except Exception:

                    pass

                continue

            if not text:

                path.unlink(
                    missing_ok=True
                )

                continue

            try:

                await bot.send_message(
                    OWNER["chat_id"],
                    text[:4000],
                    parse_mode=(
                        ParseMode.HTML
                        if use_html
                        else None
                    ),
                )

                path.unlink(
                    missing_ok=True
                )

            except TelegramAPIError as e:

                log.warning(
                    "Queue send failed "
                    "(%s): %s",
                    path.name,
                    e
                )

                break


# ============================================================
# DAILY REPORT
# ============================================================

async def report_worker(
    bot: Bot
):

    while True:

        await asyncio.sleep(
            30
        )

        try:

            if not OWNER:

                continue

            s = settings()

            if not s.get(
                "daily_report"
            ):

                continue

            now = datetime.now()

            today = now.strftime(
                "%Y-%m-%d"
            )

            if (
                now.hour
                >= to_int(
                    s.get(
                        "report_hour"
                    ),
                    9
                )
                and s.get(
                    "last_report"
                ) != today
            ):

                set_setting(
                    "last_report",
                    today
                )

                await notify(
                    bot,
                    build_report(24)
                )

        except Exception as e:

            log.exception(
                "Report error: %s",
                e
            )


# ============================================================
# MAIN
# ============================================================

async def main():

    token = read_token()

    if not token:

        log.error(
            "BOT_TOKEN not found in %s",
            CONFIG_FILE
        )

        sys.exit(1)

    QUEUE_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    DATA_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    load_owner()

    seed_known_ips()

    bot = Bot(
        token=token,
        default=DefaultBotProperties(
            parse_mode=ParseMode.HTML
        )
    )

    dp = Dispatcher()

    dp.include_router(
        router
    )

    me = await bot.get_me()

    log.info(
        "Bot @%s started. Owner: %s",
        me.username,
        OWNER.get(
            "user_id",
            "not registered"
        )
    )

    try:

        await bot.set_my_commands([
            BotCommand(
                command="menu",
                description="Main menu"
            ),
            BotCommand(
                command="status",
                description="Status and statistics"
            ),
            BotCommand(
                command="blocks",
                description="Active blocks"
            ),
            BotCommand(
                command="events",
                description="Recent events"
            ),
            BotCommand(
                command="top",
                description="Top attackers"
            ),
            BotCommand(
                command="server",
                description="Server status"
            ),
            BotCommand(
                command="ip",
                description="IP information"
            ),
            BotCommand(
                command="block",
                description="Block an IP"
            ),
            BotCommand(
                command="unblock",
                description="Unblock an IP"
            ),
            BotCommand(
                command="whitelist",
                description="Whitelist"
            ),
            BotCommand(
                command="help",
                description="Help"
            ),
        ])

    except TelegramAPIError as e:

        log.warning(
            "set_my_commands failed: %s",
            e
        )

    # ========================================================
    # BRUTE FORCE WATCHER
    # ========================================================

    watcher = Watcher(
        bot
    )

    # ========================================================
    # PORT / NETWORK / SERVICE WATCHER
    # ========================================================

    port_service_watcher = (
        PortServiceWatcher(
            bot
        )
    )

    # ========================================================
    # BACKGROUND TASKS
    # ========================================================

    tasks = [

        asyncio.create_task(
            watcher.run()
        ),

        asyncio.create_task(
            port_service_watcher.run()
        ),

        asyncio.create_task(
            queue_worker(
                bot
            )
        ),

        asyncio.create_task(
            report_worker(
                bot
            )
        ),
    ]

    try:

        await dp.start_polling(
            bot,
            allowed_updates=[
                "message",
                "callback_query",
            ]
        )

    finally:

        for task in tasks:

            task.cancel()

        await bot.session.close()


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":

    try:

        asyncio.run(
            main()
        )

    except KeyboardInterrupt:

        log.info(
            "Stopped."
        )