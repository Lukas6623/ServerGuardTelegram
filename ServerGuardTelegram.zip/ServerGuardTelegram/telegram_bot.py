#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ServerGuard Telegram Bot
========================

Works together with:
  * TelegramBot.cpp
  * Brute Force Guard
  * SSH Key Guard
  * Service Monitor

Features:
  * Owner registration
  * IP block/unblock notifications
  * SSH login notifications
  * Failed SSH notifications
  * SSH Key Guard notifications
  * Service monitor notifications
  * Daily report
  * Block / unblock IP
  * Whitelist management
  * Server information
  * SSH logs
  * Queue notifications

SSH Key Guard:
  * Watches /opt/serverguard/data/ssh_key_events.json
  * Detects added SSH keys
  * Detects removed SSH keys
  * Detects changed SSH keys
  * Shows account
  * Shows authorized_keys file
  * Shows key fingerprint
  * Shows modifier information from auditd
  * Shows source IP when available
  * Shows process / PID / command
"""


import asyncio
import hmac
import html
import ipaddress
import json
import logging
import math
import os
import shutil
import socket
import sys
import time

from collections import Counter, deque
from datetime import datetime, timezone
from pathlib import Path


import aiohttp

from aiogram import (
    BaseMiddleware,
    Bot,
    Dispatcher,
    F,
    Router,
)

from aiogram.client.default import DefaultBotProperties

from aiogram.enums import ParseMode

from aiogram.exceptions import (
    TelegramAPIError,
    TelegramBadRequest,
)

from aiogram.filters import (
    Command,
    CommandObject,
)

from aiogram.types import (
    BotCommand,
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)


# ============================================================
# PATHS
# ============================================================

BASE_DIR = Path(
    os.environ.get(
        "SERVERGUARD_DIR",
        "/opt/serverguard"
    )
)


TELEGRAM_DIR = (
    BASE_DIR
    / "telegram"
)


CONFIG_FILE = (
    TELEGRAM_DIR
    / "telegram.conf"
)


VERIFICATION_FILE = (
    TELEGRAM_DIR
    / "verification.json"
)


OWNER_FILE = (
    TELEGRAM_DIR
    / "owner.json"
)


QUEUE_DIR = (
    TELEGRAM_DIR
    / "queue"
)


DATA_DIR = (
    BASE_DIR
    / "data"
)


PROTECTION_CONFIG_FILE = (
    DATA_DIR
    / "protection_config.json"
)


EVENTS_FILE = (
    DATA_DIR
    / "ssh_events.json"
)


BLOCKS_FILE = (
    DATA_DIR
    / "blocked_ips.json"
)


STATS_FILE = (
    DATA_DIR
    / "stats.json"
)


SERVICE_MONITOR_EVENTS_FILE = (
    DATA_DIR
    / "service_monitor_events.json"
)


# ============================================================
# SSH KEY GUARD
# ============================================================

SSH_KEY_EVENTS_FILE = (
    DATA_DIR
    / "ssh_key_events.json"
)


SSH_KEY_STATE_FILE = (
    DATA_DIR
    / "ssh_key_state.json"
)


# ============================================================
# SETTINGS
# ============================================================

POLL_INTERVAL = 2

QUEUE_INTERVAL = 3

BLOCKS_PER_PAGE = 8

MAX_LIST_LINES = 15

REG_WINDOW = 900

REG_USER_LIMIT = 5

REG_GLOBAL_LIMIT = 15


DEFAULT_PROTECTION = {
    "enabled": True,
    "attempts": 5,
    "duration": 600,
    "permanent": False,
    "mode": "ip",
    "whitelist": [],
}


DEFAULT_SETTINGS = {
    "important_only": True,

    "notify_block": True,

    "notify_unblock": True,

    "notify_login": True,

    "notify_new_ip": True,

    "notify_failed": False,

    "notify_service": True,

    "notify_ssh_key": True,

    "geo": True,

    "daily_report": True,

    "report_hour": 9,

    "last_report": "",

    "mute_until": 0,
}


NOTIFY_LABELS = {

    "important_only":
        "⭐ Important only (hide minor)",

    "notify_block":
        "🚫 Blocks",

    "notify_unblock":
        "✅ Unblocks",

    "notify_login":
        "🔑 All successful logins",

    "notify_new_ip":
        "🆕 Login from a new IP",

    "notify_failed":
        "⚠️ Failed attempts",

    "notify_service":
        "🔧 Service changes",

    "notify_ssh_key":
        "🔐 SSH key changes",

    "geo":
        "🌍 IP geolocation",

    "daily_report":
        "📅 Daily report",
}


# ============================================================
# ANTI-SPAM
# ============================================================

SERVICE_COOLDOWN = 600

THROTTLE_WINDOW = 60


THROTTLE_LIMITS = {

    "block": 6,

    "login": 8,

    "service": 6,

    "failed": 3,

    "ssh_key": 10,

    "misc": 10,
}


SERVICE_IGNORE_PATTERNS = (

    "session-",
    "user@",
    "user-runtime-dir@",
    "getty@",
    "apt-daily",
    "apt-",
    "dpkg",
    "man-db",
    "logrotate",
    "fstrim",
    "e2scrub",
    "phpsessionclean",
    "motd-news",
    "sysstat",
    "snapd",
    "unattended-upgrades",
    "ua-timer",
    "update-notifier",
    "systemd-tmpfiles",
    "systemd-timedated",
    "systemd-hostnamed",
    "systemd-localed",
    "systemd-userdbd",
    "systemd-update-utmp",
    "systemd-fsck",
    "systemd-random-seed",
    "systemd-journal-flush",
    "systemd-networkd-wait-online",
    "cloud-",
    "fwupd",
    "packagekit",
    "certbot",
    "ldconfig",
    "dbus-",
    ".scope",
    ".slice",
    ".mount",
)


CRITICAL_SERVICE_PATTERNS = (

    "ssh",
    "ufw",
    "fail2ban",
    "serverguard",
    "firewalld",
    "auditd",
)


# ============================================================
# LOGGING
# ============================================================

logging.basicConfig(
    level=logging.INFO,
    format="[ServerGuard-TG] %(levelname)s %(message)s",
    stream=sys.stdout,
)


log = logging.getLogger(
    "sg-telegram"
)


router = Router()


FILE_LOCK = asyncio.Lock()


OWNER = {}


USER_FAILS = {}


GLOBAL_FAILS = deque()


SUPPRESS_BLOCK = set()


SUPPRESS_UNBLOCK = set()


GEO_CACHE = {}


# ============================================================
# BASIC HELPERS
# ============================================================

def esc(value) -> str:

    return html.escape(
        str(value),
        quote=False
    )


def to_bool(value) -> bool:

    if isinstance(
        value,
        str
    ):

        return (
            value
            .strip()
            .lower()
            in (
                "1",
                "true",
                "yes",
                "on",
                "enabled",
            )
        )

    return bool(value)


def to_int(
    value,
    default=0
) -> int:

    try:

        return int(value)

    except Exception:

        return default


def utc_iso(
    ts=None
) -> str:

    if ts is None:

        ts = time.time()

    return datetime.fromtimestamp(
        ts,
        tz=timezone.utc
    ).isoformat()


def fmt_ts(ts) -> str:

    try:

        return datetime.fromtimestamp(
            int(ts)
        ).strftime(
            "%d.%m %H:%M:%S"
        )

    except Exception:

        return "?"


def fmt_dur(seconds) -> str:

    seconds = to_int(
        seconds
    )

    if seconds < 60:

        return str(seconds) + " s"

    days, rem = divmod(
        seconds,
        86400
    )

    hours, rem = divmod(
        rem,
        3600
    )

    minutes = rem // 60

    parts = []

    if days:

        parts.append(
            str(days) + " d"
        )

    if hours:

        parts.append(
            str(hours) + " h"
        )

    if minutes:

        parts.append(
            str(minutes) + " min"
        )

    return (
        " ".join(parts)
        or "0 min"
    )


def block_term(
    rec: dict
) -> str:

    if rec.get(
        "permanent"
    ):

        return "♾ permanent"

    start = to_int(
        rec.get(
            "blocked_at"
        ),
        0
    )

    end = to_int(
        rec.get(
            "expires_at"
        ),
        0
    )

    if (
        start
        and end
        and end > start
    ):

        seconds = end - start

        if seconds >= 60:

            seconds = round(
                seconds / 60
            ) * 60

        return fmt_dur(
            seconds
        )

    duration = to_int(
        rec.get(
            "duration"
        ),
        0
    )

    if duration > 0:

        return fmt_dur(
            duration
        )

    if end:

        left = (
            end
            - time.time()
        )

        if left > 0:

            return (
                fmt_dur(left)
                + " left"
            )

    return "unknown"


def parse_ip(value):

    try:

        return str(
            ipaddress.ip_address(
                str(value).strip()
            )
        )

    except ValueError:

        return None


def ev_time(event) -> int:

    return to_int(
        event.get(
            "time"
        ),
        0
    )


# ============================================================
# JSON
# ============================================================

def load_json(
    path: Path,
    default
):

    try:

        if not path.exists():

            return default

        with path.open(
            "r",
            encoding="utf-8"
        ) as file:

            return json.load(
                file
            )

    except Exception as e:

        log.warning(
            "JSON load error %s: %s",
            path,
            e
        )

        return default


def save_json(
    path: Path,
    data,
    private=False
) -> bool:

    tmp = path.with_name(
        path.name
        + ".tg.tmp"
    )

    try:

        path.parent.mkdir(
            parents=True,
            exist_ok=True
        )

        with tmp.open(
            "w",
            encoding="utf-8"
        ) as file:

            json.dump(
                data,
                file,
                indent=2,
                ensure_ascii=False
            )

            file.write(
                "\n"
            )

        if private:

            os.chmod(
                tmp,
                0o600
            )

        tmp.replace(
            path
        )

        return True

    except Exception as e:

        log.error(
            "JSON save error %s: %s",
            path,
            e
        )

        try:

            if tmp.exists():

                tmp.unlink()

        except Exception:

            pass

        return False


def mtime_ns(
    path: Path
):

    try:

        return path.stat().st_mtime_ns

    except Exception:

        return None


# ============================================================
# GUARD DATA
# ============================================================

def load_config() -> dict:

    cfg = dict(
        DEFAULT_PROTECTION
    )

    data = load_json(
        PROTECTION_CONFIG_FILE,
        {}
    )

    if isinstance(
        data,
        dict
    ):

        cfg.update(
            data
        )

    cfg["enabled"] = to_bool(
        cfg.get(
            "enabled",
            True
        )
    )

    cfg["permanent"] = to_bool(
        cfg.get(
            "permanent",
            False
        )
    )

    cfg["attempts"] = max(
        1,
        min(
            to_int(
                cfg.get(
                    "attempts"
                ),
                5
            ),
            100
        )
    )

    cfg["duration"] = max(
        60,
        min(
            to_int(
                cfg.get(
                    "duration"
                ),
                600
            ),
            30 * 24 * 3600
        )
    )

    wl = cfg.get(
        "whitelist",
        []
    )

    clean = []

    if isinstance(
        wl,
        list
    ):

        for ip in wl:

            ip = str(
                ip
            ).strip()

            if (
                ip
                and ip not in clean
            ):

                clean.append(
                    ip
                )

    cfg["whitelist"] = clean

    return cfg


def update_protection(
    changes: dict
) -> bool:

    data = load_json(
        PROTECTION_CONFIG_FILE,
        None
    )

    if not isinstance(
        data,
        dict
    ):

        data = dict(
            DEFAULT_PROTECTION
        )

    data.update(
        changes
    )

    return save_json(
        PROTECTION_CONFIG_FILE,
        data
    )


def load_events() -> list:

    data = load_json(
        EVENTS_FILE,
        []
    )

    if not isinstance(
        data,
        list
    ):

        return []

    return [
        e
        for e in data
        if isinstance(
            e,
            dict
        )
    ]


def load_blocks() -> dict:

    data = load_json(
        BLOCKS_FILE,
        {}
    )

    if not isinstance(
        data,
        dict
    ):

        return {}

    return {
        ip: rec
        for ip, rec in data.items()
        if isinstance(
            rec,
            dict
        )
    }


def save_blocks(
    blocks: dict
) -> bool:

    return save_json(
        BLOCKS_FILE,
        blocks
    )


def load_stats() -> dict:

    data = load_json(
        STATS_FILE,
        {}
    )

    return (
        data
        if isinstance(
            data,
            dict
        )
        else {}
    )


def bump_stat(
    name: str
):

    stats = load_stats()

    stats[name] = (
        to_int(
            stats.get(
                name,
                0
            )
        )
        + 1
    )

    save_json(
        STATS_FILE,
        stats
    )


# ============================================================
# SSH KEY GUARD DATA
# ============================================================

def load_ssh_key_events() -> list:

    data = load_json(
        SSH_KEY_EVENTS_FILE,
        []
    )

    if not isinstance(
        data,
        list
    ):
        return []

    return [
        event
        for event in data
        if isinstance(
            event,
            dict
        )
    ]


# ============================================================
# SSH KEY EVENT TIME
# ============================================================

def ssh_key_event_time(
    event: dict
) -> str:

    value = event.get(
        "timestamp"
    )

    if value:
        return str(value)

    value = event.get(
        "timestamp_utc"
    )

    if value:
        return str(value)

    value = event.get(
        "audit_timestamp"
    )

    if value:
        return str(value)

    value = event.get(
        "time"
    )

    if value:
        return str(value)

    return ""


# ============================================================
# SSH KEY EVENT IDENTITY
# ============================================================

def ssh_key_event_key(
    event: dict
) -> str:

    event_id = event.get(
        "id"
    )

    if event_id:
        return str(
            event_id
        )

    important = (
        "version",
        "timestamp",
        "timestamp_utc",
        "audit_timestamp",
        "action",
        "account",
        "file",
        "key",
        "old_key",
        "modifier",
        "network",
    )

    parts = []

    for name in important:

        value = event.get(
            name,
            ""
        )

        if isinstance(
            value,
            (
                dict,
                list
            )
        ):

            try:

                value = json.dumps(
                    value,
                    sort_keys=True,
                    ensure_ascii=False
                )

            except Exception:

                value = str(
                    value
                )

        parts.append(
            str(value)
        )

    return "|".join(
        parts
    )


# ============================================================
# SSH KEY ACTION
# ============================================================

def ssh_key_action(
    event: dict
) -> str:

    value = event.get(
        "action"
    )

    if value is None:

        value = event.get(
            "type"
        )

    if value is None:

        value = event.get(
            "event"
        )

    return (
        str(
            value
            or "unknown"
        )
        .strip()
        .lower()
        .replace(
            "-",
            "_"
        )
        .replace(
            " ",
            "_"
        )
    )


# ============================================================
# GENERIC VALUE
# ============================================================

def ssh_key_value(
    event: dict,
    *keys,
    default=""
):

    for key in keys:

        value = event.get(
            key
        )

        if value is None:
            continue

        if isinstance(
            value,
            str
        ):

            if value.strip():

                return value

        else:

            return value

    return default


# ============================================================
# NESTED VALUE
# ============================================================

def ssh_key_nested(
    event: dict,
    container_name: str,
    *keys,
    default=""
):

    container = event.get(
        container_name
    )

    if not isinstance(
        container,
        dict
    ):

        return default

    for key in keys:

        value = container.get(
            key
        )

        if value is None:
            continue

        if isinstance(
            value,
            str
        ):

            if value.strip():

                return value

        else:

            return value

    return default


# ============================================================
# ACCOUNT
# ============================================================

def ssh_key_account(
    event: dict
) -> str:

    account = event.get(
        "account"
    )

    if isinstance(
        account,
        dict
    ):

        username = account.get(
            "username"
        )

        if username:
            return str(
                username
            )

    value = event.get(
        "username"
    )

    if value:
        return str(
            value
        )

    value = event.get(
        "user"
    )

    if value:
        return str(
            value
        )

    return "?"


# ============================================================
# ACCOUNT INFORMATION
# ============================================================

def ssh_key_account_info(
    event: dict
) -> dict:

    account = event.get(
        "account"
    )

    if isinstance(
        account,
        dict
    ):

        return account

    return {}


# ============================================================
# FILE PATH
# ============================================================

def ssh_key_path(
    event: dict
) -> str:

    file_info = event.get(
        "file"
    )

    if isinstance(
        file_info,
        dict
    ):

        path = file_info.get(
            "path"
        )

        if path:
            return str(
                path
            )

    value = event.get(
        "path"
    )

    if value:
        return str(
            value
        )

    value = event.get(
        "authorized_keys"
    )

    if value:
        return str(
            value
        )

    return "?"


# ============================================================
# FILE INFORMATION
# ============================================================

def ssh_key_file_info(
    event: dict
) -> dict:

    file_info = event.get(
        "file"
    )

    if isinstance(
        file_info,
        dict
    ):

        return file_info

    return {}


# ============================================================
# KEY INFORMATION
# ============================================================

def ssh_key_info(
    event: dict
) -> dict:

    key = event.get(
        "key"
    )

    if isinstance(
        key,
        dict
    ):

        return key

    return {}


# ============================================================
# KEY FINGERPRINT
# ============================================================

def ssh_key_fingerprint(
    event: dict
) -> str:

    key = ssh_key_info(
        event
    )

    value = key.get(
        "fingerprint"
    )

    if value:
        return str(
            value
        )

    value = event.get(
        "fingerprint"
    )

    if value:
        return str(
            value
        )

    value = key.get(
        "sha256"
    )

    if value:
        return str(
            value
        )

    return ""


# ============================================================
# KEY SHA256
# ============================================================

def ssh_key_sha256(
    event: dict
) -> str:

    key = ssh_key_info(
        event
    )

    value = key.get(
        "sha256"
    )

    if value:
        return str(
            value
        )

    value = event.get(
        "sha256"
    )

    if value:
        return str(
            value
        )

    return ""


# ============================================================
# KEY COMMENT
# ============================================================

def ssh_key_comment(
    event: dict
) -> str:

    key = ssh_key_info(
        event
    )

    value = key.get(
        "comment"
    )

    if value:
        return str(
            value
        )

    value = event.get(
        "comment"
    )

    if value:
        return str(
            value
        )

    return ""


# ============================================================
# KEY TYPE
# ============================================================

def ssh_key_type(
    event: dict
) -> str:

    key = ssh_key_info(
        event
    )

    value = key.get(
        "type"
    )

    if value:
        return str(
            value
        )

    value = event.get(
        "key_type"
    )

    if value:
        return str(
            value
        )

    return ""


# ============================================================
# KEY LINE
# ============================================================

def ssh_key_line(
    event: dict
) -> str:

    key = ssh_key_info(
        event
    )

    value = key.get(
        "line"
    )

    if value is not None:
        return str(
            value
        )

    return ""


# ============================================================
# KEY OPTIONS
# ============================================================

def ssh_key_options(
    event: dict
) -> str:

    key = ssh_key_info(
        event
    )

    value = key.get(
        "options"
    )

    if value:
        return str(
            value
        )

    return ""


# ============================================================
# OLD KEY
# ============================================================

def ssh_key_old_info(
    event: dict
) -> dict:

    old_key = event.get(
        "old_key"
    )

    if isinstance(
        old_key,
        dict
    ):

        return old_key

    return {}


# ============================================================
# MODIFIER
# ============================================================

def ssh_key_modifier(
    event: dict
) -> dict:

    modifier = event.get(
        "modifier"
    )

    if isinstance(
        modifier,
        dict
    ):

        return modifier

    return {}


# ============================================================
# NETWORK
# ============================================================

def ssh_key_network(
    event: dict
) -> dict:

    network = event.get(
        "network"
    )

    if isinstance(
        network,
        dict
    ):

        return network

    return {}


# ============================================================
# SOURCE IP
# ============================================================

def ssh_key_source_ip(
    event: dict
) -> str:

    network = ssh_key_network(
        event
    )

    value = network.get(
        "source_ip"
    )

    if value:
        return str(
            value
        )

    value = event.get(
        "source_ip"
    )

    if value:
        return str(
            value
        )

    return ""


# ============================================================
# SOURCE IP SOURCE
# ============================================================

def ssh_key_source_ip_source(
    event: dict
) -> str:

    network = ssh_key_network(
        event
    )

    value = network.get(
        "source_ip_source"
    )

    if value:
        return str(
            value
        )

    return ""


# ============================================================
# SSH KEY GEO INFORMATION
# ============================================================

def ssh_key_geo(
    event: dict
) -> dict:

    network = ssh_key_network(
        event
    )

    return {
        "country": network.get(
            "country",
            ""
        ),

        "region": network.get(
            "region",
            ""
        ),

        "city": network.get(
            "city",
            ""
        ),

        "org": network.get(
            "org",
            ""
        ),

        "hostname": network.get(
            "hostname",
            ""
        ),

        "terminal": network.get(
            "terminal",
            ""
        )
    }
# ============================================================
# OWNER / SETTINGS
# ============================================================

def load_owner():

    data = load_json(
        OWNER_FILE,
        {}
    )

    OWNER.clear()

    if (
        isinstance(
            data,
            dict
        )
        and data.get(
            "user_id"
        )
    ):

        OWNER.update(
            data
        )


def save_owner():

    save_json(
        OWNER_FILE,
        OWNER,
        private=True
    )


def is_owner(
    user_id
) -> bool:

    return (
        bool(OWNER)
        and OWNER.get(
            "user_id"
        ) == user_id
    )


def settings() -> dict:

    result = dict(
        DEFAULT_SETTINGS
    )

    stored = OWNER.get(
        "settings"
    )

    if isinstance(
        stored,
        dict
    ):

        result.update(
            stored
        )

    return result


def set_setting(
    key,
    value
):

    if not OWNER:

        return

    OWNER.setdefault(
        "settings",
        {}
    )[key] = value

    save_owner()


def known_ips() -> set:

    stored = OWNER.get(
        "known_ips"
    )

    return (
        set(stored)
        if isinstance(
            stored,
            list
        )
        else set()
    )


def remember_ip(
    ip: str
):

    if not OWNER:

        return

    stored = OWNER.get(
        "known_ips"
    )

    if not isinstance(
        stored,
        list
    ):

        stored = []

    if ip not in stored:

        stored.append(
            ip
        )

        OWNER["known_ips"] = (
            stored[-1000:]
        )

        save_owner()


def seed_known_ips():

    if not OWNER:

        return

    stored = OWNER.get(
        "known_ips"
    )

    stored = (
        list(stored)
        if isinstance(
            stored,
            list
        )
        else []
    )

    changed = False

    for e in load_events():

        if e.get(
            "type"
        ) == "success":

            ip = e.get(
                "ip"
            )

            if (
                ip
                and ip not in stored
            ):

                stored.append(
                    ip
                )

                changed = True

    if changed:

        OWNER["known_ips"] = (
            stored[-1000:]
        )

        save_owner()


def read_token() -> str:

    token = os.environ.get(
        "BOT_TOKEN",
        ""
    ).strip()

    try:

        if CONFIG_FILE.exists():

            for line in CONFIG_FILE.read_text(
                encoding="utf-8"
            ).splitlines():

                line = line.strip()

                if line.startswith(
                    "BOT_TOKEN="
                ):

                    token = (
                        line.split(
                            "=",
                            1
                        )[1]
                        .strip()
                        .strip('"')
                        .strip("'")
                    )

                    break

    except Exception as e:

        log.error(
            "Cannot read %s: %s",
            CONFIG_FILE,
            e
        )

    return token


# ============================================================
# SYSTEM COMMANDS
# ============================================================

async def run_cmd(
    *args,
    timeout=15
):

    proc = None

    try:

        proc = await asyncio.create_subprocess_exec(
            *args,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )

        out, _ = await asyncio.wait_for(
            proc.communicate(),
            timeout=timeout
        )

        return (
            proc.returncode,
            out.decode(
                "utf-8",
                "replace"
            )
        )

    except FileNotFoundError:

        return (
            127,
            str(args[0])
            + ": command not found"
        )

    except asyncio.TimeoutError:

        try:

            if proc:

                proc.kill()

        except Exception:

            pass

        return (
            124,
            "timeout"
        )

    except Exception as e:

        return (
            1,
            str(e)
        )


async def local_ips() -> set:

    ips = {
        "127.0.0.1",
        "::1"
    }

    rc, out = await run_cmd(
        "hostname",
        "-I",
        timeout=5
    )

    if rc == 0:

        ips.update(
            out.split()
        )

    return ips


def _rule_missing(
    text: str
) -> bool:

    low = text.lower()

    return (
        "non-existent" in low
        or "could not delete" in low
        or "not found" in low
    )


async def do_unblock(
    ip: str
):

    for _ in range(5):

        rc, out = await run_cmd(
            "ufw",
            "delete",
            "deny",
            "from",
            ip
        )

        if _rule_missing(
            out
        ):

            break

        if rc != 0:

            return (
                False,
                out.strip()[:300]
                or "ufw error"
            )

    async with FILE_LOCK:

        blocks = load_blocks()

        rec = blocks.pop(
            ip,
            None
        )

        if rec is not None:

            SUPPRESS_UNBLOCK.add(
                ip
            )

            save_blocks(
                blocks
            )

            bump_stat(
                "unblocked"
            )

    return (
        True,
        "OK"
    )


async def do_block(
    ip: str,
    permanent: bool,
    duration: int,
    reason: str
):

    ip = parse_ip(
        ip
    )

    if not ip:

        return (
            False,
            "Invalid IP address"
        )

    cfg = load_config()

    if ip in cfg["whitelist"]:

        return (
            False,
            "IP is in the whitelist"
        )

    if ip in await local_ips():

        return (
            False,
            "This is the server's own IP"
        )

    rc, out = await run_cmd(
        "ufw",
        "insert",
        "1",
        "deny",
        "from",
        ip
    )

    if rc != 0:

        return (
            False,
            out.strip()[:300]
            or "ufw error"
        )

    now = int(
        time.time()
    )

    duration = max(
        60,
        int(duration)
    )

    expires = (
        None
        if permanent
        else now + duration
    )

    async with FILE_LOCK:

        blocks = load_blocks()

        blocks[ip] = {

            "ip": ip,

            "blocked_at": now,

            "blocked_at_iso":
                utc_iso(now),

            "failed_attempts": 0,

            "permanent":
                bool(permanent),

            "duration":
                duration,

            "expires_at":
                expires,

            "expires_at_iso":
                None
                if expires is None
                else utc_iso(expires),

            "reason":
                reason,
        }

        SUPPRESS_BLOCK.add(
            (
                ip,
                now
            )
        )

        save_blocks(
            blocks
        )

        bump_stat(
            "blocked"
        )

    return (
        True,
        "OK"
    )


def whitelist_add(
    ip: str
) -> bool:

    cfg = load_config()

    wl = cfg["whitelist"]

    if ip in wl:

        return False

    wl.append(
        ip
    )

    update_protection(
        {
            "whitelist": wl
        }
    )

    return True


def whitelist_remove(
    ip: str
) -> bool:

    cfg = load_config()

    wl = cfg["whitelist"]

    if ip not in wl:

        return False

    wl.remove(
        ip
    )

    update_protection(
        {
            "whitelist": wl
        }
    )

    return True


# ============================================================
# GEO
# ============================================================

async def geo_lookup(
    ip: str,
    force=False
) -> str:

    if (
        not force
        and not settings().get(
            "geo",
            True
        )
    ):

        return ""

    try:

        addr = ipaddress.ip_address(
            ip
        )

    except ValueError:

        return ""

    if (
        addr.is_private
        or addr.is_loopback
        or addr.is_link_local
    ):

        return "🏠 local address"

    if ip in GEO_CACHE:

        return GEO_CACHE[ip]

    result = ""

    try:

        timeout = aiohttp.ClientTimeout(
            total=4
        )

        async with aiohttp.ClientSession(
            timeout=timeout
        ) as session:

            async with session.get(
                "http://ip-api.com/json/"
                + ip,
                params={
                    "fields":
                        "status,country,regionName,city,isp,org,proxy,hosting",

                    "lang":
                        "en",
                },
            ) as resp:

                data = await resp.json(
                    content_type=None
                )

        if data.get(
            "status"
        ) == "success":

            place = ", ".join(
                x
                for x in (
                    data.get(
                        "country"
                    ),
                    data.get(
                        "city"
                    ),
                )
                if x
            )

            provider = (
                data.get(
                    "isp"
                )
                or data.get(
                    "org"
                )
                or ""
            )

            result = (
                "🌍 "
                + esc(
                    place
                    or "?"
                )
            )

            if provider:

                result += (
                    " · "
                    + esc(
                        provider
                    )
                )

            if (
                data.get(
                    "hosting"
                )
                or data.get(
                    "proxy"
                )
            ):

                result += (
                    "\n🕵️ hosting / VPN / proxy"
                )

    except Exception as e:

        log.debug(
            "geo error %s: %s",
            ip,
            e
        )

        return ""

    if len(
        GEO_CACHE
    ) > 500:

        GEO_CACHE.clear()

    GEO_CACHE[ip] = result

    return result


# ============================================================
# KEYBOARDS
# ============================================================

def btn(
    text,
    data
) -> InlineKeyboardButton:

    return InlineKeyboardButton(
        text=text,
        callback_data=data
    )


def kb(
    rows
) -> InlineKeyboardMarkup:

    return InlineKeyboardMarkup(
        inline_keyboard=rows
    )


BACK_ROW = [
    btn(
        "⬅️ Menu",
        "m"
    )
]


# ============================================================
# VIEWS
# ============================================================

def view_menu():

    cfg = load_config()

    blocks = load_blocks()

    text = (
        "🛡 <b>ServerGuard</b>\n\n"

        "SSH protection: "
        + (
            "✅ enabled"
            if cfg["enabled"]
            else "❌ disabled"
        )
        + "\n"

        "Active blocks: <b>"
        + str(
            len(blocks)
        )
        + "</b>\n\n"

        "Choose an action:"
    )

    markup = kb([
        [
            btn(
                "📊 Status",
                "st"
            ),
            btn(
                "🚫 Blocks",
                "bp:0"
            ),
        ],

        [
            btn(
                "📜 Events",
                "ev:all"
            ),
            btn(
                "🔑 Logins",
                "ev:success"
            ),
        ],

        [
            btn(
                "🏴‍☠️ Top attackers",
                "tp:24"
            ),
            btn(
                "🖥 Server",
                "sv"
            ),
        ],

        [
            btn(
                "🛡 Protection",
                "pr"
            ),
            btn(
                "✅ Whitelist",
                "wl"
            ),
        ],

        [
            btn(
                "🔔 Notifications",
                "nt"
            ),
            btn(
                "🧾 SSH logs",
                "lg"
            ),
        ],
    ])

    return (
        text,
        markup
    )


def view_status():

    cfg = load_config()

    blocks = load_blocks()

    stats = load_stats()

    events = load_events()

    cutoff = (
        time.time()
        - 86400
    )

    failed24 = [
        e
        for e in events
        if (
            e.get("type")
            == "failed"
            and ev_time(e)
            >= cutoff
        )
    ]

    success24 = [
        e
        for e in events
        if (
            e.get("type")
            == "success"
            and ev_time(e)
            >= cutoff
        )
    ]

    attackers24 = {
        e.get("ip")
        for e in failed24
    }

    block_type = (
        "permanent"
        if cfg["permanent"]
        else fmt_dur(
            cfg["duration"]
        )
    )

    permanent_count = sum(
        1
        for r in blocks.values()
        if r.get(
            "permanent"
        )
    )

    ssh_key_events = (
        load_ssh_key_events()
    )

    ssh_key_24 = [
        e
        for e in ssh_key_events
        if ssh_key_event_time(e)
        >= cutoff
    ]

    text = (
        "📊 <b>ServerGuard status</b>\n\n"

        "Protection: "
        + (
            "✅ ON"
            if cfg["enabled"]
            else "❌ OFF"
        )
        + "\n"

        "Threshold: <b>"
        + str(cfg["attempts"])
        + "</b> attempts → block <b>"
        + esc(block_type)
        + "</b>\n"

        "Whitelist: "
        + str(
            len(
                cfg["whitelist"]
            )
        )
        + " IP(s)\n\n"

        "🚫 Active blocks: <b>"
        + str(
            len(blocks)
        )
        + "</b> (permanent: "
        + str(
            permanent_count
        )
        + ")\n\n"

        "<b>Last 24 hours</b>\n"

        "⚠️ Failed attempts: <b>"
        + str(
            len(failed24)
        )
        + "</b> (unique IPs: "
        + str(
            len(
                attackers24
            )
        )
        + ")\n"

        "🔑 Successful logins: <b>"
        + str(
            len(success24)
        )
        + "</b>\n"

        "🔐 SSH key changes: <b>"
        + str(
            len(ssh_key_24)
        )
        + "</b>\n\n"

        "<b>All time</b>\n"

        "⚠️ Failed: "
        + str(
            to_int(
                stats.get(
                    "failed"
                )
            )
        )
        + "\n"

        "🔑 Successful: "
        + str(
            to_int(
                stats.get(
                    "success"
                )
            )
        )
        + "\n"

        "🚫 Blocks: "
        + str(
            to_int(
                stats.get(
                    "blocked"
                )
            )
        )
        + "\n"

        "✅ Unblocks: "
        + str(
            to_int(
                stats.get(
                    "unblocked"
                )
            )
        )
    )

    markup = kb([
        [
            btn(
                "🔄 Refresh",
                "st"
            ),
            btn(
                "🚫 Blocks",
                "bp:0"
            ),
        ],
        BACK_ROW,
    ])

    return (
        text,
        markup
    )


def view_blocks(
    page=0
):

    blocks = load_blocks()

    items = sorted(
        blocks.items(),
        key=lambda kv:
            to_int(
                kv[1].get(
                    "blocked_at"
                ),
                0
            ),
        reverse=True
    )

    total = len(
        items
    )

    pages = max(
        1,
        math.ceil(
            total
            / BLOCKS_PER_PAGE
        )
    )

    page = max(
        0,
        min(
            page,
            pages - 1
        )
    )

    chunk = items[
        page * BLOCKS_PER_PAGE:
        (page + 1)
        * BLOCKS_PER_PAGE
    ]

    now = time.time()

    lines = [
        "🚫 <b>Active blocks</b> ("
        + str(total)
        + ")"
    ]

    if pages > 1:

        lines[0] += (
            " · page "
            + str(page + 1)
            + "/"
            + str(pages)
        )

    lines.append("")

    if not chunk:

        lines.append(
            "No blocked IPs right now 🎉"
        )

    for ip, rec in chunk:

        if rec.get(
            "permanent"
        ):

            left = "♾ permanent"

        else:

            exp = to_int(
                rec.get(
                    "expires_at"
                ),
                0
            )

            left = (
                fmt_dur(
                    max(
                        0,
                        exp - now
                    )
                )
                + " left"
            )

        lines.append(
            "• <code>"
            + esc(ip)
            + "</code> — "
            + left
            + "\n"
            + "   attempts: "
            + str(
                to_int(
                    rec.get(
                        "failed_attempts"
                    )
                )
            )
            + " · since "
            + fmt_ts(
                rec.get(
                    "blocked_at"
                )
            )
        )

    rows = []

    pair = []

    for ip, _ in chunk:

        pair.append(
            btn(
                "🔓 "
                + ip,
                "ub:"
                + ip
            )
        )

        if len(pair) == 2:

            rows.append(
                pair
            )

            pair = []

    if pair:

        rows.append(
            pair
        )

    nav = []

    if page > 0:

        nav.append(
            btn(
                "◀️",
                "bp:"
                + str(
                    page - 1
                )
            )
        )

    nav.append(
        btn(
            "🔄",
            "bp:"
            + str(page)
        )
    )

    if page < pages - 1:

        nav.append(
            btn(
                "▶️",
                "bp:"
                + str(
                    page + 1
                )
            )
        )

    rows.append(
        nav
    )

    if total:

        rows.append([
            btn(
                "🔓 Unblock all",
                "ua"
            )
        ])

    rows.append(
        BACK_ROW
    )

    return (
        "\n".join(lines),
        kb(rows)
    )


def view_unblock_all_confirm():

    total = len(
        load_blocks()
    )

    text = (
        "⚠️ Remove the block from all IPs "
        "<b>"
        + str(total)
        + "</b>?"
    )

    return (
        text,
        kb([
            [
                btn(
                    "✅ Yes, unblock all",
                    "uay"
                ),
                btn(
                    "❌ Cancel",
                    "bp:0"
                ),
            ]
        ])
    )


def view_events(
    kind="all"
):

    events = load_events()

    if kind in (
        "failed",
        "success"
    ):

        events = [
            e
            for e in events
            if e.get(
                "type"
            ) == kind
        ]

    last = (
        events[-MAX_LIST_LINES:]
        [::-1]
    )

    titles = {
        "all":
            "Recent events",

        "failed":
            "Failed attempts",

        "success":
            "Successful logins",
    }

    lines = [
        "📜 <b>"
        + titles.get(
            kind,
            "Events"
        )
        + "</b> (server time)",
        "",
    ]

    if not last:

        lines.append(
            "Nothing here yet."
        )

    for e in last:

        ip = esc(
            e.get(
                "ip",
                "?"
            )
        )

        user = esc(
            e.get(
                "username",
                "?"
            )
        )

        if e.get(
            "type"
        ) == "success":

            method = esc(
                e.get(
                    "auth_method",
                    ""
                )
            )

            lines.append(
                "🟢 "
                + fmt_ts(
                    e.get(
                        "time"
                    )
                )
                + " <b>"
                + user
                + "</b> ← <code>"
                + ip
                + "</code> ("
                + method
                + ")"
            )

        else:

            lines.append(
                "🔴 "
                + fmt_ts(
                    e.get(
                        "time"
                    )
                )
                + " <b>"
                + user
                + "</b> ← <code>"
                + ip
                + "</code>"
            )

    markup = kb([
        [
            btn(
                "All",
                "ev:all"
            ),
            btn(
                "🔴 Failed",
                "ev:failed"
            ),
            btn(
                "🟢 Success",
                "ev:success"
            ),
        ],

        [
            btn(
                "🔄 Refresh",
                "ev:"
                + kind
            )
        ],

        BACK_ROW,
    ])

    return (
        "\n".join(lines),
        markup
    )


def view_top(
    hours=24
):

    hours = (
        168
        if hours >= 168
        else 24
    )

    cutoff = (
        time.time()
        - hours * 3600
    )

    failed = [
        e
        for e in load_events()
        if (
            e.get("type")
            == "failed"
            and ev_time(e)
            >= cutoff
        )
    ]

    blocks = load_blocks()

    ips = Counter(
        e.get(
            "ip",
            "?"
        )
        for e in failed
    )

    users = Counter(
        e.get(
            "username",
            "?"
        )
        for e in failed
    )

    label = (
        "24 hours"
        if hours == 24
        else "7 days"
    )

    lines = [
        "🏴‍☠️ <b>Top attackers, last "
        + label
        + "</b>",
        "",
    ]

    if not ips:

        lines.append(
            "No attacks recorded ✅"
        )

    else:

        lines.append(
            "Total attempts: <b>"
            + str(
                len(failed)
            )
            + "</b> from <b>"
            + str(
                len(ips)
            )
            + "</b> IP(s)\n"
        )

        for ip, count in ips.most_common(
            10
        ):

            tried = Counter(
                e.get(
                    "username",
                    "?"
                )
                for e in failed
                if e.get(
                    "ip"
                ) == ip
            )

            names = ", ".join(
                esc(n)
                for n, _ in tried.most_common(
                    3
                )
            )

            flag = (
                "🚫"
                if ip in blocks
                else "▫️"
            )

            lines.append(
                flag
                + " <code>"
                + esc(ip)
                + "</code> — <b>"
                + str(count)
                + "</b> ("
                + names
                + ")"
            )

        lines.append(
            "\n<b>Most tried usernames:</b>"
        )

        lines.append(
            ", ".join(
                esc(u)
                + " ×"
                + str(c)
                for u, c
                in users.most_common(
                    8
                )
            )
        )

    other = (
        168
        if hours == 24
        else 24
    )

    rows = []

    top_ips = [
        ip
        for ip, _
        in ips.most_common(
            6
        )
    ]

    pair = []

    for ip in top_ips:

        pair.append(
            btn(
                "🔎 "
                + ip,
                "ip:"
                + ip
            )
        )

        if len(pair) == 2:

            rows.append(
                pair
            )

            pair = []

    if pair:

        rows.append(
            pair
        )

    rows.append([
        btn(
            "7 days"
            if hours == 24
            else "24 hours",
            "tp:"
            + str(other)
        ),
        btn(
            "🔄",
            "tp:"
            + str(hours)
        ),
    ])

    rows.append(
        BACK_ROW
    )

    return (
        "\n".join(lines),
        kb(rows)
    )


def server_info() -> str:

    lines = [
        "🖥 <b>Server</b>",
        "",
    ]

    try:

        lines.append(
            "Host: <code>"
            + esc(
                socket.gethostname()
            )
            + "</code>"
        )

    except Exception:

        pass

    try:

        with open(
            "/proc/uptime"
        ) as f:

            seconds = float(
                f.read()
                .split()[0]
            )

        lines.append(
            "Uptime: "
            + fmt_dur(
                seconds
            )
        )

    except Exception:

        pass

    try:

        l1, l5, l15 = os.getloadavg()

        lines.append(
            "Load: "
            + "{:.2f}".format(l1)
            + " / "
            + "{:.2f}".format(l5)
            + " / "
            + "{:.2f}".format(l15)
            + " (cores: "
            + str(
                os.cpu_count()
            )
            + ")"
        )

    except Exception:

        pass

    try:

        mem = {}

        with open(
            "/proc/meminfo"
        ) as f:

            for line in f:

                key, _, val = (
                    line.partition(":")
                )

                mem[key] = (
                    int(
                        val.split()[0]
                    )
                    * 1024
                )

        total = mem[
            "MemTotal"
        ]

        avail = mem.get(
            "MemAvailable",
            mem.get(
                "MemFree",
                0
            )
        )

        used = (
            total
            - avail
        )

        lines.append(
            "RAM: "
            + "{:.2f}".format(
                used / 2**30
            )
            + " / "
            + "{:.2f}".format(
                total / 2**30
            )
            + " GB ("
            + str(
                used * 100 // total
            )
            + "%)"
        )

    except Exception:

        pass

    try:

        usage = shutil.disk_usage(
            "/"
        )

        lines.append(
            "Disk /: "
            + "{:.1f}".format(
                usage.used / 2**30
            )
            + " / "
            + "{:.1f}".format(
                usage.total / 2**30
            )
            + " GB ("
            + str(
                usage.used
                * 100
                // usage.total
            )
            + "%)"
        )

    except Exception:

        pass

    lines.append(
        "Server time: "
        + datetime.now().strftime(
            "%d.%m.%Y %H:%M:%S"
        )
    )

    return "\n".join(
        lines
    )


def view_server():

    return (
        server_info(),
        kb([
            [
                btn(
                    "🔄 Refresh",
                    "sv"
                )
            ],
            BACK_ROW,
        ])
    )


async def view_logs():

    rc, out = await run_cmd(
        "journalctl",
        "-u",
        "ssh",
        "-u",
        "sshd",
        "-n",
        "25",
        "--no-pager",
        "-o",
        "short-iso"
    )

    out = out.strip()

    if (
        rc != 0
        or not out
    ):

        body = (
            out
            or "Logs are not available."
        )

    else:

        body = out[-3400:]

    text = (
        "🧾 <b>SSH logs "
        "(latest lines)</b>\n"
        "<pre>"
        + esc(body)
        + "</pre>"
    )

    return (
        text,
        kb([
            [
                btn(
                    "🔄 Refresh",
                    "lg"
                )
            ],
            BACK_ROW,
        ])
    )


def view_protection():

    cfg = load_config()

    block_type = (
        "♾ permanent"
        if cfg["permanent"]
        else fmt_dur(
            cfg["duration"]
        )
    )

    text = (
        "🛡 <b>SSH protection</b>\n\n"

        "Status: "
        + (
            "✅ ON"
            if cfg["enabled"]
            else "❌ OFF"
        )
        + "\n"

        "Threshold: <b>"
        + str(
            cfg["attempts"]
        )
        + "</b> failed attempts\n"

        "Block duration: <b>"
        + block_type
        + "</b>\n"

        "Whitelist: "
        + str(
            len(
                cfg["whitelist"]
            )
        )
        + " IP(s)\n\n"

        "<i>The guard applies changes within about 5 seconds.</i>"
    )

    attempts_row = []

    for n in (
        3,
        5,
        10,
        20
    ):

        label = (
            "● "
            + str(n)
            if cfg["attempts"] == n
            else str(n)
        )

        attempts_row.append(
            btn(
                label,
                "pr:at:"
                + str(n)
            )
        )

    durations = (
        (600, "10m"),
        (3600, "1h"),
        (21600, "6h"),
        (86400, "24h"),
        (604800, "7d"),
    )

    duration_row = []

    for sec, label in durations:

        selected = (
            cfg["duration"]
            == sec
            and not cfg["permanent"]
        )

        duration_row.append(
            btn(
                (
                    "● "
                    + label
                    if selected
                    else label
                ),
                "pr:du:"
                + str(sec)
            )
        )

    markup = kb([
        [
            btn(
                "❌ Disable protection"
                if cfg["enabled"]
                else "✅ Enable protection",
                "pr:en"
            )
        ],

        [
            btn(
                "Attempts:",
                "noop"
            )
        ]
        + attempts_row,

        [
            btn(
                "Duration:",
                "noop"
            )
        ]
        + duration_row,

        [
            btn(
                "♾ Permanent: "
                + (
                    "ON"
                    if cfg["permanent"]
                    else "OFF"
                ),
                "pr:pm"
            )
        ],

        BACK_ROW,
    ])

    return (
        text,
        markup
    )


def view_whitelist():

    cfg = load_config()

    wl = cfg["whitelist"]

    lines = [
        "✅ <b>Whitelist</b>",
        "",
    ]

    if not wl:

        lines.append(
            "The list is empty."
        )

    for ip in wl:

        lines.append(
            "• <code>"
            + esc(ip)
            + "</code>"
        )

    lines.append(
        "\nAdd: <code>/whitelist add 1.2.3.4</code>"
        "\nor just send an IP address to the bot."
    )

    rows = []

    pair = []

    for ip in wl[:20]:

        pair.append(
            btn(
                "🗑 "
                + ip,
                "wd:"
                + ip
            )
        )

        if len(pair) == 2:

            rows.append(
                pair
            )

            pair = []

    if pair:

        rows.append(
            pair
        )

    rows.append(
        BACK_ROW
    )

    return (
        "\n".join(lines),
        kb(rows)
    )


def view_notify():

    s = settings()

    muted_until = to_int(
        s.get(
            "mute_until"
        ),
        0
    )

    text = (
        "🔔 <b>Notifications</b>\n\n"

        "Tap to turn a notification on or off.\n\n"

        "⭐ <b>Important only</b> hides minor events "
        "(unblocks, failed attempts, service starts).\n"

        "🚨 Critical alerts are always delivered, "
        "even when muted.\n\n"

        "🔐 <b>SSH key changes</b> are generated by "
        "the SSH Key Guard when an authorized_keys "
        "file changes.\n\n"

        "The daily report is sent at <b>"
        + "{:02d}".format(
            to_int(
                s["report_hour"]
            )
        )
        + ":00</b> (server time)."
    )

    if muted_until > time.time():

        text += (
            "\n\n🔕 Muted until <b>"
            + datetime.fromtimestamp(
                muted_until
            ).strftime(
                "%d.%m %H:%M"
            )
            + "</b>."
        )

    rows = []

    for key, label in NOTIFY_LABELS.items():

        enabled = bool(
            s.get(
                key
            )
        )

        rows.append([
            btn(
                (
                    "✅ "
                    if enabled
                    else "❌ "
                )
                + label,
                "nt:"
                + key
            )
        ])

    hour_row = [
        btn(
            "🕘 Report at:",
            "noop"
        )
    ]

    for h in (
        6,
        9,
        18,
        22
    ):

        hour_row.append(
            btn(
                (
                    "● "
                    + str(h)
                    if to_int(
                        s["report_hour"]
                    ) == h
                    else str(h)
                ),
                "nt:hr:"
                + str(h)
            )
        )

    rows.append(
        hour_row
    )

    rows.append([
        btn(
            "🔕 1h",
            "mu:60"
        ),
        btn(
            "🔕 8h",
            "mu:480"
        ),
        btn(
            "🔔 Unmute",
            "mu:0"
        ),
    ])

    rows.append(
        BACK_ROW
    )

    return (
        text,
        kb(rows)
    )


async def view_ip(
    ip: str
):

    geo = await geo_lookup(
        ip,
        force=True
    )

    blocks = load_blocks()

    cfg = load_config()

    rec = blocks.get(
        ip
    )

    in_wl = (
        ip in cfg["whitelist"]
    )

    cutoff = (
        time.time()
        - 7 * 86400
    )

    events = [
        e
        for e in load_events()
        if (
            e.get("ip") == ip
            and ev_time(e)
            >= cutoff
        )
    ]

    failed = [
        e
        for e in events
        if e.get(
            "type"
        ) == "failed"
    ]

    success = [
        e
        for e in events
        if e.get(
            "type"
        ) == "success"
    ]

    users = Counter(
        e.get(
            "username",
            "?"
        )
        for e in failed
    )

    lines = [
        "🔎 <b>IP</b> <code>"
        + esc(ip)
        + "</code>",
        "",
    ]

    if geo:

        lines.append(
            geo
        )

    if rec:

        if rec.get(
            "permanent"
        ):

            lines.append(
                "Status: 🚫 blocked "
                "<b>permanently</b>"
            )

        else:

            left = max(
                0,
                to_int(
                    rec.get(
                        "expires_at"
                    )
                )
                - time.time()
            )

            lines.append(
                "Status: 🚫 blocked, "
                "<b>"
                + fmt_dur(left)
                + "</b> left"
            )

    else:

        lines.append(
            "Status: not blocked"
        )

    lines.append(
        "Whitelist: "
        + (
            "✅ yes"
            if in_wl
            else "no"
        )
    )

    lines.append(
        "\nLast 7 days: 🔴 "
        + str(
            len(failed)
        )
        + " failed · 🟢 "
        + str(
            len(success)
        )
        + " logins"
    )

    if events:

        lines.append(
            "Last activity: "
            + fmt_ts(
                max(
                    ev_time(e)
                    for e in events
                )
            )
        )

    if users:

        lines.append(
            "Usernames: "
            + ", ".join(
                esc(u)
                + " ×"
                + str(c)
                for u, c
                in users.most_common(
                    8
                )
            )
        )

    row1 = []

    if rec:

        row1.append(
            btn(
                "🔓 Unblock",
                "ub:"
                + ip
            )
        )

    else:

        row1.append(
            btn(
                "🚫 Block",
                "bk:"
                + ip
            )
        )

    if in_wl:

        row1.append(
            btn(
                "🗑 Remove from whitelist",
                "wd:"
                + ip
            )
        )

    else:

        row1.append(
            btn(
                "✅ Add to whitelist",
                "wa:"
                + ip
            )
        )

    markup = kb([
        row1,

        [
            btn(
                "🔄 Refresh",
                "ip:"
                + ip
            )
        ],

        BACK_ROW,
    ])

    return (
        "\n".join(lines),
        markup
    )


def build_report(
    hours=24
) -> str:

    now = time.time()

    cutoff = (
        now
        - hours * 3600
    )

    events = load_events()

    failed = [
        e
        for e in events
        if (
            e.get("type")
            == "failed"
            and ev_time(e)
            >= cutoff
        )
    ]

    success = [
        e
        for e in events
        if (
            e.get("type")
            == "success"
            and ev_time(e)
            >= cutoff
        )
    ]

    blocks = load_blocks()

    new_blocks = [
        r
        for r in blocks.values()
        if to_int(
            r.get(
                "blocked_at"
            )
        ) >= cutoff
    ]

    ssh_key_events = load_ssh_key_events()

    ssh_key_changes = [
        e
        for e in ssh_key_events
        if ssh_key_event_time(e)
        >= cutoff
    ]

    lines = [

        "📅 <b>ServerGuard report, "
        "last 24 hours</b>",

        "",

        "⚠️ Failed attempts: <b>"
        + str(
            len(failed)
        )
        + "</b>",

        "🌐 Unique attacking IPs: <b>"
        + str(
            len(
                {
                    e.get("ip")
                    for e in failed
                }
            )
        )
        + "</b>",

        "🔑 Successful logins: <b>"
        + str(
            len(success)
        )
        + "</b>",

        "🔐 SSH key changes: <b>"
        + str(
            len(
                ssh_key_changes
            )
        )
        + "</b>",

        "🚫 New blocks (still active): <b>"
        + str(
            len(new_blocks)
        )
        + "</b>",

        "🚫 Total active blocks: <b>"
        + str(
            len(blocks)
        )
        + "</b>",
    ]

    top = Counter(
        e.get(
            "ip",
            "?"
        )
        for e in failed
    ).most_common(
        5
    )

    if top:

        lines.append(
            "\n<b>Top attackers:</b>"
        )

        for ip, count in top:

            lines.append(
                "• <code>"
                + esc(ip)
                + "</code> — "
                + str(count)
            )

    if success:

        ips = Counter(
            e.get(
                "ip",
                "?"
            )
            for e in success
        )

        lines.append(
            "\n<b>Logins:</b>"
        )

        for ip, count in ips.most_common(
            5
        ):

            lines.append(
                "• <code>"
                + esc(ip)
                + "</code> ×"
                + str(count)
            )

    if ssh_key_changes:

        lines.append(
            "\n<b>SSH key changes:</b>"
        )

        for event in ssh_key_changes[-5:]:

            action = ssh_key_action(
                event
            )

            account = ssh_key_account(
                event
            )

            lines.append(
                "• "
                + esc(action)
                + " — <b>"
                + esc(account)
                + "</b>"
            )

    return "\n".join(
        lines
    )


# ============================================================
# HELP
# ============================================================

HELP_TEXT = (
    "❓ <b>Commands</b>\n\n"

    "/menu — main menu\n"

    "/status — status and statistics\n"

    "/blocks — active blocks\n"

    "/events — recent events\n"

    "/top — top attackers\n"

    "/server — server status\n"

    "/ip <code>1.2.3.4</code> — IP information\n"

    "/block <code>1.2.3.4</code> "
    "[minutes | perm] — block an IP\n"

    "/unblock <code>1.2.3.4</code> "
    "— unblock an IP\n"

    "/whitelist [add|del <code>IP</code>] "
    "— manage the whitelist\n"

    "/mute [minutes] — silence everything "
    "except critical alerts\n"

    "/unmute — turn notifications back on\n\n"

    "You can also just send an IP address — "
    "the bot will show a card with buttons.\n\n"

    "🔐 <b>SSH Key Guard</b>\n"

    "The bot automatically monitors "
    "<code>ssh_key_events.json</code> and "
    "notifies you when SSH keys are added, "
    "removed or changed.\n\n"

    "📥 <b>Message queue</b>\n"

    "Any script on the server can drop a "
    "<code>.txt</code> or <code>.json</code> file "
    "into the queue directory."
)


# ============================================================
# RENDER
# ============================================================

async def render(
    target,
    text: str,
    markup=None
):

    if isinstance(
        target,
        CallbackQuery
    ):

        try:

            await target.message.edit_text(
                text,
                reply_markup=markup
            )

        except TelegramBadRequest as e:

            if (
                "not modified"
                not in str(e).lower()
            ):

                await target.message.answer(
                    text,
                    reply_markup=markup
                )

    else:

        await target.answer(
            text,
            reply_markup=markup
        )


# ============================================================
# THROTTLE
# ============================================================

class Throttle:

    def __init__(self):

        self.sent = {}

        self.suppressed = Counter()


    def _limit(
        self,
        category: str,
        level: str
    ) -> int:

        limit = THROTTLE_LIMITS.get(
            category,
            THROTTLE_LIMITS["misc"]
        )

        if level == "critical":

            return limit * 3

        return limit


    def _window(
        self,
        category: str
    ) -> deque:

        now = time.time()

        q = self.sent.setdefault(
            category,
            deque()
        )

        while (
            q
            and now - q[0]
            > THROTTLE_WINDOW
        ):

            q.popleft()

        return q


    def allow(
        self,
        category: str,
        level: str
    ) -> bool:

        q = self._window(
            category
        )

        if len(q) >= self._limit(
            category,
            level
        ):

            self.suppressed[
                category
            ] += 1

            return False

        q.append(
            time.time()
        )

        return True


    def pop_summaries(self) -> list:

        ready = []

        for category, count in list(
            self.suppressed.items()
        ):

            if (
                count > 0
                and len(
                    self._window(
                        category
                    )
                )
                < self._limit(
                    category,
                    "normal"
                )
            ):

                ready.append(
                    (
                        category,
                        count
                    )
                )

                del self.suppressed[
                    category
                ]

        return ready


THROTTLE = Throttle()


def is_muted() -> bool:

    return (
        time.time()
        < to_int(
            settings().get(
                "mute_until"
            ),
            0
        )
    )


async def notify(
    bot: Bot,
    text: str,
    markup=None,
    category: str = "misc",
    level: str = "normal",
    throttle: bool = True
) -> bool:

    chat_id = OWNER.get(
        "chat_id"
    )

    if not chat_id:

        return False

    s = settings()

    if (
        level == "low"
        and s.get(
            "important_only"
        )
    ):

        return False

    if (
        level != "critical"
        and is_muted()
    ):

        return False

    if (
        throttle
        and not THROTTLE.allow(
            category,
            level
        )
    ):

        return False

    try:

        await bot.send_message(
            chat_id,
            text[:4000],
            reply_markup=markup,
            disable_notification=(
                level == "low"
            ),
        )

        return True

    except TelegramAPIError as e:

        log.warning(
            "Cannot send notification: %s",
            e
        )

        return False


# ============================================================
# ACCESS
# ============================================================

class AccessMiddleware(
    BaseMiddleware
):

    async def __call__(
        self,
        handler,
        event,
        data
    ):

        if isinstance(
            event,
            Message
        ):

            user = event.from_user

            if (
                user is None
                or event.chat.type
                != "private"
            ):

                return None

            if is_owner(
                user.id
            ):

                return await handler(
                    event,
                    data
                )

            if (
                event.text or ""
            ).startswith(
                "/start"
            ):

                return await handler(
                    event,
                    data
                )

            return None

        if isinstance(
            event,
            CallbackQuery
        ):

            if is_owner(
                event.from_user.id
            ):

                return await handler(
                    event,
                    data
                )

            try:

                await event.answer(
                    "⛔ Access denied",
                    show_alert=True
                )

            except TelegramAPIError:

                pass

            return None

        return await handler(
            event,
            data
        )


router.message.outer_middleware(
    AccessMiddleware()
)


router.callback_query.outer_middleware(
    AccessMiddleware()
)


# ============================================================
# REGISTRATION
# ============================================================

def reg_wait_seconds(
    user_id: int
) -> int:

    now = time.time()

    mine = [
        t
        for t in USER_FAILS.get(
            user_id,
            []
        )
        if now - t < REG_WINDOW
    ]

    USER_FAILS[
        user_id
    ] = mine

    while (
        GLOBAL_FAILS
        and now - GLOBAL_FAILS[0]
        >= REG_WINDOW
    ):

        GLOBAL_FAILS.popleft()

    if len(mine) >= REG_USER_LIMIT:

        return int(
            REG_WINDOW
            - (
                now
                - mine[0]
            )
        )

    if (
        len(GLOBAL_FAILS)
        >= REG_GLOBAL_LIMIT
    ):

        return int(
            REG_WINDOW
            - (
                now
                - GLOBAL_FAILS[0]
            )
        )

    return 0


def reg_register_fail(
    user_id: int
):

    now = time.time()

    USER_FAILS.setdefault(
        user_id,
        []
    ).append(
        now
    )

    GLOBAL_FAILS.append(
        now
    )


NOT_REGISTERED_TEXT = (
    "👋 This is the <b>ServerGuard</b> bot.\n\n"

    "To register:\n"

    "1. On the server open ServerGuard → "
    "Telegram bot → <b>Generate verification code</b>\n"

    "2. Send it here: <code>/start CODE</code>\n\n"

    "The code is valid for 5 minutes."
)


async def try_register(
    message: Message,
    code: str
):

    user = message.from_user

    wait = reg_wait_seconds(
        user.id
    )

    if wait:

        await message.answer(
            "⏳ Too many wrong attempts. "
            "Try again in "
            + fmt_dur(
                wait
            )
            + "."
        )

        return

    ver = load_json(
        VERIFICATION_FILE,
        None
    )

    if (
        not isinstance(
            ver,
            dict
        )
        or not ver.get(
            "code"
        )
    ):

        await message.answer(
            "❌ There is no active code. "
            "Generate a new one on the server."
        )

        return

    if (
        time.time()
        > to_int(
            ver.get(
                "expires_at"
            ),
            0
        )
    ):

        try:

            VERIFICATION_FILE.unlink()

        except Exception:

            pass

        await message.answer(
            "⌛ The code has expired. "
            "Generate a new one on the server."
        )

        return

    if not hmac.compare_digest(
        str(
            ver["code"]
        ),
        code
    ):

        reg_register_fail(
            user.id
        )

        try:

            await message.delete()

        except TelegramAPIError:

            pass

        left = max(
            0,
            REG_USER_LIMIT
            - len(
                USER_FAILS.get(
                    user.id,
                    []
                )
            )
        )

        await message.answer(
            "❌ Wrong code. Attempts left: "
            + str(left)
        )

        return

    try:

        await message.delete()

    except TelegramAPIError:

        pass

    previous = dict(
        OWNER
    )

    new_owner = {

        "user_id":
            user.id,

        "chat_id":
            message.chat.id,

        "username":
            user.username
            or "",

        "first_name":
            user.full_name
            or "",

        "registered_at":
            int(
                time.time()
            ),

        "settings":
            (
                previous.get(
                    "settings",
                    {}
                )
                if isinstance(
                    previous.get(
                        "settings"
                    ),
                    dict
                )
                else {}
            ),

        "known_ips":
            (
                previous.get(
                    "known_ips",
                    []
                )
                if isinstance(
                    previous.get(
                        "known_ips"
                    ),
                    list
                )
                else []
            ),
    }

    new_owner[
        "settings"
    ][
        "last_report"
    ] = datetime.now().strftime(
        "%Y-%m-%d"
    )

    OWNER.clear()

    OWNER.update(
        new_owner
    )

    save_owner()

    seed_known_ips()

    try:

        VERIFICATION_FILE.unlink()

    except Exception:

        pass

    if (
        previous.get(
            "chat_id"
        )
        and previous.get(
            "user_id"
        )
        != user.id
    ):

        try:

            await message.bot.send_message(
                previous[
                    "chat_id"
                ],
                "⚠️ Access to this bot has been transferred "
                "to another account."
            )

        except TelegramAPIError:

            pass

    log.info(
        "Owner registered: %s (%s)",
        user.id,
        user.username
    )

    await message.answer(
        "✅ <b>Registration complete!</b>\n\n"

        "You will now receive notifications about "
        "blocks, SSH logins, services and SSH key changes.\n\n"

        "Only important events are shown by default. "
        "Tune it in 🔔 Notifications."
    )

    text, markup = view_menu()

    await message.answer(
        text,
        reply_markup=markup
    )


# ============================================================
# COMMAND HANDLERS
# ============================================================

@router.message(
    Command("start")
)
async def cmd_start(
    message: Message,
    command: CommandObject
):

    code = "".join(
        (
            command.args
            or ""
        ).split()
    )

    if not code:

        if is_owner(
            message.from_user.id
        ):

            text, markup = (
                view_menu()
            )

            await message.answer(
                text,
                reply_markup=markup
            )

        else:

            await message.answer(
                NOT_REGISTERED_TEXT
            )

        return

    await try_register(
        message,
        code
    )


@router.message(
    Command("menu")
)
async def cmd_menu(
    message: Message
):

    text, markup = (
        view_menu()
    )

    await message.answer(
        text,
        reply_markup=markup
    )


@router.message(
    Command("help")
)
async def cmd_help(
    message: Message
):

    await message.answer(
        HELP_TEXT,
        reply_markup=kb([
            BACK_ROW
        ])
    )


@router.message(
    Command("status")
)
async def cmd_status(
    message: Message
):

    text, markup = (
        view_status()
    )

    await message.answer(
        text,
        reply_markup=markup
    )


@router.message(
    Command("blocks")
)
async def cmd_blocks(
    message: Message
):

    text, markup = (
        view_blocks(0)
    )

    await message.answer(
        text,
        reply_markup=markup
    )


@router.message(
    Command("events")
)
async def cmd_events(
    message: Message
):

    text, markup = (
        view_events("all")
    )

    await message.answer(
        text,
        reply_markup=markup
    )


@router.message(
    Command("top")
)
async def cmd_top(
    message: Message
):

    text, markup = (
        view_top(24)
    )

    await message.answer(
        text,
        reply_markup=markup
    )


@router.message(
    Command("server")
)
async def cmd_server(
    message: Message
):

    text, markup = (
        view_server()
    )

    await message.answer(
        text,
        reply_markup=markup
    )


@router.message(
    Command("ip")
)
async def cmd_ip(
    message: Message,
    command: CommandObject
):

    ip = parse_ip(
        command.args or ""
    )

    if not ip:

        await message.answer(
            "Usage: <code>/ip 1.2.3.4</code>"
        )

        return

    text, markup = await view_ip(
        ip
    )

    await message.answer(
        text,
        reply_markup=markup
    )


@router.message(
    Command("block")
)
async def cmd_block(
    message: Message,
    command: CommandObject
):

    parts = (
        command.args
        or ""
    ).split()

    if not parts:

        await message.answer(
            "Usage:\n"
            "<code>/block 1.2.3.4</code>\n"
            "<code>/block 1.2.3.4 60</code>\n"
            "<code>/block 1.2.3.4 perm</code>"
        )

        return

    ip = parse_ip(
        parts[0]
    )

    if not ip:

        await message.answer(
            "❌ Invalid IP address."
        )

        return

    cfg = load_config()

    permanent = cfg[
        "permanent"
    ]

    duration = cfg[
        "duration"
    ]

    if len(parts) > 1:

        arg = parts[1].lower()

        if arg in (
            "perm",
            "permanent",
            "forever"
        ):

            permanent = True

        else:

            minutes = to_int(
                arg,
                0
            )

            if minutes <= 0:

                await message.answer(
                    "❌ Specify duration in minutes "
                    "or <code>perm</code>."
                )

                return

            permanent = False

            duration = (
                minutes * 60
            )

    ok, info = await do_block(
        ip,
        permanent,
        duration,
        "Manual block via Telegram"
    )

    if ok:

        term = (
            "permanently"
            if permanent
            else "for "
            + fmt_dur(
                max(
                    60,
                    duration
                )
            )
        )

        await message.answer(
            "🚫 <code>"
            + esc(ip)
            + "</code> blocked "
            + term
            + "."
        )

    else:

        await message.answer(
            "❌ Failed: "
            + esc(info)
        )


@router.message(
    Command("unblock")
)
async def cmd_unblock(
    message: Message,
    command: CommandObject
):

    ip = parse_ip(
        command.args or ""
    )

    if not ip:

        await message.answer(
            "Usage: <code>/unblock 1.2.3.4</code>"
        )

        return

    ok, info = await do_unblock(
        ip
    )

    if ok:

        await message.answer(
            "✅ <code>"
            + esc(ip)
            + "</code> unblocked."
        )

    else:

        await message.answer(
            "❌ Failed: "
            + esc(info)
        )


@router.message(
    Command("whitelist")
)
async def cmd_whitelist(
    message: Message,
    command: CommandObject
):

    parts = (
        command.args
        or ""
    ).split()

    if not parts:

        text, markup = (
            view_whitelist()
        )

        await message.answer(
            text,
            reply_markup=markup
        )

        return

    action = parts[
        0
    ].lower()

    ip = (
        parse_ip(
            parts[1]
        )
        if len(parts) > 1
        else None
    )

    if (
        action not in (
            "add",
            "del",
            "remove",
            "rm"
        )
        or not ip
    ):

        await message.answer(
            "Usage:\n"
            "<code>/whitelist add 1.2.3.4</code>\n"
            "<code>/whitelist del 1.2.3.4</code>"
        )

        return

    if action == "add":

        added = whitelist_add(
            ip
        )

        blocked = (
            ip in load_blocks()
        )

        if blocked:

            await do_unblock(
                ip
            )

        await message.answer(
            "✅ <code>"
            + esc(ip)
            + "</code> "
            + (
                "added to the whitelist."
                if added
                else "is already in the whitelist."
            )
            + (
                " Block removed."
                if blocked
                else ""
            )
        )

    else:

        removed = whitelist_remove(
            ip
        )

        await message.answer(
            "🗑 <code>"
            + esc(ip)
            + "</code> "
            + (
                "removed from the whitelist."
                if removed
                else "was not found in the whitelist."
            )
        )


@router.message(
    Command("mute")
)
async def cmd_mute(
    message: Message,
    command: CommandObject
):

    minutes = max(
        1,
        min(
            to_int(
                (
                    command.args
                    or ""
                ).strip(),
                60
            ),
            7 * 24 * 60
        )
    )

    set_setting(
        "mute_until",
        int(
            time.time()
        )
        + minutes * 60
    )

    await message.answer(
        "🔕 Muted for <b>"
        + fmt_dur(
            minutes * 60
        )
        + "</b>. Critical alerts still come through."
    )


@router.message(
    Command("unmute")
)
async def cmd_unmute(
    message: Message
):

    set_setting(
        "mute_until",
        0
    )

    await message.answer(
        "🔔 Notifications are back on."
    )


@router.message(
    F.text
)
async def on_text(
    message: Message
):

    ip = parse_ip(
        message.text or ""
    )

    if ip:

        text, markup = await view_ip(
            ip
        )

        await message.answer(
            text,
            reply_markup=markup
        )

        return

    await message.answer(
        "I didn't get that 🤔 "
        "Open /menu or /help."
    )


# ============================================================
# CALLBACKS
# ============================================================

def info_only_markup(
    ip: str
) -> InlineKeyboardMarkup:

    return kb([
        [
            btn(
                "🔎 Info",
                "ip:"
                + ip
            )
        ]
    ])


async def refresh_after(
    cb: CallbackQuery,
    ip: str
):

    head = (
        cb.message.text
        or ""
    )

    if head.startswith(
        "🚫 Active blocks"
    ):

        text, markup = (
            view_blocks(0)
        )

        await render(
            cb,
            text,
            markup
        )

    elif head.startswith(
        "🔎"
    ):

        text, markup = await view_ip(
            ip
        )

        await render(
            cb,
            text,
            markup
        )

    elif head.startswith(
        "✅ Whitelist"
    ):

        text, markup = (
            view_whitelist()
        )

        await render(
            cb,
            text,
            markup
        )

    else:

        try:

            await cb.message.edit_reply_markup(
                reply_markup=info_only_markup(
                    ip
                )
            )

        except TelegramAPIError:

            pass


async def handle_callback(
    cb: CallbackQuery
):

    action, _, arg = (
        cb.data or ""
    ).partition(":")

    if action == "noop":

        return None

    if action == "m":

        await render(
            cb,
            *view_menu()
        )

    elif action == "st":

        await render(
            cb,
            *view_status()
        )

    elif action == "bp":

        await render(
            cb,
            *view_blocks(
                to_int(
                    arg,
                    0
                )
            )
        )

    elif action == "ev":

        await render(
            cb,
            *view_events(
                arg
                if arg in (
                    "all",
                    "failed",
                    "success"
                )
                else "all"
            )
        )

    elif action == "tp":

        await render(
            cb,
            *view_top(
                to_int(
                    arg,
                    24
                )
            )
        )

    elif action == "sv":

        await render(
            cb,
            *view_server()
        )

    elif action == "lg":

        text, markup = await view_logs()

        await render(
            cb,
            text,
            markup
        )

    elif action == "pr":

        sub, _, val = (
            arg.partition(":")
        )

        cfg = load_config()

        if sub == "en":

            update_protection(
                {
                    "enabled":
                        not cfg["enabled"]
                }
            )

        elif sub == "pm":

            update_protection(
                {
                    "permanent":
                        not cfg["permanent"]
                }
            )

        elif sub == "at":

            update_protection(
                {
                    "attempts":
                        max(
                            1,
                            min(
                                to_int(
                                    val,
                                    5
                                ),
                                100
                            )
                        )
                }
            )

        elif sub == "du":

            update_protection(
                {
                    "duration":
                        max(
                            60,
                            to_int(
                                val,
                                600
                            )
                        ),

                    "permanent":
                        False,
                }
            )

        await render(
            cb,
            *view_protection()
        )

    elif action == "wl":

        await render(
            cb,
            *view_whitelist()
        )

    elif action == "wa":

        ip = parse_ip(
            arg
        )

        if not ip:

            return "Invalid IP address"

        added = whitelist_add(
            ip
        )

        if ip in load_blocks():

            await do_unblock(
                ip
            )

        await refresh_after(
            cb,
            ip
        )

        return (
            "✅ Added to the whitelist"
            if added
            else "Already in the whitelist"
        )

    elif action == "wd":

        ip = parse_ip(
            arg
        )

        if not ip:

            return "Invalid IP address"

        removed = whitelist_remove(
            ip
        )

        await refresh_after(
            cb,
            ip
        )

        return (
            "🗑 Removed from the whitelist"
            if removed
            else "Not found"
        )

    elif action == "nt":

        if arg.startswith(
            "hr:"
        ):

            hour = max(
                0,
                min(
                    to_int(
                        arg[3:],
                        9
                    ),
                    23
                )
            )

            set_setting(
                "report_hour",
                hour
            )

        elif arg in NOTIFY_LABELS:

            set_setting(
                arg,
                not settings().get(
                    arg,
                    False
                )
            )

        await render(
            cb,
            *view_notify()
        )

    elif action == "mu":

        minutes = max(
            0,
            min(
                to_int(
                    arg,
                    0
                ),
                7 * 24 * 60
            )
        )

        set_setting(
            "mute_until",
            (
                int(
                    time.time()
                )
                + minutes * 60
                if minutes
                else 0
            )
        )

        await render(
            cb,
            *view_notify()
        )

        return (
            "🔕 Muted for "
            + fmt_dur(
                minutes * 60
            )
            if minutes
            else "🔔 Notifications on"
        )

    elif action == "ip":

        ip = parse_ip(
            arg
        )

        if not ip:

            return "Invalid IP address"

        text, markup = await view_ip(
            ip
        )

        await render(
            cb,
            text,
            markup
        )

    elif action == "ub":

        ip = parse_ip(
            arg
        )

        if not ip:

            return "Invalid IP address"

        ok, info = await do_unblock(
            ip
        )

        if not ok:

            return (
                "❌ "
                + info[:150]
            )

        await refresh_after(
            cb,
            ip
        )

        return "✅ Unblocked"

    elif action == "bk":

        ip = parse_ip(
            arg
        )

        if not ip:

            return "Invalid IP address"

        cfg = load_config()

        ok, info = await do_block(
            ip,
            cfg["permanent"],
            cfg["duration"],
            "Manual block via Telegram"
        )

        if not ok:

            return (
                "❌ "
                + info[:150]
            )

        await refresh_after(
            cb,
            ip
        )

        return "🚫 Blocked"

    elif action == "ua":

        await render(
            cb,
            *view_unblock_all_confirm()
        )

    elif action == "uay":

        blocks = list(
            load_blocks().keys()
        )

        done = 0

        for ip in blocks:

            ok, _ = await do_unblock(
                ip
            )

            if ok:

                done += 1

        await render(
            cb,
            *view_blocks(0)
        )

        return (
            "✅ Unblocked: "
            + str(done)
            + "/"
            + str(len(blocks))
        )

    return None


@router.callback_query()
async def on_callback(
    cb: CallbackQuery
):

    toast = None

    if cb.message is None:

        try:

            await cb.answer()

        except TelegramAPIError:

            pass

        return

    try:

        toast = await handle_callback(
            cb
        )

    except Exception as e:

        log.exception(
            "Callback error: %s",
            e
        )

        toast = (
            "Error, check the logs"
        )

    try:

        await cb.answer(
            toast or ""
        )

    except TelegramAPIError:

        pass


# ============================================================
# BACKGROUND: WATCH BRUTE FORCE GUARD
# ============================================================

def event_key(
    e: dict
) -> str:

    return "|".join(
        str(
            e.get(
                k,
                ""
            )
        )
        for k in (
            "time",
            "type",
            "ip",
            "username",
            "raw"
        )
    )


class Watcher:

    def __init__(
        self,
        bot: Bot
    ):

        self.bot = bot

        self.events_mtime = (
            mtime_ns(
                EVENTS_FILE
            )
        )

        self.blocks_mtime = (
            mtime_ns(
                BLOCKS_FILE
            )
        )

        self.seen = Counter(
            event_key(e)
            for e in load_events()
        )

        self.prev_blocks = (
            load_blocks()
        )


    async def run(self):

        while True:

            await asyncio.sleep(
                POLL_INTERVAL
            )

            try:

                await self.check_blocks()

                await self.check_events()

            except Exception as e:

                log.exception(
                    "Watcher error: %s",
                    e
                )


    async def check_blocks(self):

        current_mtime = (
            mtime_ns(
                BLOCKS_FILE
            )
        )

        if (
            current_mtime
            == self.blocks_mtime
        ):

            return

        self.blocks_mtime = (
            current_mtime
        )

        current = load_blocks()

        previous = self.prev_blocks

        self.prev_blocks = current

        s = settings()

        for ip, rec in current.items():

            old = previous.get(
                ip
            )

            stamp = rec.get(
                "blocked_at"
            )

            if (
                old is not None
                and old.get(
                    "blocked_at"
                ) == stamp
            ):

                continue

            if (
                ip,
                stamp
            ) in SUPPRESS_BLOCK:

                SUPPRESS_BLOCK.discard(
                    (
                        ip,
                        stamp
                    )
                )

                continue

            if not (
                OWNER
                and s.get(
                    "notify_block"
                )
            ):

                continue

            await self.send_block(
                ip,
                rec
            )

        for ip, rec in previous.items():

            if ip in current:

                continue

            if ip in SUPPRESS_UNBLOCK:

                SUPPRESS_UNBLOCK.discard(
                    ip
                )

                continue

            if not (
                OWNER
                and s.get(
                    "notify_unblock"
                )
            ):

                continue

            expired = (
                not rec.get(
                    "permanent"
                )
                and to_int(
                    rec.get(
                        "expires_at"
                    ),
                    0
                )
                <= time.time()
                + POLL_INTERVAL
            )

            reason = (
                "the block has expired"
                if expired
                else "removed manually on the server"
            )

            await notify(
                self.bot,

                "✅ <b>IP unblocked</b>\n"
                "<code>"
                + esc(ip)
                + "</code>\n"
                "Reason: "
                + reason,

                info_only_markup(
                    ip
                ),

                category="block",

                level="low",
            )


    async def send_block(
        self,
        ip: str,
        rec: dict
    ):

        geo = await geo_lookup(
            ip
        )

        term = block_term(
            rec
        )

        lines = [

            "🚫 <b>IP blocked</b>",

            "",

            "🌐 <code>"
            + esc(ip)
            + "</code>",
        ]

        if geo:

            lines.append(
                geo
            )

        lines.append(
            "⚠️ Failed attempts: <b>"
            + str(
                to_int(
                    rec.get(
                        "failed_attempts"
                    )
                )
            )
            + "</b>"
        )

        lines.append(
            "⏱ Duration: <b>"
            + term
            + "</b>"
        )

        if (
            not rec.get(
                "permanent"
            )
            and rec.get(
                "expires_at"
            )
        ):

            lines.append(
                "🕒 Until: "
                + fmt_ts(
                    rec.get(
                        "expires_at"
                    )
                )
            )

        if rec.get(
            "reason"
        ):

            lines.append(
                "📝 "
                + esc(
                    rec.get(
                        "reason"
                    )
                )
            )

        markup = kb([
            [
                btn(
                    "🔓 Unblock",
                    "ub:"
                    + ip
                ),
                btn(
                    "✅ Add to whitelist",
                    "wa:"
                    + ip
                ),
            ],

            [
                btn(
                    "🔎 Info",
                    "ip:"
                    + ip
                )
            ],
        ])

        await notify(
            self.bot,
            "\n".join(lines),
            markup,
            category="block",
            level="normal"
        )


    async def check_events(self):

        current_mtime = (
            mtime_ns(
                EVENTS_FILE
            )
        )

        if (
            current_mtime
            == self.events_mtime
        ):

            return

        self.events_mtime = (
            current_mtime
        )

        events = load_events()

        remaining = Counter(
            self.seen
        )

        new = []

        for e in events:

            key = event_key(
                e
            )

            if remaining[key] > 0:

                remaining[key] -= 1

            else:

                new.append(
                    e
                )

        self.seen = Counter(
            event_key(e)
            for e in events
        )

        if (
            not new
            or not OWNER
        ):

            return

        s = settings()

        failed = [
            e
            for e in new
            if e.get(
                "type"
            ) == "failed"
        ]

        success = [
            e
            for e in new
            if e.get(
                "type"
            ) == "success"
        ]

        if (
            failed
            and s.get(
                "notify_failed"
            )
        ):

            await self.send_failed(
                failed
            )

        for e in success[:5]:

            await self.send_login(
                e,
                s
            )

        if len(success) > 5:

            await notify(
                self.bot,

                "🔑 …and "
                + str(
                    len(success)
                    - 5
                )
                + " more SSH logins.",

                category="login",

                level="low"
            )


    async def send_failed(
        self,
        failed: list
    ):

        by_ip = {}

        for e in failed:

            by_ip.setdefault(
                e.get(
                    "ip",
                    "?"
                ),
                []
            ).append(
                e
            )

        lines = [
            "⚠️ <b>Failed SSH attempts</b>",
            "",
        ]

        for ip, items in list(
            by_ip.items()
        )[:10]:

            users = ", ".join(
                sorted(
                    {
                        esc(
                            i.get(
                                "username",
                                "?"
                            )
                        )
                        for i in items
                    }
                )[:4]
            )

            lines.append(
                "<code>"
                + esc(ip)
                + "</code> ×"
                + str(
                    len(items)
                )
                + " ("
                + users
                + ")"
            )

        await notify(
            self.bot,
            "\n".join(lines),
            category="failed",
            level="low"
        )


    async def send_login(
        self,
        e: dict,
        s: dict
    ):

        ip = e.get(
            "ip",
            "?"
        )

        is_new = (
            ip not in known_ips()
        )

        if is_new:

            remember_ip(
                ip
            )

        if not (
            s.get(
                "notify_login"
            )
            or (
                is_new
                and s.get(
                    "notify_new_ip"
                )
            )
        ):

            return

        geo = await geo_lookup(
            ip
        )

        lines = [

            "🔑 <b>SSH login</b>",

            "",

            "👤 <b>"
            + esc(
                e.get(
                    "username",
                    "?"
                )
            )
            + "</b>",

            "🌐 <code>"
            + esc(ip)
            + "</code>",
        ]

        if geo:

            lines.append(
                geo
            )

        if e.get(
            "auth_method"
        ):

            lines.append(
                "🔐 "
                + esc(
                    e.get(
                        "auth_method"
                    )
                )
            )

        lines.append(
            "🕒 "
            + fmt_ts(
                e.get(
                    "time"
                )
            )
        )

        if is_new:

            lines.append(
                "\n🆕 <b>New IP</b> — "
                "no successful login from it before.\n"
                "If this wasn't you, block it!"
            )

        markup = kb([
            [
                btn(
                    "🚫 Block",
                    "bk:"
                    + ip
                ),
                btn(
                    "✅ Add to whitelist",
                    "wa:"
                    + ip
                ),
            ],

            [
                btn(
                    "🔎 Info",
                    "ip:"
                    + ip
                )
            ],
        ])

        await notify(
            self.bot,
            "\n".join(lines),
            markup,
            category="login",
            level=(
                "critical"
                if is_new
                else "normal"
            )
        )


# ============================================================
# SSH KEY GUARD WATCHER
# ============================================================

class SSHKeyWatcher:

    """
    Watches ssh_key_events.json produced by SSH Key Guard.

    Expected events may contain:

        action
        type
        time
        path
        account
        username
        owner
        key
        old_key
        modifier
        network
        file
        id

    Existing events are marked as seen during startup,
    so the bot does not send hundreds of old notifications
    after restart.
    """


    def __init__(
        self,
        bot: Bot
    ):

        self.bot = bot

        self.mtime = (
            mtime_ns(
                SSH_KEY_EVENTS_FILE
            )
        )

        self.seen = Counter(
            ssh_key_event_key(event)
            for event
            in load_ssh_key_events()
        )


    async def run(self):

        while True:

            await asyncio.sleep(
                POLL_INTERVAL
            )

            try:

                await self.check_events()

            except Exception as e:

                log.exception(
                    "SSH Key Guard watcher error: %s",
                    e
                )


    def new_events(self) -> list:

        current_mtime = (
            mtime_ns(
                SSH_KEY_EVENTS_FILE
            )
        )

        if (
            current_mtime
            == self.mtime
        ):

            return []

        self.mtime = (
            current_mtime
        )

        events = (
            load_ssh_key_events()
        )

        remaining = Counter(
            self.seen
        )

        new = []

        for event in events:

            key = (
                ssh_key_event_key(
                    event
                )
            )

            if remaining[key] > 0:

                remaining[key] -= 1

            else:

                new.append(
                    event
                )

        self.seen = Counter(
            ssh_key_event_key(event)
            for event in events
        )

        return new


    async def check_events(self):

        new_events = (
            self.new_events()
        )

        if not new_events:

            return

        if not OWNER:

            return

        if not settings().get(
            "notify_ssh_key",
            True
        ):

            return

        for event in new_events:

            await self.send_event(
                event
            )


    def action_title(
        self,
        action: str
    ):

        normalized = (
            action
            .lower()
            .replace(
                "-",
                "_"
            )
            .replace(
                " ",
                "_"
            )
        )

        if normalized in (
            "added",
            "add",
            "key_added",
            "ssh_key_added",
            "created"
        ):

            return (
                "🔐 <b>SSH KEY ADDED</b>",
                "A new SSH key was added."
            )

        if normalized in (
            "removed",
            "remove",
            "key_removed",
            "ssh_key_removed",
            "deleted"
        ):

            return (
                "🚨 <b>SSH KEY REMOVED</b>",
                "An SSH key was removed."
            )

        if normalized in (
            "changed",
            "change",
            "modified",
            "modified_key",
            "key_changed",
            "ssh_key_changed"
        ):

            return (
                "⚠️ <b>SSH KEY CHANGED</b>",
                "An SSH key entry was changed."
            )

        return (
            "🔐 <b>SSH KEY EVENT</b>",
            "SSH key configuration changed."
        )


    def format_modifier(
        self,
        event: dict
    ) -> list:

        modifier = ssh_key_modifier(
            event
        )

        lines = []

        if not modifier:

            return lines

        username = (
            modifier.get(
                "username"
            )
            or modifier.get(
                "user"
            )
        )

        uid = modifier.get(
            "uid"
        )

        auid = modifier.get(
            "auid"
        )

        pid = modifier.get(
            "pid"
        )

        ppid = modifier.get(
            "ppid"
        )

        process = (
            modifier.get(
                "process"
            )
            or modifier.get(
                "process_name"
            )
        )

        exe = modifier.get(
            "exe"
        )

        command = modifier.get(
            "command"
        )

        cwd = modifier.get(
            "cwd"
        )

        success = modifier.get(
            "success"
        )

        audit_serial = (
            modifier.get(
                "audit_serial"
            )
            or modifier.get(
                "serial"
            )
        )

        if username:

            line = (
                "👤 Modifier: <b>"
                + esc(
                    username
                )
                + "</b>"
            )

            if uid is not None:

                line += (
                    " · UID "
                    + esc(uid)
                )

            lines.append(
                line
            )

        elif uid is not None:

            lines.append(
                "👤 UID: <code>"
                + esc(uid)
                + "</code>"
            )

        if auid is not None:

            lines.append(
                "🆔 AUID: <code>"
                + esc(auid)
                + "</code>"
            )

        if process:

            line = (
                "⚙️ Process: <code>"
                + esc(
                    process
                )
                + "</code>"
            )

            if pid is not None:

                line += (
                    " · PID <code>"
                    + esc(pid)
                    + "</code>"
                )

            lines.append(
                line
            )

        elif pid is not None:

            lines.append(
                "⚙️ PID: <code>"
                + esc(pid)
                + "</code>"
            )

        if ppid is not None:

            lines.append(
                "↳ PPID: <code>"
                + esc(ppid)
                + "</code>"
            )

        if exe:

            lines.append(
                "📦 Executable: <code>"
                + esc(exe)
                + "</code>"
            )

        if command:

            lines.append(
                "⌨️ Command: <code>"
                + esc(command)
                + "</code>"
            )

        if cwd:

            lines.append(
                "📂 CWD: <code>"
                + esc(cwd)
                + "</code>"
            )

        if success is not None:

            lines.append(
                "📌 Audit result: "
                + (
                    "✅ success"
                    if to_bool(
                        success
                    )
                    else "❌ failed"
                )
            )

        if audit_serial is not None:

            lines.append(
                "🧾 Audit serial: <code>"
                + esc(
                    audit_serial
                )
                + "</code>"
            )

        return lines


    def format_network(
        self,
        event: dict
    ) -> list:

        network = ssh_key_network(
            event
        )

        lines = []

        source_ip = ""

        if network:

            source_ip = (
                network.get(
                    "source_ip"
                )
                or network.get(
                    "ip"
                )
                or network.get(
                    "addr"
                )
                or ""
            )

        if not source_ip:

            source_ip = (
                event.get(
                    "source_ip"
                )
                or event.get(
                    "ip"
                )
                or ""
            )

        if source_ip:

            lines.append(
                "🌐 Source IP: <code>"
                + esc(
                    source_ip
                )
                + "</code>"
            )

            source = (
                network.get(
                    "source"
                )
                if network
                else event.get(
                    "source_ip_source"
                )
            )

            if source:

                lines.append(
                    "   Source: "
                    + esc(
                        source
                    )
                )

        return lines


    async def send_event(
        self,
        event: dict
    ):

        action = ssh_key_action(
            event
        )

        title, description = (
            self.action_title(
                action
            )
        )

        account = ssh_key_account(
            event
        )

        path = ssh_key_path(
            event
        )

        fingerprint = (
            ssh_key_fingerprint(
                event
            )
        )

        key_type = ssh_key_type(
            event
        )

        comment = ssh_key_comment(
            event
        )

        lines = [

            title,

            "",

            "📌 "
            + description,

            "👤 Account: <b>"
            + esc(account)
            + "</b>",

            "📁 File: <code>"
            + esc(path)
            + "</code>",
        ]

        if key_type:

            lines.append(
                "🔑 Type: <code>"
                + esc(
                    key_type
                )
                + "</code>"
            )

        if fingerprint:

            lines.append(
                "🔐 Fingerprint: <code>"
                + esc(
                    fingerprint
                )
                + "</code>"
            )

        if comment:

            lines.append(
                "💬 Comment: "
                + esc(
                    comment
                )
            )

        old_key = event.get(
            "old_key"
        )

        if isinstance(
            old_key,
            dict
        ):

            old_fp = (
                old_key.get(
                    "fingerprint"
                )
                or old_key.get(
                    "sha256"
                )
            )

            if old_fp:

                lines.append(
                    "🔙 Previous key: <code>"
                    + esc(
                        old_fp
                    )
                    + "</code>"
                )

        modifier_lines = (
            self.format_modifier(
                event
            )
        )

        if modifier_lines:

            lines.append(
                ""
            )

            lines.extend(
                modifier_lines
            )

        network_lines = (
            self.format_network(
                event
            )
        )

        if network_lines:

            lines.append(
                ""
            )

            lines.extend(
                network_lines
            )

        lines.append(
            ""
        )

        lines.append(
            "🕒 "
            + fmt_ts(
                ssh_key_event_time(
                    event
                )
            )
        )

        lines.append(
            "\n⚠️ If you did not make this change, "
            "check the server immediately."
        )

        normalized = (
            action
            .lower()
            .replace(
                "-",
                "_"
            )
            .replace(
                " ",
                "_"
            )
        )

        if normalized in (
            "removed",
            "remove",
            "key_removed",
            "ssh_key_removed",
            "deleted"
        ):

            level = "critical"

        elif normalized in (
            "added",
            "add",
            "key_added",
            "ssh_key_added",
            "created"
        ):

            level = "normal"

        else:

            level = "normal"

        await notify(
            self.bot,
            "\n".join(
                lines
            ),
            category="ssh_key",
            level=level
        )


# ============================================================
# SERVICE MONITOR
# ============================================================

def load_monitor_events(
    path: Path
) -> list:

    data = load_json(
        path,
        []
    )

    if not isinstance(
        data,
        list
    ):

        return []

    return [
        e
        for e in data
        if isinstance(
            e,
            dict
        )
    ]


MONITOR_KEY_FIELDS = (

    "time",
    "timestamp",
    "type",
    "event",
    "action",

    "process",
    "process_name",

    "pid",

    "user",
    "username",

    "service",
    "systemd_service",
    "unit",

    "state",
    "old_state",
    "new_state",

    "old_process",
    "new_process",

    "old_pid",
    "new_pid",

    "old_user",
    "new_user",

    "old_service",
    "new_service",
)


def monitor_event_key(
    event: dict
) -> str:

    return "|".join(
        str(
            event.get(
                key,
                ""
            )
        )
        for key in MONITOR_KEY_FIELDS
    )


def monitor_event_time(
    event: dict
) -> int:

    value = event.get(
        "time"
    )

    if value is None:

        value = event.get(
            "timestamp"
        )

    return to_int(
        value,
        int(
            time.time()
        )
    )


def monitor_event_type(
    event: dict
) -> str:

    value = event.get(
        "type"
    )

    if value is None:

        value = event.get(
            "event"
        )

    if value is None:

        value = event.get(
            "action"
        )

    return (
        str(
            value
            or "unknown"
        )
        .strip()
        .lower()
    )


def monitor_value(
    event: dict,
    *keys,
    default="?"
):

    for key in keys:

        value = event.get(
            key
        )

        if (
            value is not None
            and str(value) != ""
        ):

            return value

    return default


def format_monitor_service(
    event: dict
) -> str:

    service = monitor_value(
        event,
        "service",
        "systemd_service",
        "unit",
        default="?"
    )

    state = monitor_value(
        event,
        "state",
        "new_state",
        default=""
    )

    old_state = monitor_value(
        event,
        "old_state",
        default=""
    )

    new_state = monitor_value(
        event,
        "new_state",
        default=""
    )

    process = monitor_value(
        event,
        "process",
        "process_name",
        default=""
    )

    pid = monitor_value(
        event,
        "pid",
        default=""
    )

    lines = [
        "🔧 Service: <code>"
        + esc(service)
        + "</code>"
    ]

    if (
        old_state
        and new_state
    ):

        lines.append(
            "🔄 State: <code>"
            + esc(old_state)
            + "</code> → <code>"
            + esc(new_state)
            + "</code>"
        )

    elif state:

        lines.append(
            "📌 State: <b>"
            + esc(state)
            + "</b>"
        )

    if process:

        line = (
            "⚙️ Process: <code>"
            + esc(process)
            + "</code>"
        )

        if pid:

            line += (
                " · PID <code>"
                + esc(pid)
                + "</code>"
            )

        lines.append(
            line
        )

    return "\n".join(
        lines
    )


def is_noisy_service(
    name: str
) -> bool:

    name = name.lower()

    return any(
        pattern in name
        for pattern
        in SERVICE_IGNORE_PATTERNS
    )


class ServiceWatcher:

    def __init__(
        self,
        bot: Bot
    ):

        self.bot = bot

        self.mtime = (
            mtime_ns(
                SERVICE_MONITOR_EVENTS_FILE
            )
        )

        self.seen = Counter(
            monitor_event_key(e)
            for e in load_monitor_events(
                SERVICE_MONITOR_EVENTS_FILE
            )
        )

        self.cooldowns = {}


    async def run(self):

        while True:

            await asyncio.sleep(
                POLL_INTERVAL
            )

            try:

                await self.check_services()

            except Exception as e:

                log.exception(
                    "Service watcher error: %s",
                    e
                )


    def new_events(
        self
    ) -> list:

        current = (
            mtime_ns(
                SERVICE_MONITOR_EVENTS_FILE
            )
        )

        if current == self.mtime:

            return []

        self.mtime = current

        events = load_monitor_events(
            SERVICE_MONITOR_EVENTS_FILE
        )

        remaining = Counter(
            self.seen
        )

        new = []

        for event in events:

            key = (
                monitor_event_key(
                    event
                )
            )

            if remaining[key] > 0:

                remaining[key] -= 1

            else:

                new.append(
                    event
                )

        self.seen = Counter(
            monitor_event_key(e)
            for e in events
        )

        return new


    def is_duplicate(
        self,
        key,
        seconds: int
    ) -> bool:

        now = time.time()

        if (
            now
            - self.cooldowns.get(
                key,
                0
            )
            < seconds
        ):

            return True

        self.cooldowns[key] = now

        if len(
            self.cooldowns
        ) > 3000:

            for k, t in list(
                self.cooldowns.items()
            ):

                if (
                    now - t
                    > 3600
                ):

                    del self.cooldowns[
                        k
                    ]

        return False


    async def check_services(
        self
    ):

        for event in self.new_events():

            if not (
                OWNER
                and settings().get(
                    "notify_service",
                    True
                )
            ):

                continue

            event_type = (
                monitor_event_type(
                    event
                )
            )

            name = str(
                monitor_value(
                    event,
                    "service",
                    "systemd_service",
                    "unit",
                    default=""
                )
            ).lower()

            if is_noisy_service(
                name
            ):

                continue

            if self.is_duplicate(
                (
                    "service",
                    event_type,
                    name
                ),
                SERVICE_COOLDOWN
            ):

                continue

            await self.send_service_event(
                event,
                event_type,
                name
            )


    async def send_service_event(
        self,
        event: dict,
        event_type: str,
        name: str
    ):

        important = any(
            p in name
            for p
            in CRITICAL_SERVICE_PATTERNS
        )

        if event_type == "service_started":

            title = (
                "🟢 <b>SERVICE STARTED</b>"
            )

            description = (
                "A systemd service has started."
            )

            level = "low"

        elif event_type == "service_removed":

            title = (
                "🔴 <b>SERVICE STOPPED / REMOVED</b>"
            )

            description = (
                "A systemd service is no longer running."
            )

            level = (
                "critical"
                if important
                else "normal"
            )

        elif event_type == "service_changed":

            title = (
                "🔄 <b>SERVICE CHANGED</b>"
            )

            description = (
                "A systemd service changed its state."
            )

            level = "low"

        else:

            title = (
                "🔧 <b>SERVICE MONITOR EVENT</b>"
            )

            description = (
                "Event: <code>"
                + esc(event_type)
                + "</code>"
            )

            level = "low"

        text = "\n".join([
            title,
            "",
            description,
            "",
            format_monitor_service(
                event
            ),
            "",
            "🕒 "
            + fmt_ts(
                monitor_event_time(
                    event
                )
            ),
        ])

        await notify(
            self.bot,
            text,
            category="service",
            level=level
        )


# ============================================================
# FLOOD WORKER
# ============================================================

async def flood_worker(
    bot: Bot
):

    while True:

        await asyncio.sleep(
            10
        )

        try:

            for category, count in (
                THROTTLE.pop_summaries()
            ):

                await notify(
                    bot,

                    "🌊 <b>Flood protection</b>\n"
                    + str(count)
                    + " more <b>"
                    + esc(category)
                    + "</b> notification(s) "
                    "were suppressed in the last minute.",

                    category="flood",

                    level="normal",

                    throttle=False,
                )

        except Exception as e:

            log.exception(
                "Flood worker error: %s",
                e
            )


# ============================================================
# QUEUE
# ============================================================

async def queue_worker(
    bot: Bot
):

    while True:

        await asyncio.sleep(
            QUEUE_INTERVAL
        )

        if not OWNER:

            continue

        try:

            files = sorted(
                p
                for p in QUEUE_DIR.glob(
                    "*"
                )
                if (
                    p.is_file()
                    and p.suffix
                    in (
                        ".txt",
                        ".json"
                    )
                )
            )

        except Exception:

            continue

        for path in files:

            try:

                if (
                    time.time()
                    - path.stat().st_mtime
                    < 1
                ):

                    continue

                raw = path.read_text(
                    encoding="utf-8",
                    errors="replace"
                )

                use_html = False

                if path.suffix == ".json":

                    data = json.loads(
                        raw
                    )

                    if isinstance(
                        data,
                        dict
                    ):

                        text = str(
                            data.get(
                                "text",
                                ""
                            )
                        ).strip()

                        use_html = to_bool(
                            data.get(
                                "html",
                                False
                            )
                        )

                    else:

                        text = str(
                            data
                        ).strip()

                else:

                    text = raw.strip()

            except Exception as e:

                log.warning(
                    "Bad queue file %s: %s",
                    path,
                    e
                )

                try:

                    path.rename(
                        path.with_name(
                            path.name
                            + ".failed"
                        )
                    )

                except Exception:

                    pass

                continue

            if not text:

                path.unlink(
                    missing_ok=True
                )

                continue

            try:

                await bot.send_message(
                    OWNER["chat_id"],
                    text[:4000],
                    parse_mode=(
                        ParseMode.HTML
                        if use_html
                        else None
                    ),
                )

                path.unlink(
                    missing_ok=True
                )

            except TelegramAPIError as e:

                log.warning(
                    "Queue send failed (%s): %s",
                    path.name,
                    e
                )

                break


# ============================================================
# DAILY REPORT
# ============================================================

async def report_worker(
    bot: Bot
):

    while True:

        await asyncio.sleep(
            30
        )

        try:

            if not OWNER:

                continue

            s = settings()

            if not s.get(
                "daily_report"
            ):

                continue

            now = datetime.now()

            today = now.strftime(
                "%Y-%m-%d"
            )

            if (
                now.hour
                >= to_int(
                    s.get(
                        "report_hour"
                    ),
                    9
                )
                and s.get(
                    "last_report"
                )
                != today
            ):

                set_setting(
                    "last_report",
                    today
                )

                await notify(
                    bot,
                    build_report(24),
                    category="report",
                    level="normal",
                    throttle=False
                )

        except Exception as e:

            log.exception(
                "Report error: %s",
                e
            )


# ============================================================
# MAIN
# ============================================================

async def main():

    token = read_token()

    if not token:

        log.error(
            "BOT_TOKEN not found in %s",
            CONFIG_FILE
        )

        sys.exit(1)

    QUEUE_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    DATA_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    load_owner()

    seed_known_ips()

    bot = Bot(
        token=token,
        default=DefaultBotProperties(
            parse_mode=ParseMode.HTML
        )
    )

    dp = Dispatcher()

    dp.include_router(
        router
    )

    me = await bot.get_me()

    log.info(
        "Bot @%s started. Owner: %s",
        me.username,
        OWNER.get(
            "user_id",
            "not registered"
        )
    )

    try:

        await bot.set_my_commands([

            BotCommand(
                command="menu",
                description="Main menu"
            ),

            BotCommand(
                command="status",
                description="Status and statistics"
            ),

            BotCommand(
                command="blocks",
                description="Active blocks"
            ),

            BotCommand(
                command="events",
                description="Recent events"
            ),

            BotCommand(
                command="top",
                description="Top attackers"
            ),

            BotCommand(
                command="server",
                description="Server status"
            ),

            BotCommand(
                command="ip",
                description="IP information"
            ),

            BotCommand(
                command="block",
                description="Block an IP"
            ),

            BotCommand(
                command="unblock",
                description="Unblock an IP"
            ),

            BotCommand(
                command="whitelist",
                description="Whitelist"
            ),

            BotCommand(
                command="mute",
                description="Mute non-critical alerts"
            ),

            BotCommand(
                command="unmute",
                description="Turn notifications back on"
            ),

            BotCommand(
                command="help",
                description="Help"
            ),
        ])

    except TelegramAPIError as e:

        log.warning(
            "set_my_commands failed: %s",
            e
        )

    watcher = Watcher(
        bot
    )

    ssh_key_watcher = SSHKeyWatcher(
        bot
    )

    service_watcher = ServiceWatcher(
        bot
    )

    tasks = [

        asyncio.create_task(
            watcher.run()
        ),

        asyncio.create_task(
            ssh_key_watcher.run()
        ),

        asyncio.create_task(
            service_watcher.run()
        ),

        asyncio.create_task(
            flood_worker(
                bot
            )
        ),

        asyncio.create_task(
            queue_worker(
                bot
            )
        ),

        asyncio.create_task(
            report_worker(
                bot
            )
        ),
    ]

    try:

        await dp.start_polling(
            bot,
            allowed_updates=[
                "message",
                "callback_query"
            ]
        )

    finally:

        for task in tasks:

            task.cancel()

        await bot.session.close()


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":

    try:

        asyncio.run(
            main()
        )

    except KeyboardInterrupt:

        log.info(
            "Stopped."
        )