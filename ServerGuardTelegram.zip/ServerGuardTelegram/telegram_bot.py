#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ServerGuard Telegram Bot
========================

Работает вместе с:
  * C++ установщиком (TelegramBot.cpp)  -> telegram.conf / verification.json / owner.json / queue/
  * Brute Force Guard (python-скрипт)   -> protection_config.json / ssh_events.json /
                                            blocked_ips.json / stats.json

Что умеет:
  * Регистрация владельца по коду из пункта меню "Generate verification code"
  * Мгновенные уведомления: блокировка IP, разблокировка, вход по SSH (с пометкой нового IP),
    неудачные попытки (опционально), ежедневный отчёт
  * Кнопки под уведомлением: разблокировать / заблокировать / в whitelist / инфо по IP
  * Управление защитой: вкл/выкл, порог попыток, срок блокировки, permanent
  * Управление блокировками и whitelist прямо из Telegram (ufw + json-файлы guard'а)
  * Статистика, последние события, топ атакующих, состояние сервера, SSH-логи
  * Очередь queue/: любой скрипт на сервере может положить туда .json/.txt и бот отправит его владельцу
"""

import asyncio
import hmac
import html
import ipaddress
import json
import logging
import math
import os
import shutil
import socket
import sys
import time
from collections import Counter, deque
from datetime import datetime, timezone
from pathlib import Path

import aiohttp
from aiogram import BaseMiddleware, Bot, Dispatcher, F, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.exceptions import TelegramAPIError, TelegramBadRequest
from aiogram.filters import Command, CommandObject
from aiogram.types import (
    BotCommand,
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)


# ============================================================
# PATHS  (совпадают с TelegramBot.cpp и Brute Force Guard)
# ============================================================

BASE_DIR = Path(os.environ.get("SERVERGUARD_DIR", "/opt/serverguard"))

TELEGRAM_DIR = BASE_DIR / "telegram"
CONFIG_FILE = TELEGRAM_DIR / "telegram.conf"
VERIFICATION_FILE = TELEGRAM_DIR / "verification.json"
OWNER_FILE = TELEGRAM_DIR / "owner.json"
QUEUE_DIR = TELEGRAM_DIR / "queue"

DATA_DIR = BASE_DIR / "data"
PROTECTION_CONFIG_FILE = DATA_DIR / "protection_config.json"
EVENTS_FILE = DATA_DIR / "ssh_events.json"
BLOCKS_FILE = DATA_DIR / "blocked_ips.json"
STATS_FILE = DATA_DIR / "stats.json"


# ============================================================
# SETTINGS
# ============================================================

POLL_INTERVAL = 2            # как часто проверять файлы guard'а (сек)
QUEUE_INTERVAL = 3           # как часто проверять queue/ (сек)
BLOCKS_PER_PAGE = 8
MAX_LIST_LINES = 15
REG_WINDOW = 900             # окно ограничения попыток регистрации (сек)
REG_USER_LIMIT = 5           # неверных кодов на пользователя за окно
REG_GLOBAL_LIMIT = 15        # неверных кодов всего за окно

DEFAULT_PROTECTION = {
    "enabled": True,
    "attempts": 5,
    "duration": 600,
    "permanent": False,
    "mode": "ip",
    "whitelist": [],
}

DEFAULT_SETTINGS = {
    "notify_block": True,
    "notify_unblock": True,
    "notify_login": True,
    "notify_new_ip": True,
    "notify_failed": False,
    "geo": True,
    "daily_report": True,
    "report_hour": 9,
    "last_report": "",
}

NOTIFY_LABELS = {
    "notify_block": "🚫 Блокировки",
    "notify_unblock": "✅ Разблокировки",
    "notify_login": "🔑 Все успешные входы",
    "notify_new_ip": "🆕 Вход с нового IP",
    "notify_failed": "⚠️ Неудачные попытки",
    "geo": "🌍 Геолокация IP",
    "daily_report": "📅 Ежедневный отчёт",
}

logging.basicConfig(
    level=logging.INFO,
    format="[ServerGuard-TG] %(levelname)s %(message)s",
    stream=sys.stdout,
)
log = logging.getLogger("sg-telegram")

router = Router()

FILE_LOCK = asyncio.Lock()

OWNER: dict = {}

USER_FAILS: dict = {}
GLOBAL_FAILS: deque = deque()

SUPPRESS_BLOCK: set = set()      # (ip, blocked_at) - действия, сделанные самим ботом
SUPPRESS_UNBLOCK: set = set()

GEO_CACHE: dict = {}


# ============================================================
# BASIC HELPERS
# ============================================================

def esc(value) -> str:
    return html.escape(str(value), quote=False)


def to_bool(value) -> bool:
    if isinstance(value, str):
        return value.strip().lower() in ("1", "true", "yes", "on", "enabled")
    return bool(value)


def to_int(value, default=0) -> int:
    try:
        return int(value)
    except Exception:
        return default


def utc_iso(ts=None) -> str:
    if ts is None:
        ts = time.time()
    return datetime.fromtimestamp(ts, tz=timezone.utc).isoformat()


def fmt_ts(ts) -> str:
    try:
        return datetime.fromtimestamp(int(ts)).strftime("%d.%m %H:%M:%S")
    except Exception:
        return "?"


def fmt_dur(seconds) -> str:
    seconds = to_int(seconds)
    if seconds < 60:
        return f"{seconds} с"
    days, rem = divmod(seconds, 86400)
    hours, rem = divmod(rem, 3600)
    minutes = rem // 60
    parts = []
    if days:
        parts.append(f"{days} д")
    if hours:
        parts.append(f"{hours} ч")
    if minutes:
        parts.append(f"{minutes} мин")
    return " ".join(parts) or "0 мин"


def parse_ip(value):
    try:
        return str(ipaddress.ip_address(str(value).strip()))
    except ValueError:
        return None


def ev_time(event) -> int:
    return to_int(event.get("time"), 0)


# ============================================================
# JSON
# ============================================================

def load_json(path: Path, default):
    try:
        if not path.exists():
            return default
        with path.open("r", encoding="utf-8") as file:
            return json.load(file)
    except Exception as e:
        log.warning("JSON load error %s: %s", path, e)
        return default


def save_json(path: Path, data, private=False) -> bool:
    tmp = path.with_name(path.name + ".tg.tmp")
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with tmp.open("w", encoding="utf-8") as file:
            json.dump(data, file, indent=2, ensure_ascii=False)
            file.write("\n")
        if private:
            os.chmod(tmp, 0o600)
        tmp.replace(path)
        return True
    except Exception as e:
        log.error("JSON save error %s: %s", path, e)
        try:
            if tmp.exists():
                tmp.unlink()
        except Exception:
            pass
        return False


def mtime_ns(path: Path):
    try:
        return path.stat().st_mtime_ns
    except Exception:
        return None


# ============================================================
# GUARD DATA
# ============================================================

def load_config() -> dict:
    cfg = dict(DEFAULT_PROTECTION)
    data = load_json(PROTECTION_CONFIG_FILE, {})
    if isinstance(data, dict):
        cfg.update(data)

    cfg["enabled"] = to_bool(cfg.get("enabled", True))
    cfg["permanent"] = to_bool(cfg.get("permanent", False))
    cfg["attempts"] = max(1, min(to_int(cfg.get("attempts"), 5), 100))
    cfg["duration"] = max(60, min(to_int(cfg.get("duration"), 600), 30 * 24 * 3600))

    wl = cfg.get("whitelist", [])
    clean = []
    if isinstance(wl, list):
        for ip in wl:
            ip = str(ip).strip()
            if ip and ip not in clean:
                clean.append(ip)
    cfg["whitelist"] = clean
    return cfg


def update_protection(changes: dict) -> bool:
    data = load_json(PROTECTION_CONFIG_FILE, None)
    if not isinstance(data, dict):
        data = dict(DEFAULT_PROTECTION)
    data.update(changes)
    return save_json(PROTECTION_CONFIG_FILE, data)


def load_events() -> list:
    data = load_json(EVENTS_FILE, [])
    if not isinstance(data, list):
        return []
    return [e for e in data if isinstance(e, dict)]


def load_blocks() -> dict:
    data = load_json(BLOCKS_FILE, {})
    if not isinstance(data, dict):
        return {}
    return {ip: rec for ip, rec in data.items() if isinstance(rec, dict)}


def save_blocks(blocks: dict) -> bool:
    return save_json(BLOCKS_FILE, blocks)


def load_stats() -> dict:
    data = load_json(STATS_FILE, {})
    return data if isinstance(data, dict) else {}


def bump_stat(name: str):
    stats = load_stats()
    stats[name] = to_int(stats.get(name, 0)) + 1
    save_json(STATS_FILE, stats)


# ============================================================
# OWNER / SETTINGS
# ============================================================

def load_owner():
    data = load_json(OWNER_FILE, {})
    OWNER.clear()
    if isinstance(data, dict) and data.get("user_id"):
        OWNER.update(data)


def save_owner():
    save_json(OWNER_FILE, OWNER, private=True)


def is_owner(user_id) -> bool:
    return bool(OWNER) and OWNER.get("user_id") == user_id


def settings() -> dict:
    result = dict(DEFAULT_SETTINGS)
    stored = OWNER.get("settings")
    if isinstance(stored, dict):
        result.update(stored)
    return result


def set_setting(key, value):
    if not OWNER:
        return
    OWNER.setdefault("settings", {})[key] = value
    save_owner()


def known_ips() -> set:
    stored = OWNER.get("known_ips")
    return set(stored) if isinstance(stored, list) else set()


def remember_ip(ip: str):
    if not OWNER:
        return
    stored = OWNER.get("known_ips")
    if not isinstance(stored, list):
        stored = []
    if ip not in stored:
        stored.append(ip)
        OWNER["known_ips"] = stored[-1000:]
        save_owner()


def seed_known_ips():
    """Все IP, с которых уже успешно заходили, не считаются 'новыми'."""
    if not OWNER:
        return
    stored = OWNER.get("known_ips")
    stored = list(stored) if isinstance(stored, list) else []
    changed = False
    for e in load_events():
        if e.get("type") == "success":
            ip = e.get("ip")
            if ip and ip not in stored:
                stored.append(ip)
                changed = True
    if changed:
        OWNER["known_ips"] = stored[-1000:]
        save_owner()


def read_token() -> str:
    token = os.environ.get("BOT_TOKEN", "").strip()
    try:
        if CONFIG_FILE.exists():
            for line in CONFIG_FILE.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line.startswith("BOT_TOKEN="):
                    token = line.split("=", 1)[1].strip().strip('"').strip("'")
                    break
    except Exception as e:
        log.error("Cannot read %s: %s", CONFIG_FILE, e)
    return token


# ============================================================
# SYSTEM COMMANDS
# ============================================================

async def run_cmd(*args, timeout=15):
    proc = None
    try:
        proc = await asyncio.create_subprocess_exec(
            *args,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )
        out, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        return proc.returncode, out.decode("utf-8", "replace")
    except FileNotFoundError:
        return 127, f"{args[0]}: command not found"
    except asyncio.TimeoutError:
        try:
            if proc:
                proc.kill()
        except Exception:
            pass
        return 124, "timeout"
    except Exception as e:
        return 1, str(e)


async def local_ips() -> set:
    ips = {"127.0.0.1", "::1"}
    rc, out = await run_cmd("hostname", "-I", timeout=5)
    if rc == 0:
        ips.update(out.split())
    return ips


def _rule_missing(text: str) -> bool:
    low = text.lower()
    return "non-existent" in low or "could not delete" in low or "not found" in low


async def do_unblock(ip: str):
    """Снимает блокировку в ufw и убирает запись из blocked_ips.json."""
    for _ in range(5):
        rc, out = await run_cmd("ufw", "delete", "deny", "from", ip)
        if _rule_missing(out):
            break
        if rc != 0:
            return False, out.strip()[:300] or "ufw error"

    async with FILE_LOCK:
        blocks = load_blocks()
        rec = blocks.pop(ip, None)
        if rec is not None:
            SUPPRESS_UNBLOCK.add(ip)
            save_blocks(blocks)
            bump_stat("unblocked")
    return True, "OK"


async def do_block(ip: str, permanent: bool, duration: int, reason: str):
    """Блокирует IP так же, как это делает guard (ufw insert 1 deny from ...)."""
    ip = parse_ip(ip)
    if not ip:
        return False, "Некорректный IP"

    cfg = load_config()
    if ip in cfg["whitelist"]:
        return False, "IP находится в whitelist"
    if ip in await local_ips():
        return False, "Это IP самого сервера"

    rc, out = await run_cmd("ufw", "insert", "1", "deny", "from", ip)
    if rc != 0:
        return False, out.strip()[:300] or "ufw error"

    now = int(time.time())
    duration = max(60, int(duration))
    expires = None if permanent else now + duration

    async with FILE_LOCK:
        blocks = load_blocks()
        blocks[ip] = {
            "ip": ip,
            "blocked_at": now,
            "blocked_at_iso": utc_iso(now),
            "failed_attempts": 0,
            "permanent": bool(permanent),
            "duration": duration,
            "expires_at": expires,
            "expires_at_iso": None if expires is None else utc_iso(expires),
            "reason": reason,
        }
        SUPPRESS_BLOCK.add((ip, now))
        save_blocks(blocks)
        bump_stat("blocked")
    return True, "OK"


def whitelist_add(ip: str) -> bool:
    cfg = load_config()
    wl = cfg["whitelist"]
    if ip in wl:
        return False
    wl.append(ip)
    update_protection({"whitelist": wl})
    return True


def whitelist_remove(ip: str) -> bool:
    cfg = load_config()
    wl = cfg["whitelist"]
    if ip not in wl:
        return False
    wl.remove(ip)
    update_protection({"whitelist": wl})
    return True


# ============================================================
# GEO
# ============================================================

async def geo_lookup(ip: str, force=False) -> str:
    if not force and not settings().get("geo", True):
        return ""
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return ""
    if addr.is_private or addr.is_loopback or addr.is_link_local:
        return "🏠 локальный адрес"
    if ip in GEO_CACHE:
        return GEO_CACHE[ip]

    result = ""
    try:
        timeout = aiohttp.ClientTimeout(total=4)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(
                f"http://ip-api.com/json/{ip}",
                params={
                    "fields": "status,country,regionName,city,isp,org,proxy,hosting",
                    "lang": "ru",
                },
            ) as resp:
                data = await resp.json(content_type=None)
        if data.get("status") == "success":
            place = ", ".join(x for x in (data.get("country"), data.get("city")) if x)
            provider = data.get("isp") or data.get("org") or ""
            result = "🌍 " + esc(place or "?")
            if provider:
                result += " · " + esc(provider)
            if data.get("hosting") or data.get("proxy"):
                result += "\n🕵️ хостинг / VPN / proxy"
    except Exception as e:
        log.debug("geo error %s: %s", ip, e)
        return ""

    if len(GEO_CACHE) > 500:
        GEO_CACHE.clear()
    GEO_CACHE[ip] = result
    return result


# ============================================================
# KEYBOARDS
# ============================================================

def btn(text, data) -> InlineKeyboardButton:
    return InlineKeyboardButton(text=text, callback_data=data)


def kb(rows) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=rows)


BACK_ROW = [btn("⬅️ Меню", "m")]


# ============================================================
# VIEWS  (каждая возвращает (text, markup))
# ============================================================

def view_menu():
    cfg = load_config()
    blocks = load_blocks()
    text = (
        "🛡 <b>ServerGuard</b>\n\n"
        f"Защита SSH: {'✅ включена' if cfg['enabled'] else '❌ выключена'}\n"
        f"Активных блокировок: <b>{len(blocks)}</b>\n\n"
        "Выберите действие:"
    )
    markup = kb([
        [btn("📊 Статус", "st"), btn("🚫 Блокировки", "bp:0")],
        [btn("📜 События", "ev:all"), btn("🔑 Входы", "ev:success")],
        [btn("🏴‍☠️ Топ атакующих", "tp:24"), btn("🖥 Сервер", "sv")],
        [btn("🛡 Защита", "pr"), btn("✅ Whitelist", "wl")],
        [btn("🔔 Уведомления", "nt"), btn("🧾 SSH логи", "lg")],
    ])
    return text, markup


def view_status():
    cfg = load_config()
    blocks = load_blocks()
    stats = load_stats()
    events = load_events()

    cutoff = time.time() - 86400
    failed24 = [e for e in events if e.get("type") == "failed" and ev_time(e) >= cutoff]
    success24 = [e for e in events if e.get("type") == "success" and ev_time(e) >= cutoff]
    attackers24 = {e.get("ip") for e in failed24}

    block_type = "навсегда" if cfg["permanent"] else fmt_dur(cfg["duration"])
    permanent_count = sum(1 for r in blocks.values() if r.get("permanent"))

    text = (
        "📊 <b>Статус ServerGuard</b>\n\n"
        f"Защита: {'✅ ВКЛ' if cfg['enabled'] else '❌ ВЫКЛ'}\n"
        f"Порог: <b>{cfg['attempts']}</b> попыток → блок <b>{block_type}</b>\n"
        f"Whitelist: {len(cfg['whitelist'])} IP\n\n"
        f"🚫 Активных блокировок: <b>{len(blocks)}</b> (permanent: {permanent_count})\n\n"
        "<b>За 24 часа</b>\n"
        f"⚠️ Неудачных попыток: <b>{len(failed24)}</b> (уникальных IP: {len(attackers24)})\n"
        f"🔑 Успешных входов: <b>{len(success24)}</b>\n\n"
        "<b>За всё время</b>\n"
        f"⚠️ Неудачных: {to_int(stats.get('failed'))}\n"
        f"🔑 Успешных: {to_int(stats.get('success'))}\n"
        f"🚫 Блокировок: {to_int(stats.get('blocked'))}\n"
        f"✅ Разблокировок: {to_int(stats.get('unblocked'))}"
    )
    markup = kb([
        [btn("🔄 Обновить", "st"), btn("🚫 Блокировки", "bp:0")],
        BACK_ROW,
    ])
    return text, markup


def view_blocks(page=0):
    blocks = load_blocks()
    items = sorted(
        blocks.items(),
        key=lambda kv: to_int(kv[1].get("blocked_at"), 0),
        reverse=True,
    )
    total = len(items)
    pages = max(1, math.ceil(total / BLOCKS_PER_PAGE))
    page = max(0, min(page, pages - 1))
    chunk = items[page * BLOCKS_PER_PAGE:(page + 1) * BLOCKS_PER_PAGE]

    now = time.time()
    lines = [f"🚫 <b>Активные блокировки</b> ({total})"]
    if pages > 1:
        lines[0] += f" · стр. {page + 1}/{pages}"
    lines.append("")

    if not chunk:
        lines.append("Сейчас нет заблокированных IP 🎉")

    for ip, rec in chunk:
        if rec.get("permanent"):
            left = "♾ навсегда"
        else:
            exp = to_int(rec.get("expires_at"), 0)
            left = "осталось " + fmt_dur(max(0, exp - now))
        lines.append(
            f"• <code>{esc(ip)}</code> — {left}\n"
            f"   попыток: {to_int(rec.get('failed_attempts'))} · с {fmt_ts(rec.get('blocked_at'))}"
        )

    rows = []
    pair = []
    for ip, _ in chunk:
        pair.append(btn(f"🔓 {ip}", f"ub:{ip}"))
        if len(pair) == 2:
            rows.append(pair)
            pair = []
    if pair:
        rows.append(pair)

    nav = []
    if page > 0:
        nav.append(btn("◀️", f"bp:{page - 1}"))
    nav.append(btn("🔄", f"bp:{page}"))
    if page < pages - 1:
        nav.append(btn("▶️", f"bp:{page + 1}"))
    rows.append(nav)

    if total:
        rows.append([btn("🔓 Разблокировать все", "ua")])
    rows.append(BACK_ROW)
    return "\n".join(lines), kb(rows)


def view_unblock_all_confirm():
    total = len(load_blocks())
    text = f"⚠️ Снять блокировку со всех IP (<b>{total}</b>)?"
    return text, kb([[btn("✅ Да, разблокировать", "uay"), btn("❌ Отмена", "bp:0")]])


def view_events(kind="all"):
    events = load_events()
    if kind in ("failed", "success"):
        events = [e for e in events if e.get("type") == kind]
    last = events[-MAX_LIST_LINES:][::-1]

    titles = {"all": "Последние события", "failed": "Неудачные попытки", "success": "Успешные входы"}
    lines = [f"📜 <b>{titles.get(kind, 'События')}</b> (время сервера)", ""]
    if not last:
        lines.append("Пока пусто.")

    for e in last:
        ip = esc(e.get("ip", "?"))
        user = esc(e.get("username", "?"))
        if e.get("type") == "success":
            method = esc(e.get("auth_method", ""))
            lines.append(f"🟢 {fmt_ts(e.get('time'))} <b>{user}</b> ← <code>{ip}</code> ({method})")
        else:
            lines.append(f"🔴 {fmt_ts(e.get('time'))} <b>{user}</b> ← <code>{ip}</code>")

    markup = kb([
        [btn("Все", "ev:all"), btn("🔴 Failed", "ev:failed"), btn("🟢 Success", "ev:success")],
        [btn("🔄 Обновить", f"ev:{kind}")],
        BACK_ROW,
    ])
    return "\n".join(lines), markup


def view_top(hours=24):
    hours = 168 if hours >= 168 else 24
    cutoff = time.time() - hours * 3600
    failed = [e for e in load_events() if e.get("type") == "failed" and ev_time(e) >= cutoff]
    blocks = load_blocks()

    ips = Counter(e.get("ip", "?") for e in failed)
    users = Counter(e.get("username", "?") for e in failed)

    label = "24 часа" if hours == 24 else "7 дней"
    lines = [f"🏴‍☠️ <b>Топ атакующих за {label}</b>", ""]
    if not ips:
        lines.append("Атак не зафиксировано ✅")
    else:
        lines.append(f"Всего попыток: <b>{len(failed)}</b> с <b>{len(ips)}</b> IP\n")
        for ip, count in ips.most_common(10):
            tried = Counter(e.get("username", "?") for e in failed if e.get("ip") == ip)
            names = ", ".join(esc(n) for n, _ in tried.most_common(3))
            flag = "🚫" if ip in blocks else "▫️"
            lines.append(f"{flag} <code>{esc(ip)}</code> — <b>{count}</b> ({names})")
        lines.append("\n<b>Популярные логины:</b>")
        lines.append(", ".join(f"{esc(u)} ×{c}" for u, c in users.most_common(8)))

    other = 168 if hours == 24 else 24
    rows = []
    top_ips = [ip for ip, _ in ips.most_common(6)]
    pair = []
    for ip in top_ips:
        pair.append(btn(f"🔎 {ip}", f"ip:{ip}"))
        if len(pair) == 2:
            rows.append(pair)
            pair = []
    if pair:
        rows.append(pair)
    rows.append([btn("7 дней" if hours == 24 else "24 часа", f"tp:{other}"), btn("🔄", f"tp:{hours}")])
    rows.append(BACK_ROW)
    return "\n".join(lines), kb(rows)


def server_info() -> str:
    lines = ["🖥 <b>Сервер</b>", ""]
    try:
        lines.append(f"Хост: <code>{esc(socket.gethostname())}</code>")
    except Exception:
        pass
    try:
        with open("/proc/uptime") as f:
            seconds = float(f.read().split()[0])
        lines.append(f"Аптайм: {fmt_dur(seconds)}")
    except Exception:
        pass
    try:
        l1, l5, l15 = os.getloadavg()
        lines.append(f"Нагрузка: {l1:.2f} / {l5:.2f} / {l15:.2f} (ядер: {os.cpu_count()})")
    except Exception:
        pass
    try:
        mem = {}
        with open("/proc/meminfo") as f:
            for line in f:
                key, _, val = line.partition(":")
                mem[key] = int(val.split()[0]) * 1024
        total = mem["MemTotal"]
        avail = mem.get("MemAvailable", mem.get("MemFree", 0))
        used = total - avail
        lines.append(f"RAM: {used / 2**30:.2f} / {total / 2**30:.2f} ГБ ({used * 100 // total}%)")
    except Exception:
        pass
    try:
        usage = shutil.disk_usage("/")
        lines.append(
            f"Диск /: {usage.used / 2**30:.1f} / {usage.total / 2**30:.1f} ГБ "
            f"({usage.used * 100 // usage.total}%)"
        )
    except Exception:
        pass
    lines.append(f"Время сервера: {datetime.now().strftime('%d.%m.%Y %H:%M:%S')}")
    return "\n".join(lines)


def view_server():
    return server_info(), kb([[btn("🔄 Обновить", "sv")], BACK_ROW])


async def view_logs():
    rc, out = await run_cmd(
        "journalctl", "-u", "ssh", "-u", "sshd", "-n", "25", "--no-pager", "-o", "short-iso"
    )
    out = out.strip()
    if rc != 0 or not out:
        body = out or "Логи недоступны."
    else:
        body = out[-3400:]
    text = "🧾 <b>SSH логи (последние строки)</b>\n<pre>" + esc(body) + "</pre>"
    return text, kb([[btn("🔄 Обновить", "lg")], BACK_ROW])


def view_protection():
    cfg = load_config()
    block_type = "♾ навсегда" if cfg["permanent"] else fmt_dur(cfg["duration"])
    text = (
        "🛡 <b>Защита SSH</b>\n\n"
        f"Статус: {'✅ ВКЛ' if cfg['enabled'] else '❌ ВЫКЛ'}\n"
        f"Порог: <b>{cfg['attempts']}</b> неудачных попыток\n"
        f"Блокировка: <b>{block_type}</b>\n"
        f"Whitelist: {len(cfg['whitelist'])} IP\n\n"
        "<i>Изменения применяются guard'ом примерно за 5 секунд.</i>"
    )

    attempts_row = [
        btn(f"● {n}" if cfg["attempts"] == n else str(n), f"pr:at:{n}")
        for n in (3, 5, 10, 20)
    ]
    durations = ((600, "10м"), (3600, "1ч"), (21600, "6ч"), (86400, "24ч"), (604800, "7д"))
    duration_row = [
        btn(f"● {label}" if (cfg["duration"] == sec and not cfg["permanent"]) else label, f"pr:du:{sec}")
        for sec, label in durations
    ]
    markup = kb([
        [btn("❌ Выключить защиту" if cfg["enabled"] else "✅ Включить защиту", "pr:en")],
        [btn("Попыток:", "noop")] + attempts_row,
        [btn("Срок:", "noop")] + duration_row,
        [btn("♾ Permanent: " + ("ВКЛ" if cfg["permanent"] else "ВЫКЛ"), "pr:pm")],
        BACK_ROW,
    ])
    return text, markup


def view_whitelist():
    cfg = load_config()
    wl = cfg["whitelist"]
    lines = ["✅ <b>Whitelist</b>", ""]
    if not wl:
        lines.append("Список пуст.")
    for ip in wl:
        lines.append(f"• <code>{esc(ip)}</code>")
    lines.append("\nДобавить: <code>/whitelist add 1.2.3.4</code>\nили просто отправьте IP боту.")

    rows = []
    pair = []
    for ip in wl[:20]:
        pair.append(btn(f"🗑 {ip}", f"wd:{ip}"))
        if len(pair) == 2:
            rows.append(pair)
            pair = []
    if pair:
        rows.append(pair)
    rows.append(BACK_ROW)
    return "\n".join(lines), kb(rows)


def view_notify():
    s = settings()
    text = (
        "🔔 <b>Уведомления</b>\n\n"
        "Нажмите, чтобы включить или выключить.\n"
        f"Ежедневный отчёт отправляется в <b>{to_int(s['report_hour']):02d}:00</b> (время сервера)."
    )
    rows = []
    for key, label in NOTIFY_LABELS.items():
        rows.append([btn(f"{'✅' if s.get(key) else '❌'} {label}", f"nt:{key}")])
    hour_row = [btn("🕘 Отчёт в:", "noop")]
    for h in (6, 9, 18, 22):
        hour_row.append(btn(f"● {h}" if to_int(s["report_hour"]) == h else str(h), f"nt:hr:{h}"))
    rows.append(hour_row)
    rows.append(BACK_ROW)
    return text, kb(rows)


async def view_ip(ip: str):
    geo = await geo_lookup(ip, force=True)
    blocks = load_blocks()
    cfg = load_config()
    rec = blocks.get(ip)
    in_wl = ip in cfg["whitelist"]

    cutoff = time.time() - 7 * 86400
    events = [e for e in load_events() if e.get("ip") == ip and ev_time(e) >= cutoff]
    failed = [e for e in events if e.get("type") == "failed"]
    success = [e for e in events if e.get("type") == "success"]
    users = Counter(e.get("username", "?") for e in failed)

    lines = [f"🔎 <b>IP</b> <code>{esc(ip)}</code>", ""]
    if geo:
        lines.append(geo)

    if rec:
        if rec.get("permanent"):
            lines.append("Статус: 🚫 заблокирован <b>навсегда</b>")
        else:
            left = max(0, to_int(rec.get("expires_at")) - time.time())
            lines.append(f"Статус: 🚫 заблокирован ещё на <b>{fmt_dur(left)}</b>")
    else:
        lines.append("Статус: не заблокирован")
    lines.append(f"Whitelist: {'✅ да' if in_wl else 'нет'}")
    lines.append(f"\nЗа 7 дней: 🔴 {len(failed)} неудачных · 🟢 {len(success)} входов")
    if events:
        lines.append(f"Последняя активность: {fmt_ts(max(ev_time(e) for e in events))}")
    if users:
        lines.append("Логины: " + ", ".join(esc(u) for u, _ in users.most_common(8)))

    row1 = []
    row1.append(btn("🔓 Разблокировать", f"ub:{ip}") if rec else btn("🚫 Заблокировать", f"bk:{ip}"))
    row1.append(btn("🗑 Из whitelist", f"wd:{ip}") if in_wl else btn("✅ В whitelist", f"wa:{ip}"))
    markup = kb([row1, [btn("🔄 Обновить", f"ip:{ip}")], BACK_ROW])
    return "\n".join(lines), markup


def build_report(hours=24) -> str:
    now = time.time()
    cutoff = now - hours * 3600
    events = load_events()
    failed = [e for e in events if e.get("type") == "failed" and ev_time(e) >= cutoff]
    success = [e for e in events if e.get("type") == "success" and ev_time(e) >= cutoff]
    blocks = load_blocks()
    new_blocks = [r for r in blocks.values() if to_int(r.get("blocked_at")) >= cutoff]

    lines = [
        "📅 <b>Отчёт ServerGuard за 24 часа</b>",
        "",
        f"⚠️ Неудачных попыток: <b>{len(failed)}</b>",
        f"🌐 Уникальных атакующих IP: <b>{len({e.get('ip') for e in failed})}</b>",
        f"🔑 Успешных входов: <b>{len(success)}</b>",
        f"🚫 Новых блокировок (активных): <b>{len(new_blocks)}</b>",
        f"🚫 Всего активных блокировок: <b>{len(blocks)}</b>",
    ]
    top = Counter(e.get("ip", "?") for e in failed).most_common(5)
    if top:
        lines.append("\n<b>Топ атакующих:</b>")
        for ip, count in top:
            lines.append(f"• <code>{esc(ip)}</code> — {count}")
    if success:
        ips = Counter(e.get("ip", "?") for e in success)
        lines.append("\n<b>Входы:</b>")
        for ip, count in ips.most_common(5):
            lines.append(f"• <code>{esc(ip)}</code> ×{count}")
    return "\n".join(lines)


HELP_TEXT = (
    "❓ <b>Команды</b>\n\n"
    "/menu — главное меню\n"
    "/status — статус и статистика\n"
    "/blocks — активные блокировки\n"
    "/events — последние события\n"
    "/top — топ атакующих\n"
    "/server — состояние сервера\n"
    "/ip <code>1.2.3.4</code> — информация об IP\n"
    "/block <code>1.2.3.4</code> [минуты | perm] — заблокировать IP\n"
    "/unblock <code>1.2.3.4</code> — разблокировать IP\n"
    "/whitelist [add|del <code>IP</code>] — управление whitelist\n\n"
    "Можно просто отправить IP-адрес — бот покажет карточку с кнопками.\n\n"
    "📥 <b>Очередь сообщений</b>\n"
    "Любой скрипт на сервере может положить в "
    f"<code>{esc(QUEUE_DIR)}</code> файл <code>.txt</code> или <code>.json</code> "
    "(<code>{\"text\": \"...\"}</code>), и бот отправит его вам."
)


# ============================================================
# RENDER
# ============================================================

async def render(target, text: str, markup=None):
    if isinstance(target, CallbackQuery):
        try:
            await target.message.edit_text(text, reply_markup=markup)
        except TelegramBadRequest as e:
            if "not modified" not in str(e).lower():
                await target.message.answer(text, reply_markup=markup)
    else:
        await target.answer(text, reply_markup=markup)


async def notify(bot: Bot, text: str, markup=None) -> bool:
    chat_id = OWNER.get("chat_id")
    if not chat_id:
        return False
    try:
        await bot.send_message(chat_id, text[:4000], reply_markup=markup)
        return True
    except TelegramAPIError as e:
        log.warning("Cannot send notification: %s", e)
        return False


# ============================================================
# ACCESS
# ============================================================

class AccessMiddleware(BaseMiddleware):
    async def __call__(self, handler, event, data):
        if isinstance(event, Message):
            user = event.from_user
            if user is None or event.chat.type != "private":
                return None
            if is_owner(user.id):
                return await handler(event, data)
            if (event.text or "").startswith("/start"):
                return await handler(event, data)
            return None

        if isinstance(event, CallbackQuery):
            if is_owner(event.from_user.id):
                return await handler(event, data)
            try:
                await event.answer("⛔ Нет доступа", show_alert=True)
            except TelegramAPIError:
                pass
            return None

        return await handler(event, data)


router.message.outer_middleware(AccessMiddleware())
router.callback_query.outer_middleware(AccessMiddleware())


# ============================================================
# REGISTRATION
# ============================================================

def reg_wait_seconds(user_id: int) -> int:
    now = time.time()
    mine = [t for t in USER_FAILS.get(user_id, []) if now - t < REG_WINDOW]
    USER_FAILS[user_id] = mine
    while GLOBAL_FAILS and now - GLOBAL_FAILS[0] >= REG_WINDOW:
        GLOBAL_FAILS.popleft()
    if len(mine) >= REG_USER_LIMIT:
        return int(REG_WINDOW - (now - mine[0]))
    if len(GLOBAL_FAILS) >= REG_GLOBAL_LIMIT:
        return int(REG_WINDOW - (now - GLOBAL_FAILS[0]))
    return 0


def reg_register_fail(user_id: int):
    now = time.time()
    USER_FAILS.setdefault(user_id, []).append(now)
    GLOBAL_FAILS.append(now)


NOT_REGISTERED_TEXT = (
    "👋 Это бот <b>ServerGuard</b>.\n\n"
    "Чтобы зарегистрироваться:\n"
    "1. На сервере откройте ServerGuard → Telegram bot → "
    "<b>Generate verification code</b>\n"
    "2. Отправьте сюда: <code>/start КОД</code>\n\n"
    "Код действует 5 минут."
)


async def try_register(message: Message, code: str):
    user = message.from_user
    wait = reg_wait_seconds(user.id)
    if wait:
        await message.answer(f"⏳ Слишком много неверных попыток. Подождите {fmt_dur(wait)}.")
        return

    ver = load_json(VERIFICATION_FILE, None)
    if not isinstance(ver, dict) or not ver.get("code"):
        await message.answer(
            "❌ Активного кода нет. Сгенерируйте новый на сервере "
            "(Telegram bot → Generate verification code)."
        )
        return

    if time.time() > to_int(ver.get("expires_at"), 0):
        try:
            VERIFICATION_FILE.unlink()
        except Exception:
            pass
        await message.answer("⌛ Код истёк. Сгенерируйте новый на сервере.")
        return

    if not hmac.compare_digest(str(ver["code"]), code):
        reg_register_fail(user.id)
        try:
            await message.delete()
        except TelegramAPIError:
            pass
        left = max(0, REG_USER_LIMIT - len(USER_FAILS.get(user.id, [])))
        await message.answer(f"❌ Неверный код. Осталось попыток: {left}")
        return

    # ---- SUCCESS ----
    try:
        await message.delete()          # убираем код из чата
    except TelegramAPIError:
        pass

    previous = dict(OWNER)
    new_owner = {
        "user_id": user.id,
        "chat_id": message.chat.id,
        "username": user.username or "",
        "first_name": user.full_name or "",
        "registered_at": int(time.time()),
        "settings": previous.get("settings", {}) if isinstance(previous.get("settings"), dict) else {},
        "known_ips": previous.get("known_ips", []) if isinstance(previous.get("known_ips"), list) else [],
    }
    new_owner["settings"]["last_report"] = datetime.now().strftime("%Y-%m-%d")

    OWNER.clear()
    OWNER.update(new_owner)
    save_owner()
    seed_known_ips()

    try:
        VERIFICATION_FILE.unlink()
    except Exception:
        pass

    if previous.get("chat_id") and previous.get("user_id") != user.id:
        try:
            await message.bot.send_message(
                previous["chat_id"],
                "⚠️ Доступ к боту передан другому аккаунту (через код с сервера). "
                "Вы больше не получаете уведомления.",
            )
        except TelegramAPIError:
            pass

    log.info("Owner registered: %s (%s)", user.id, user.username)
    await message.answer(
        "✅ <b>Регистрация завершена!</b>\n\n"
        "Теперь вы будете получать уведомления о блокировках, входах по SSH "
        "и сможете управлять защитой прямо здесь."
    )
    text, markup = view_menu()
    await message.answer(text, reply_markup=markup)


# ============================================================
# COMMAND HANDLERS
# ============================================================

@router.message(Command("start"))
async def cmd_start(message: Message, command: CommandObject):
    code = "".join((command.args or "").split())
    if not code:
        if is_owner(message.from_user.id):
            text, markup = view_menu()
            await message.answer(text, reply_markup=markup)
        else:
            await message.answer(NOT_REGISTERED_TEXT)
        return
    await try_register(message, code)


@router.message(Command("menu"))
async def cmd_menu(message: Message):
    text, markup = view_menu()
    await message.answer(text, reply_markup=markup)


@router.message(Command("help"))
async def cmd_help(message: Message):
    await message.answer(HELP_TEXT, reply_markup=kb([BACK_ROW]))


@router.message(Command("status"))
async def cmd_status(message: Message):
    text, markup = view_status()
    await message.answer(text, reply_markup=markup)


@router.message(Command("blocks"))
async def cmd_blocks(message: Message):
    text, markup = view_blocks(0)
    await message.answer(text, reply_markup=markup)


@router.message(Command("events"))
async def cmd_events(message: Message):
    text, markup = view_events("all")
    await message.answer(text, reply_markup=markup)


@router.message(Command("top"))
async def cmd_top(message: Message):
    text, markup = view_top(24)
    await message.answer(text, reply_markup=markup)


@router.message(Command("server"))
async def cmd_server(message: Message):
    text, markup = view_server()
    await message.answer(text, reply_markup=markup)


@router.message(Command("ip"))
async def cmd_ip(message: Message, command: CommandObject):
    ip = parse_ip(command.args or "")
    if not ip:
        await message.answer("Использование: <code>/ip 1.2.3.4</code>")
        return
    text, markup = await view_ip(ip)
    await message.answer(text, reply_markup=markup)


@router.message(Command("block"))
async def cmd_block(message: Message, command: CommandObject):
    parts = (command.args or "").split()
    if not parts:
        await message.answer(
            "Использование:\n<code>/block 1.2.3.4</code> — по настройкам защиты\n"
            "<code>/block 1.2.3.4 60</code> — на 60 минут\n"
            "<code>/block 1.2.3.4 perm</code> — навсегда"
        )
        return

    ip = parse_ip(parts[0])
    if not ip:
        await message.answer("❌ Некорректный IP.")
        return

    cfg = load_config()
    permanent = cfg["permanent"]
    duration = cfg["duration"]
    if len(parts) > 1:
        arg = parts[1].lower()
        if arg in ("perm", "permanent", "forever", "навсегда"):
            permanent = True
        else:
            minutes = to_int(arg, 0)
            if minutes <= 0:
                await message.answer("❌ Укажите минуты числом или <code>perm</code>.")
                return
            permanent = False
            duration = minutes * 60

    ok, info = await do_block(ip, permanent, duration, "Manual block via Telegram")
    if ok:
        term = "навсегда" if permanent else "на " + fmt_dur(max(60, duration))
        await message.answer(f"🚫 <code>{esc(ip)}</code> заблокирован {term}.")
    else:
        await message.answer(f"❌ Не удалось: {esc(info)}")


@router.message(Command("unblock"))
async def cmd_unblock(message: Message, command: CommandObject):
    ip = parse_ip(command.args or "")
    if not ip:
        await message.answer("Использование: <code>/unblock 1.2.3.4</code>")
        return
    ok, info = await do_unblock(ip)
    if ok:
        await message.answer(f"✅ <code>{esc(ip)}</code> разблокирован.")
    else:
        await message.answer(f"❌ Не удалось: {esc(info)}")


@router.message(Command("whitelist"))
async def cmd_whitelist(message: Message, command: CommandObject):
    parts = (command.args or "").split()
    if not parts:
        text, markup = view_whitelist()
        await message.answer(text, reply_markup=markup)
        return

    action = parts[0].lower()
    ip = parse_ip(parts[1]) if len(parts) > 1 else None
    if action not in ("add", "del", "remove", "rm") or not ip:
        await message.answer("Использование:\n<code>/whitelist add 1.2.3.4</code>\n<code>/whitelist del 1.2.3.4</code>")
        return

    if action == "add":
        added = whitelist_add(ip)
        blocked = ip in load_blocks()
        if blocked:
            await do_unblock(ip)
        await message.answer(
            f"✅ <code>{esc(ip)}</code> "
            + ("добавлен в whitelist." if added else "уже в whitelist.")
            + (" Блокировка снята." if blocked else "")
        )
    else:
        removed = whitelist_remove(ip)
        await message.answer(
            f"🗑 <code>{esc(ip)}</code> " + ("удалён из whitelist." if removed else "не найден в whitelist.")
        )


@router.message(F.text)
async def on_text(message: Message):
    ip = parse_ip(message.text or "")
    if ip:
        text, markup = await view_ip(ip)
        await message.answer(text, reply_markup=markup)
        return
    await message.answer("Не понял 🤔 Откройте /menu или /help.")


# ============================================================
# CALLBACKS
# ============================================================

def info_only_markup(ip: str) -> InlineKeyboardMarkup:
    return kb([[btn("🔎 Инфо", f"ip:{ip}")]])


async def refresh_after(cb: CallbackQuery, ip: str):
    head = cb.message.text or ""
    if head.startswith("🚫 Активные"):
        text, markup = view_blocks(0)
        await render(cb, text, markup)
    elif head.startswith("🔎"):
        text, markup = await view_ip(ip)
        await render(cb, text, markup)
    elif head.startswith("✅ Whitelist"):
        text, markup = view_whitelist()
        await render(cb, text, markup)
    else:
        try:
            await cb.message.edit_reply_markup(reply_markup=info_only_markup(ip))
        except TelegramAPIError:
            pass


async def handle_callback(cb: CallbackQuery):
    """Возвращает необязательный текст для всплывающего уведомления."""
    action, _, arg = (cb.data or "").partition(":")

    if action == "noop":
        return None

    if action == "m":
        await render(cb, *view_menu())

    elif action == "st":
        await render(cb, *view_status())

    elif action == "bp":
        await render(cb, *view_blocks(to_int(arg, 0)))

    elif action == "ev":
        await render(cb, *view_events(arg if arg in ("all", "failed", "success") else "all"))

    elif action == "tp":
        await render(cb, *view_top(to_int(arg, 24)))

    elif action == "sv":
        await render(cb, *view_server())

    elif action == "lg":
        text, markup = await view_logs()
        await render(cb, text, markup)

    elif action == "pr":
        sub, _, val = arg.partition(":")
        cfg = load_config()
        if sub == "en":
            update_protection({"enabled": not cfg["enabled"]})
        elif sub == "pm":
            update_protection({"permanent": not cfg["permanent"]})
        elif sub == "at":
            update_protection({"attempts": max(1, min(to_int(val, 5), 100))})
        elif sub == "du":
            update_protection({"duration": max(60, to_int(val, 600)), "permanent": False})
        await render(cb, *view_protection())

    elif action == "wl":
        await render(cb, *view_whitelist())

    elif action == "wa":
        ip = parse_ip(arg)
        if not ip:
            return "Некорректный IP"
        added = whitelist_add(ip)
        if ip in load_blocks():
            await do_unblock(ip)
        await refresh_after(cb, ip)
        return "✅ Добавлен в whitelist" if added else "Уже в whitelist"

    elif action == "wd":
        ip = parse_ip(arg)
        if not ip:
            return "Некорректный IP"
        removed = whitelist_remove(ip)
        await refresh_after(cb, ip)
        return "🗑 Удалён из whitelist" if removed else "Не найден"

    elif action == "nt":
        if arg.startswith("hr:"):
            hour = max(0, min(to_int(arg[3:], 9), 23))
            set_setting("report_hour", hour)
        elif arg in NOTIFY_LABELS:
            set_setting(arg, not settings().get(arg, False))
        await render(cb, *view_notify())

    elif action == "ip":
        ip = parse_ip(arg)
        if not ip:
            return "Некорректный IP"
        text, markup = await view_ip(ip)
        await render(cb, text, markup)

    elif action == "ub":
        ip = parse_ip(arg)
        if not ip:
            return "Некорректный IP"
        ok, info = await do_unblock(ip)
        if not ok:
            return "❌ " + info[:150]
        await refresh_after(cb, ip)
        return "✅ Разблокирован"

    elif action == "bk":
        ip = parse_ip(arg)
        if not ip:
            return "Некорректный IP"
        cfg = load_config()
        ok, info = await do_block(ip, cfg["permanent"], cfg["duration"], "Manual block via Telegram")
        if not ok:
            return "❌ " + info[:150]
        await refresh_after(cb, ip)
        return "🚫 Заблокирован"

    elif action == "ua":
        await render(cb, *view_unblock_all_confirm())

    elif action == "uay":
        blocks = list(load_blocks().keys())
        done = 0
        for ip in blocks:
            ok, _ = await do_unblock(ip)
            done += 1 if ok else 0
        await render(cb, *view_blocks(0))
        return f"✅ Разблокировано: {done}/{len(blocks)}"

    return None


@router.callback_query()
async def on_callback(cb: CallbackQuery):
    toast = None
    if cb.message is None:
        try:
            await cb.answer()
        except TelegramAPIError:
            pass
        return
    try:
        toast = await handle_callback(cb)
    except Exception as e:
        log.exception("Callback error: %s", e)
        toast = "Ошибка, смотрите логи"
    try:
        await cb.answer(toast or "")
    except TelegramAPIError:
        pass


# ============================================================
# BACKGROUND: WATCH GUARD FILES
# ============================================================

def event_key(e: dict) -> str:
    return "|".join(
        str(e.get(k, "")) for k in ("time", "type", "ip", "username", "raw")
    )


class Watcher:
    def __init__(self, bot: Bot):
        self.bot = bot
        self.events_mtime = mtime_ns(EVENTS_FILE)
        self.blocks_mtime = mtime_ns(BLOCKS_FILE)
        self.seen = Counter(event_key(e) for e in load_events())
        self.prev_blocks = load_blocks()

    async def run(self):
        while True:
            await asyncio.sleep(POLL_INTERVAL)
            try:
                await self.check_blocks()
                await self.check_events()
            except Exception as e:
                log.exception("Watcher error: %s", e)

    # ---------------- blocks ----------------

    async def check_blocks(self):
        current_mtime = mtime_ns(BLOCKS_FILE)
        if current_mtime == self.blocks_mtime:
            return
        self.blocks_mtime = current_mtime

        current = load_blocks()
        previous = self.prev_blocks
        self.prev_blocks = current
        s = settings()

        for ip, rec in current.items():
            old = previous.get(ip)
            stamp = rec.get("blocked_at")
            if old is not None and old.get("blocked_at") == stamp:
                continue
            if (ip, stamp) in SUPPRESS_BLOCK:
                SUPPRESS_BLOCK.discard((ip, stamp))
                continue
            if not (OWNER and s.get("notify_block")):
                continue
            await self.send_block(ip, rec)

        for ip, rec in previous.items():
            if ip in current:
                continue
            if ip in SUPPRESS_UNBLOCK:
                SUPPRESS_UNBLOCK.discard(ip)
                continue
            if not (OWNER and s.get("notify_unblock")):
                continue
            expired = (not rec.get("permanent")) and to_int(rec.get("expires_at"), 0) <= time.time() + POLL_INTERVAL
            reason = "срок блокировки истёк" if expired else "снята вручную на сервере"
            await notify(
                self.bot,
                f"✅ <b>IP разблокирован</b>\n<code>{esc(ip)}</code>\nПричина: {reason}",
                info_only_markup(ip),
            )

    async def send_block(self, ip: str, rec: dict):
        geo = await geo_lookup(ip)
        if rec.get("permanent"):
            term = "♾ навсегда"
        else:
            term = "на " + fmt_dur(rec.get("duration", 0))
        lines = [
            "🚫 <b>IP заблокирован</b>",
            "",
            f"🌐 <code>{esc(ip)}</code>",
        ]
        if geo:
            lines.append(geo)
        lines.append(f"⚠️ Неудачных попыток: <b>{to_int(rec.get('failed_attempts'))}</b>")
        lines.append(f"⏱ Срок: <b>{term}</b>")
        if not rec.get("permanent") and rec.get("expires_at"):
            lines.append(f"🕒 До: {fmt_ts(rec.get('expires_at'))}")
        if rec.get("reason"):
            lines.append(f"📝 {esc(rec.get('reason'))}")

        markup = kb([
            [btn("🔓 Разблокировать", f"ub:{ip}"), btn("✅ В whitelist", f"wa:{ip}")],
            [btn("🔎 Инфо", f"ip:{ip}")],
        ])
        await notify(self.bot, "\n".join(lines), markup)

    # ---------------- events ----------------

    async def check_events(self):
        current_mtime = mtime_ns(EVENTS_FILE)
        if current_mtime == self.events_mtime:
            return
        self.events_mtime = current_mtime

        events = load_events()
        remaining = Counter(self.seen)
        new = []
        for e in events:
            key = event_key(e)
            if remaining[key] > 0:
                remaining[key] -= 1
            else:
                new.append(e)
        self.seen = Counter(event_key(e) for e in events)

        if not new or not OWNER:
            return

        s = settings()
        failed = [e for e in new if e.get("type") == "failed"]
        success = [e for e in new if e.get("type") == "success"]

        if failed and s.get("notify_failed"):
            await self.send_failed(failed)

        for e in success[:5]:
            await self.send_login(e, s)
        if len(success) > 5:
            await notify(self.bot, f"🔑 …и ещё {len(success) - 5} входов по SSH.")

    async def send_failed(self, failed: list):
        by_ip = {}
        for e in failed:
            by_ip.setdefault(e.get("ip", "?"), []).append(e)
        lines = ["⚠️ <b>Неудачные попытки SSH</b>", ""]
        for ip, items in list(by_ip.items())[:10]:
            users = ", ".join(sorted({esc(i.get("username", "?")) for i in items})[:4])
            lines.append(f"<code>{esc(ip)}</code> ×{len(items)} ({users})")
        await notify(self.bot, "\n".join(lines))

    async def send_login(self, e: dict, s: dict):
        ip = e.get("ip", "?")
        is_new = ip not in known_ips()
        if is_new:
            remember_ip(ip)

        if not (s.get("notify_login") or (is_new and s.get("notify_new_ip"))):
            return

        geo = await geo_lookup(ip)
        lines = [
            "🔑 <b>Вход по SSH</b>",
            "",
            f"👤 <b>{esc(e.get('username', '?'))}</b>",
            f"🌐 <code>{esc(ip)}</code>",
        ]
        if geo:
            lines.append(geo)
        if e.get("auth_method"):
            lines.append(f"🔐 {esc(e.get('auth_method'))}")
        lines.append(f"🕒 {fmt_ts(e.get('time'))}")
        if is_new:
            lines.append("\n🆕 <b>Новый IP</b> — с него ещё не заходили.\nЕсли это не вы — заблокируйте!")

        markup = kb([
            [btn("🚫 Заблокировать", f"bk:{ip}"), btn("✅ В whitelist", f"wa:{ip}")],
            [btn("🔎 Инфо", f"ip:{ip}")],
        ])
        await notify(self.bot, "\n".join(lines), markup)


# ============================================================
# BACKGROUND: QUEUE
# ============================================================

async def queue_worker(bot: Bot):
    """
    Внешние скрипты кладут файлы в queue/:
      *.txt  - весь текст файла отправляется как есть
      *.json - {"text": "...", "html": false}
    Пишите во временный файл и переименовывайте в .txt/.json,
    чтобы бот не подхватил недописанный файл.
    """
    while True:
        await asyncio.sleep(QUEUE_INTERVAL)
        if not OWNER:
            continue
        try:
            files = sorted(p for p in QUEUE_DIR.glob("*") if p.is_file() and p.suffix in (".txt", ".json"))
        except Exception:
            continue

        for path in files:
            try:
                if time.time() - path.stat().st_mtime < 1:
                    continue
                raw = path.read_text(encoding="utf-8", errors="replace")
                use_html = False
                if path.suffix == ".json":
                    data = json.loads(raw)
                    if isinstance(data, dict):
                        text = str(data.get("text", "")).strip()
                        use_html = to_bool(data.get("html", False))
                    else:
                        text = str(data).strip()
                else:
                    text = raw.strip()
            except Exception as e:
                log.warning("Bad queue file %s: %s", path, e)
                try:
                    path.rename(path.with_name(path.name + ".failed"))
                except Exception:
                    pass
                continue

            if not text:
                path.unlink(missing_ok=True)
                continue

            try:
                await bot.send_message(
                    OWNER["chat_id"],
                    text[:4000],
                    parse_mode=ParseMode.HTML if use_html else None,
                )
                path.unlink(missing_ok=True)
            except TelegramAPIError as e:
                log.warning("Queue send failed (%s): %s", path.name, e)
                break


# ============================================================
# BACKGROUND: DAILY REPORT
# ============================================================

async def report_worker(bot: Bot):
    while True:
        await asyncio.sleep(30)
        try:
            if not OWNER:
                continue
            s = settings()
            if not s.get("daily_report"):
                continue
            now = datetime.now()
            today = now.strftime("%Y-%m-%d")
            if now.hour >= to_int(s.get("report_hour"), 9) and s.get("last_report") != today:
                set_setting("last_report", today)
                await notify(bot, build_report(24))
        except Exception as e:
            log.exception("Report error: %s", e)


# ============================================================
# MAIN
# ============================================================

async def main():
    token = read_token()
    if not token:
        log.error("BOT_TOKEN not found in %s", CONFIG_FILE)
        sys.exit(1)

    QUEUE_DIR.mkdir(parents=True, exist_ok=True)
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    load_owner()
    seed_known_ips()

    bot = Bot(token=token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()
    dp.include_router(router)

    me = await bot.get_me()
    log.info("Bot @%s started. Owner: %s", me.username, OWNER.get("user_id", "not registered"))

    try:
        await bot.set_my_commands([
            BotCommand(command="menu", description="Главное меню"),
            BotCommand(command="status", description="Статус и статистика"),
            BotCommand(command="blocks", description="Активные блокировки"),
            BotCommand(command="events", description="Последние события"),
            BotCommand(command="top", description="Топ атакующих"),
            BotCommand(command="server", description="Состояние сервера"),
            BotCommand(command="ip", description="Информация об IP"),
            BotCommand(command="block", description="Заблокировать IP"),
            BotCommand(command="unblock", description="Разблокировать IP"),
            BotCommand(command="whitelist", description="Whitelist"),
            BotCommand(command="help", description="Помощь"),
        ])
    except TelegramAPIError as e:
        log.warning("set_my_commands failed: %s", e)

    watcher = Watcher(bot)
    tasks = [
        asyncio.create_task(watcher.run()),
        asyncio.create_task(queue_worker(bot)),
        asyncio.create_task(report_worker(bot)),
    ]

    try:
        await dp.start_polling(bot, allowed_updates=["message", "callback_query"])
    finally:
        for task in tasks:
            task.cancel()
        await bot.session.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        log.info("Stopped.")