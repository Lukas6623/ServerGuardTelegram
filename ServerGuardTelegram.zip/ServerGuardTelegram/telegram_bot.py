#!/usr/bin/env python3

import asyncio

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

from config import load_config
from handlers import register_handlers
from monitor import security_monitor


VERSION = "2.0.0"


async def main():

    print(
        "========================================",
        flush=True
    )

    print(
        "       ServerGuard Telegram Bot",
        flush=True
    )

    print(
        f"       Version: {VERSION}",
        flush=True
    )

    print(
        "========================================",
        flush=True
    )

    token = load_config()

    if not token:

        print(
            "[ERROR] BOT_TOKEN was not found.",
            flush=True
        )

        print(
            "[ERROR] Check:",
            flush=True
        )

        print(
            "/opt/serverguard/telegram/telegram.conf",
            flush=True
        )

        return

    bot = Bot(

        token=token,

        default=DefaultBotProperties(
            parse_mode=ParseMode.HTML
        )
    )

    dp = Dispatcher()

    register_handlers(
        dp
    )

    try:

        me = await bot.get_me()

        print(
            f"[BOT] Connected as "
            f"@{me.username}",
            flush=True
        )

    except Exception as e:

        print(
            f"[ERROR] Telegram connection failed: {e}",
            flush=True
        )

        await bot.session.close()

        return

    monitor_task = asyncio.create_task(
        security_monitor(
            bot
        )
    )

    try:

        print(
            "[BOT] Polling started.",
            flush=True
        )

        await dp.start_polling(
            bot
        )

    except Exception as e:

        print(
            f"[BOT] Polling error: {e}",
            flush=True
        )

    finally:

        monitor_task.cancel()

        try:

            await monitor_task

        except asyncio.CancelledError:

            pass

        await bot.session.close()

        print(
            "[BOT] Stopped.",
            flush=True
        )


if __name__ == "__main__":

    try:

        asyncio.run(
            main()
        )

    except KeyboardInterrupt:

        print(
            "[BOT] Interrupted.",
            flush=True
        )