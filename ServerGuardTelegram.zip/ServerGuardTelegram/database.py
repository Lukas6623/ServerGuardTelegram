import json
import os
import time

from datetime import datetime, timezone

from config import (
    OWNER_FILE,
    VERIFICATION_FILE
)


# ============================================================
# JSON
# ============================================================

def load_json(
    path,
    default
):

    try:

        if not path.exists():

            return default

        with path.open(
            "r",
            encoding="utf-8"
        ) as file:

            return json.load(
                file
            )

    except Exception as e:

        print(
            f"[JSON] Cannot read "
            f"{path}: {e}",
            flush=True
        )

        return default


def save_json(
    path,
    data
):

    try:

        path.parent.mkdir(
            parents=True,
            exist_ok=True
        )

        temporary = path.with_suffix(
            path.suffix + ".tmp"
        )

        with temporary.open(
            "w",
            encoding="utf-8"
        ) as file:

            json.dump(
                data,
                file,
                ensure_ascii=False,
                indent=2
            )

            file.write("\n")

        os.replace(
            temporary,
            path
        )

        return True

    except Exception as e:

        print(
            f"[JSON] Cannot write "
            f"{path}: {e}",
            flush=True
        )

        return False


# ============================================================
# OWNER
# ============================================================

def get_owner():

    data = load_json(
        OWNER_FILE,
        {}
    )

    if not isinstance(
        data,
        dict
    ):

        return None

    if not data.get(
        "verified",
        False
    ):

        return None

    if not data.get(
        "chat_id"
    ):

        return None

    changed = False

    if not data.get(
        "timezone"
    ):

        data["timezone"] = "Europe/Kyiv"

        changed = True

    if not data.get(
        "language"
    ):

        data["language"] = "en"

        changed = True

    if changed:

        save_json(
            OWNER_FILE,
            data
        )

    return data


def is_owner(
    chat_id
):

    owner = get_owner()

    if not owner:

        return False

    try:

        return int(
            owner["chat_id"]
        ) == int(
            chat_id
        )

    except Exception:

        return False


# ============================================================
# OWNER LANGUAGE
# ============================================================

def get_owner_language():

    owner = get_owner()

    if not owner:

        return "en"

    language = owner.get(
        "language",
        "en"
    )

    if not isinstance(
        language,
        str
    ):

        return "en"

    return language


def set_owner_language(
    chat_id,
    language
):

    owner = get_owner()

    if not owner:

        return False

    try:

        if int(
            owner["chat_id"]
        ) != int(
            chat_id
        ):

            return False

    except Exception:

        return False

    owner["language"] = language

    return save_json(
        OWNER_FILE,
        owner
    )


# ============================================================
# TIMEZONE
# ============================================================

def get_owner_timezone():

    owner = get_owner()

    if not owner:

        return "Europe/Kyiv"

    return owner.get(
        "timezone",
        "Europe/Kyiv"
    )


def set_owner_timezone(
    chat_id,
    timezone_name
):

    owner = get_owner()

    if not owner:

        return False

    try:

        if int(
            owner["chat_id"]
        ) != int(
            chat_id
        ):

            return False

    except Exception:

        return False

    owner["timezone"] = timezone_name

    return save_json(
        OWNER_FILE,
        owner
    )


# ============================================================
# VERIFICATION
# ============================================================

def get_verification():

    data = load_json(
        VERIFICATION_FILE,
        {}
    )

    if not isinstance(
        data,
        dict
    ):

        return None

    code = str(
        data.get(
            "code",
            ""
        )
    )

    if not code:

        return None

    try:

        expires_at = int(
            data.get(
                "expires_at",
                0
            )
        )

    except Exception:

        return None

    if expires_at <= int(
        time.time()
    ):

        try:

            VERIFICATION_FILE.unlink(
                missing_ok=True
            )

        except Exception:
            pass

        return None

    return data


def register_owner(
    message
):

    user = message.from_user

    owner = {

        "chat_id":
            message.chat.id,

        "user_id":
            user.id
            if user
            else None,

        "username":
            user.username
            if user
            else None,

        "first_name":
            user.first_name
            if user
            else None,

        "registered_at":
            int(time.time()),

        "registered_at_iso":
            datetime.now(
                timezone.utc
            ).isoformat(),

        "timezone":
            "Europe/Kyiv",

        "language":
            "en",

        "verified":
            True
    }

    if not save_json(
        OWNER_FILE,
        owner
    ):

        return False

    try:

        VERIFICATION_FILE.unlink(
            missing_ok=True
        )

    except Exception:
        pass

    return True