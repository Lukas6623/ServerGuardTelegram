from config import (
    FILEGUARD_EVENTS_FILE
)

from database import load_json

import subprocess


IGNORED_PATHS = {

    "/opt/serverguard/telegram/"
    "seen_file_events.json.tmp"

}


def load_file_events():

    data = load_json(
        FILEGUARD_EVENTS_FILE,
        []
    )

    if not isinstance(
        data,
        list
    ):

        return []

    return data


def ignored_event(
    event
):

    if not isinstance(
        event,
        dict
    ):

        return True

    path = str(
        event.get(
            "path",
            ""
        )
    )

    return path in IGNORED_PATHS


def service_installed():

    return (

        (
            "/etc/systemd/system/"
            "serverguard-fileguard.service"
        )
    )


def service_active():

    try:

        result = subprocess.run(

            [
                "systemctl",
                "is-active",
                "serverguard-fileguard.service"
            ],

            capture_output=True,

            text=True,

            timeout=10
        )

        return (
            result.returncode == 0
            and
            result.stdout.strip()
            == "active"
        )

    except Exception:

        return False


def status():

    events = load_file_events()

    valid = []

    for event in events:

        if ignored_event(
            event
        ):

            continue

        valid.append(
            event
        )

    critical = 0

    high = 0

    medium = 0

    for event in valid:

        severity = str(
            event.get(
                "severity",
                ""
            )
        ).upper()

        if severity == "CRITICAL":

            critical += 1

        elif severity == "HIGH":

            high += 1

        elif severity == "MEDIUM":

            medium += 1

    return {

        "installed":
            service_installed(),

        "active":
            service_active(),

        "events":
            len(valid),

        "critical":
            critical,

        "high":
            high,

        "medium":
            medium
    }