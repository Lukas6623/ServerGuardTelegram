import html

from database import get_owner

from i18n import tr

from config import (
    SEEN_BLOCKS_FILE,
    SEEN_EVENTS_FILE,
    SEEN_FILEGUARD_EVENTS_FILE
)

from database import (
    load_json,
    save_json
)


async def send_block_notification(
    bot,
    ip,
    block
):

    owner = get_owner()

    if not owner:

        return False

    language = owner.get(
        "language",
        "en"
    )

    attempts = html.escape(
        str(
            block.get(
                "failed_attempts",
                "?"
            )
        )
    )

    level = html.escape(
        str(
            block.get(
                "level",
                "?"
            )
        )
    )

    blocked = html.escape(
        str(
            block.get(
                "blocked_at_iso",
                block.get(
                    "blocked_at",
                    "unknown"
                )
            )
        )
    )

    if block.get(
        "permanent",
        False
    ):

        text = tr(

            language,

            "notifications.permanent_block",

            ip=html.escape(
                str(ip)
            ),

            attempts=attempts,

            level=level,

            time=blocked
        )

    else:

        expires = html.escape(
            str(
                block.get(
                    "expires_at_iso",
                    block.get(
                        "expires_at",
                        "unknown"
                    )
                )
            )
        )

        text = tr(

            language,

            "notifications.block",

            ip=html.escape(
                str(ip)
            ),

            attempts=attempts,

            level=level,

            blocked=blocked,

            expires=expires
        )

    try:

        await bot.send_message(

            chat_id=int(
                owner["chat_id"]
            ),

            text=text
        )

        return True

    except Exception as e:

        print(
            f"[NOTIFY] Block error: {e}",
            flush=True
        )

        return False


async def send_success_notification(
    bot,
    event
):

    owner = get_owner()

    if not owner:

        return False

    language = owner.get(
        "language",
        "en"
    )

    username = html.escape(
        str(
            event.get(
                "username",
                "unknown"
            )
        )
    )

    ip = html.escape(
        str(
            event.get(
                "ip",
                "unknown"
            )
        )
    )

    method = html.escape(
        str(
            event.get(
                "auth_method",
                "unknown"
            )
        )
    )

    event_time = html.escape(
        str(
            event.get(
                "time_iso",
                event.get(
                    "time",
                    "unknown"
                )
            )
        )
    )

    text = tr(

        language,

        "notifications.success",

        username=username,

        ip=ip,

        method=method,

        time=event_time
    )

    fingerprint = event.get(
        "fingerprint"
    )

    if fingerprint:

        text += (

            "\n\n🔑 <b>Fingerprint:</b>\n"

            "<code>"

            + html.escape(
                str(
                    fingerprint
                )
            )

            + "</code>"
        )

    try:

        await bot.send_message(

            chat_id=int(
                owner["chat_id"]
            ),

            text=text
        )

        return True

    except Exception as e:

        print(
            f"[NOTIFY] SSH error: {e}",
            flush=True
        )

        return False


async def send_fileguard_notification(
    bot,
    event
):

    owner = get_owner()

    if not owner:

        return False

    language = owner.get(
        "language",
        "en"
    )

    path = html.escape(
        str(
            event.get(
                "path",
                "unknown"
            )
        )
    )

    event_type = html.escape(
        str(
            event.get(
                "event",
                "unknown"
            )
        )
    )

    severity = html.escape(
        str(
            event.get(
                "severity",
                "MEDIUM"
            )
        )
    )

    event_time = html.escape(
        str(
            event.get(
                "timestamp",
                event.get(
                    "time",
                    "unknown"
                )
            )
        )
    )

    text = tr(

        language,

        "notifications.fileguard",

        path=path,

        event=event_type,

        severity=severity,

        time=event_time
    )

    try:

        await bot.send_message(

            chat_id=int(
                owner["chat_id"]
            ),

            text=text
        )

        return True

    except Exception as e:

        print(
            f"[NOTIFY] FileGuard error: {e}",
            flush=True
        )

        return False