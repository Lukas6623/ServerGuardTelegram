
from aiogram.types import (
    InlineKeyboardMarkup,
    InlineKeyboardButton
)


# ============================================================
# MAIN KEYBOARD
# ============================================================

def main_keyboard(
    language=None
):

    return InlineKeyboardMarkup(
        inline_keyboard=[

            [
                InlineKeyboardButton(
                    text="🚫 Blocked IPs",
                    callback_data="menu:blocked"
                ),

                InlineKeyboardButton(
                    text="📋 Events",
                    callback_data="menu:events"
                )
            ],

            [
                InlineKeyboardButton(
                    text="🛡️ FileGuard",
                    callback_data="menu:fileguard"
                ),

                InlineKeyboardButton(
                    text="🌐 IP Management",
                    callback_data="menu:ip"
                )
            ],

            [
                InlineKeyboardButton(
                    text="⚙️ Settings",
                    callback_data="menu:settings"
                )
            ],

            [
                InlineKeyboardButton(
                    text="🔄 Refresh",
                    callback_data="menu:home"
                )
            ]
        ]
    )


# ============================================================
# IP KEYBOARD
# ============================================================

def ip_keyboard(
    language=None
):

    return InlineKeyboardMarkup(
        inline_keyboard=[

            [
                InlineKeyboardButton(
                    text="🚫 Block",
                    callback_data="ip:block"
                ),

                InlineKeyboardButton(
                    text="✅ Unblock",
                    callback_data="ip:unblock"
                )
            ],

            [
                InlineKeyboardButton(
                    text="🔍 Check",
                    callback_data="ip:check"
                ),

                InlineKeyboardButton(
                    text="📋 List",
                    callback_data="ip:list"
                )
            ],

            [
                InlineKeyboardButton(
                    text="◀️ Back",
                    callback_data="menu:home"
                )
            ]
        ]
    )


# ============================================================
# SETTINGS KEYBOARD
# ============================================================

def settings_keyboard(
    language=None
):

    return InlineKeyboardMarkup(
        inline_keyboard=[

            [
                InlineKeyboardButton(
                    text="🌍 Timezone",
                    callback_data="settings:timezone"
                )
            ],

            [
                InlineKeyboardButton(
                    text="🔔 Notifications",
                    callback_data="settings:notifications"
                )
            ],

            [
                InlineKeyboardButton(
                    text="◀️ Back",
                    callback_data="menu:home"
                )
            ]
        ]
    )


# ============================================================
# CONFIRM KEYBOARD
# ============================================================

def confirm_keyboard(
    language=None,
    action=None
):

    return InlineKeyboardMarkup(
        inline_keyboard=[

            [
                InlineKeyboardButton(
                    text="✅ Confirm",
                    callback_data=f"confirm:{action}"
                ),

                InlineKeyboardButton(
                    text="❌ Cancel",
                    callback_data="menu:ip"
                )
            ]
        ]
    )
