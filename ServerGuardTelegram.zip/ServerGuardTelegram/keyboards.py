from aiogram.types import (
    InlineKeyboardMarkup,
    InlineKeyboardButton
)


# ============================================================
# MAIN KEYBOARD
# ============================================================

def main_keyboard(
    language=None
):

    return InlineKeyboardMarkup(
        inline_keyboard=[

            [
                InlineKeyboardButton(
                    text="🛡️ Protection",
                    callback_data="menu:protection"
                )
            ],

            [
                InlineKeyboardButton(
                    text="🚫 Blocked IPs",
                    callback_data="menu:blocked"
                ),

                InlineKeyboardButton(
                    text="📋 Events",
                    callback_data="menu:events"
                )
            ],

            [
                InlineKeyboardButton(
                    text="🛡️ FileGuard",
                    callback_data="menu:fileguard"
                ),

                InlineKeyboardButton(
                    text="🌐 IP Management",
                    callback_data="menu:ip"
                )
            ],

            [
                InlineKeyboardButton(
                    text="⚙️ Settings",
                    callback_data="menu:settings"
                )
            ],

            [
                InlineKeyboardButton(
                    text="🔄 Refresh",
                    callback_data="menu:home"
                )
            ]
        ]
    )


# ============================================================
# PROTECTION SETTINGS KEYBOARD
# ============================================================

def protection_keyboard():

    return InlineKeyboardMarkup(
        inline_keyboard=[

            [
                InlineKeyboardButton(
                    text="🟢 / 🔴 Enable / Disable",
                    callback_data="protection:toggle"
                )
            ],

            [
                InlineKeyboardButton(
                    text="🔢 Attempts",
                    callback_data="protection:attempts"
                ),

                InlineKeyboardButton(
                    text="⏱ Duration",
                    callback_data="protection:duration"
                )
            ],

            [
                InlineKeyboardButton(
                    text="♾️ Permanent blocking",
                    callback_data="protection:permanent"
                )
            ],

            [
                InlineKeyboardButton(
                    text="🌐 Whitelist",
                    callback_data="protection:whitelist"
                )
            ],

            [
                InlineKeyboardButton(
                    text="📊 Statistics",
                    callback_data="protection:show"
                )
            ],

            [
                InlineKeyboardButton(
                    text="⚙️ Reset settings",
                    callback_data="protection:reset"
                )
            ],

            [
                InlineKeyboardButton(
                    text="🔄 Refresh",
                    callback_data="protection:show"
                )
            ],

            [
                InlineKeyboardButton(
                    text="◀️ Back to Settings",
                    callback_data="menu:settings"
                )
            ]
        ]
    )


# ============================================================
# ATTEMPTS KEYBOARD
# ============================================================

def protection_attempts_keyboard():

    return InlineKeyboardMarkup(
        inline_keyboard=[

            [
                InlineKeyboardButton(
                    text="1",
                    callback_data="protection_attempts:1"
                ),

                InlineKeyboardButton(
                    text="2",
                    callback_data="protection_attempts:2"
                ),

                InlineKeyboardButton(
                    text="3",
                    callback_data="protection_attempts:3"
                ),

                InlineKeyboardButton(
                    text="5",
                    callback_data="protection_attempts:5"
                )
            ],

            [
                InlineKeyboardButton(
                    text="10",
                    callback_data="protection_attempts:10"
                ),

                InlineKeyboardButton(
                    text="20",
                    callback_data="protection_attempts:20"
                ),

                InlineKeyboardButton(
                    text="50",
                    callback_data="protection_attempts:50"
                ),

                InlineKeyboardButton(
                    text="100",
                    callback_data="protection_attempts:100"
                )
            ],

            [
                InlineKeyboardButton(
                    text="✏️ Custom value",
                    callback_data="protection_attempts:custom"
                )
            ],

            [
                InlineKeyboardButton(
                    text="◀️ Back",
                    callback_data="protection:show"
                )
            ]
        ]
    )


# ============================================================
# DURATION KEYBOARD
# ============================================================

def protection_duration_keyboard():

    return InlineKeyboardMarkup(
        inline_keyboard=[

            [
                InlineKeyboardButton(
                    text="1 min",
                    callback_data="protection_duration:60"
                ),

                InlineKeyboardButton(
                    text="5 min",
                    callback_data="protection_duration:300"
                ),

                InlineKeyboardButton(
                    text="10 min",
                    callback_data="protection_duration:600"
                )
            ],

            [
                InlineKeyboardButton(
                    text="20 min",
                    callback_data="protection_duration:1200"
                ),

                InlineKeyboardButton(
                    text="30 min",
                    callback_data="protection_duration:1800"
                ),

                InlineKeyboardButton(
                    text="1 hour",
                    callback_data="protection_duration:3600"
                )
            ],

            [
                InlineKeyboardButton(
                    text="2 hours",
                    callback_data="protection_duration:7200"
                ),

                InlineKeyboardButton(
                    text="6 hours",
                    callback_data="protection_duration:21600"
                ),

                InlineKeyboardButton(
                    text="12 hours",
                    callback_data="protection_duration:43200"
                )
            ],

            [
                InlineKeyboardButton(
                    text="24 hours",
                    callback_data="protection_duration:86400"
                )
            ],

            [
                InlineKeyboardButton(
                    text="7 days",
                    callback_data="protection_duration:604800"
                ),

                InlineKeyboardButton(
                    text="30 days",
                    callback_data="protection_duration:2592000"
                )
            ],

            [
                InlineKeyboardButton(
                    text="✏️ Custom value",
                    callback_data="protection_duration:custom"
                )
            ],

            [
                InlineKeyboardButton(
                    text="◀️ Back",
                    callback_data="protection:show"
                )
            ]
        ]
    )


# ============================================================
# PERMANENT KEYBOARD
# ============================================================

def protection_permanent_keyboard():

    return InlineKeyboardMarkup(
        inline_keyboard=[

            [
                InlineKeyboardButton(
                    text="♾️ Permanent",
                    callback_data="protection_permanent:on"
                )
            ],

            [
                InlineKeyboardButton(
                    text="⏱️ Temporary",
                    callback_data="protection_permanent:off"
                )
            ],

            [
                InlineKeyboardButton(
                    text="◀️ Back",
                    callback_data="protection:show"
                )
            ]
        ]
    )


# ============================================================
# WHITELIST KEYBOARD
# ============================================================

def protection_whitelist_keyboard():

    return InlineKeyboardMarkup(
        inline_keyboard=[

            [
                InlineKeyboardButton(
                    text="➕ Add IP",
                    callback_data="protection_whitelist:add"
                )
            ],

            [
                InlineKeyboardButton(
                    text="➖ Remove IP",
                    callback_data="protection_whitelist:remove"
                )
            ],

            [
                InlineKeyboardButton(
                    text="📋 List",
                    callback_data="protection_whitelist:list"
                )
            ],

            [
                InlineKeyboardButton(
                    text="◀️ Back",
                    callback_data="protection:show"
                )
            ]
        ]
    )


# ============================================================
# IP KEYBOARD
# ============================================================

def ip_keyboard(
    language=None
):

    return InlineKeyboardMarkup(
        inline_keyboard=[

            [
                InlineKeyboardButton(
                    text="🚫 Block",
                    callback_data="ip:block"
                ),

                InlineKeyboardButton(
                    text="✅ Unblock",
                    callback_data="ip:unblock"
                )
            ],

            [
                InlineKeyboardButton(
                    text="🔍 Check",
                    callback_data="ip:check"
                ),

                InlineKeyboardButton(
                    text="📋 List",
                    callback_data="ip:list"
                )
            ],

            [
                InlineKeyboardButton(
                    text="◀️ Back",
                    callback_data="menu:home"
                )
            ]
        ]
    )


# ============================================================
# SETTINGS KEYBOARD
# ============================================================

def settings_keyboard(
    language=None
):

    return InlineKeyboardMarkup(
        inline_keyboard=[

            [
                InlineKeyboardButton(
                    text="🛡️ Protection settings",
                    callback_data="settings:protection"
                )
            ],

            [
                InlineKeyboardButton(
                    text="🌍 Timezone",
                    callback_data="settings:timezone"
                )
            ],

            [
                InlineKeyboardButton(
                    text="🔔 Notifications",
                    callback_data="settings:notifications"
                )
            ],

            [
                InlineKeyboardButton(
                    text="◀️ Back",
                    callback_data="menu:home"
                )
            ]
        ]
    )


# ============================================================
# CONFIRM KEYBOARD
# ============================================================

def confirm_keyboard(
    language=None,
    action=None
):

    return InlineKeyboardMarkup(
        inline_keyboard=[

            [
                InlineKeyboardButton(
                    text="✅ Confirm",
                    callback_data=f"confirm:{action}"
                ),

                InlineKeyboardButton(
                    text="❌ Cancel",
                    callback_data="menu:ip"
                )
            ]
        ]
    )