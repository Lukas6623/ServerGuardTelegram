import asyncio

from config import (
    CHECK_INTERVAL,
    SEEN_BLOCKS_FILE,
    SEEN_EVENTS_FILE,
    SEEN_FILEGUARD_EVENTS_FILE,
    FILEGUARD_EVENTS_FILE
)

from database import (
    load_json,
    save_json,
    get_owner
)

from security import (
    load_events,
    active_blocks,
    event_signature,
    block_signature
)

from fileguard import (
    load_file_events,
    ignored_event
)

from notifications import (
    send_block_notification,
    send_success_notification,
    send_fileguard_notification
)


def load_seen(
    path
):

    data = load_json(
        path,
        []
    )

    if not isinstance(
        data,
        list
    ):

        return set()

    return set(
        str(x)
        for x in data
    )


def save_seen(
    path,
    values
):

    return save_json(
        path,
        list(values)
    )


def file_event_signature(
    event
):

    return "|".join(

        [
            str(
                event.get(
                    "timestamp",
                    ""
                )
            ),

            str(
                event.get(
                    "time",
                    ""
                )
            ),

            str(
                event.get(
                    "path",
                    ""
                )
            ),

            str(
                event.get(
                    "event",
                    ""
                )
            ),

            str(
                event.get(
                    "severity",
                    ""
                )
            )
        ]
    )


async def security_monitor(
    bot
):

    print(
        "[MONITOR] Started.",
        flush=True
    )

    seen_blocks = load_seen(
        SEEN_BLOCKS_FILE
    )

    seen_events = load_seen(
        SEEN_EVENTS_FILE
    )

    seen_file_events = load_seen(
        SEEN_FILEGUARD_EVENTS_FILE
    )

    while True:

        try:

            owner = get_owner()

            if not owner:

                await asyncio.sleep(
                    CHECK_INTERVAL
                )

                continue

            # =================================================
            # SSH EVENTS
            # =================================================

            events = load_events()

            current_events = set()

            for event in events:

                if not isinstance(
                    event,
                    dict
                ):

                    continue

                if event.get(
                    "type"
                ) != "success":

                    continue

                signature = event_signature(
                    event
                )

                current_events.add(
                    signature
                )

                if signature in seen_events:

                    continue

                success = (
                    await send_success_notification(
                        bot,
                        event
                    )
                )

                if success:

                    seen_events.add(
                        signature
                    )

            if current_events:

                seen_events = (
                    seen_events
                    & current_events
                )

            save_seen(
                SEEN_EVENTS_FILE,
                seen_events
            )

            # =================================================
            # BLOCKS
            # =================================================

            blocks = active_blocks()

            current_blocks = set()

            for ip, block in blocks.items():

                signature = block_signature(
                    ip,
                    block
                )

                current_blocks.add(
                    signature
                )

                if signature in seen_blocks:

                    continue

                success = (
                    await send_block_notification(
                        bot,
                        ip,
                        block
                    )
                )

                if success:

                    seen_blocks.add(
                        signature
                    )

            if current_blocks:

                seen_blocks = (
                    seen_blocks
                    & current_blocks
                )

            save_seen(
                SEEN_BLOCKS_FILE,
                seen_blocks
            )

            # =================================================
            # FILEGUARD
            # =================================================

            file_events = load_file_events()

            current_file_events = set()

            for event in file_events:

                if not isinstance(
                    event,
                    dict
                ):

                    continue

                if ignored_event(
                    event
                ):

                    continue

                signature = file_event_signature(
                    event
                )

                current_file_events.add(
                    signature
                )

                if signature in seen_file_events:

                    continue

                success = (
                    await send_fileguard_notification(
                        bot,
                        event
                    )
                )

                if success:

                    seen_file_events.add(
                        signature
                    )

            if current_file_events:

                seen_file_events = (
                    seen_file_events
                    & current_file_events
                )

            save_seen(
                SEEN_FILEGUARD_EVENTS_FILE,
                seen_file_events
            )

        except Exception as e:

            print(
                f"[MONITOR] Error: {e}",
                flush=True
            )

        await asyncio.sleep(
            CHECK_INTERVAL
        )