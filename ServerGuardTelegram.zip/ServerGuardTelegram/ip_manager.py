import ipaddress
import subprocess


def validate_ip(
    value
):

    try:

        return str(
            ipaddress.ip_address(
                value.strip()
            )
        )

    except ValueError:

        return None


def get_server_ips():

    result = set()

    try:

        output = subprocess.check_output(
            [
                "hostname",
                "-I"
            ],
            text=True,
            stderr=subprocess.DEVNULL
        )

        for value in output.split():

            ip = validate_ip(
                value
            )

            if ip:

                result.add(
                    ip
                )

    except Exception as e:

        print(
            f"[IP] Cannot get server IPs: {e}",
            flush=True
        )

    return result


def ufw_is_blocked(
    ip
):

    try:

        result = subprocess.run(

            [
                "ufw",
                "status"
            ],

            capture_output=True,

            text=True,

            timeout=10
        )

        if result.returncode != 0:

            return False

        for line in (
            result.stdout
            .splitlines()
        ):

            if ip in line:

                if (
                    "DENY"
                    in line
                    or
                    "REJECT"
                    in line
                ):

                    return True

    except Exception as e:

        print(
            f"[UFW] Status error: {e}",
            flush=True
        )

    return False


def ufw_block_ip(
    ip
):

    ip = validate_ip(
        ip
    )

    if not ip:

        return False

    if ip in get_server_ips():

        print(
            f"[UFW] Refusing to block "
            f"server IP {ip}",
            flush=True
        )

        return False

    try:

        result = subprocess.run(

            [
                "ufw",
                "insert",
                "1",
                "deny",
                "from",
                ip
            ],

            capture_output=True,

            text=True,

            timeout=15
        )

        if result.returncode == 0:

            print(
                f"[UFW] Blocked {ip}",
                flush=True
            )

            return True

        print(
            f"[UFW] Block failed: "
            f"{result.stderr.strip()}",
            flush=True
        )

    except Exception as e:

        print(
            f"[UFW] Block exception: {e}",
            flush=True
        )

    return False


def ufw_unblock_ip(
    ip
):

    ip = validate_ip(
        ip
    )

    if not ip:

        return False

    try:

        result = subprocess.run(

            [
                "ufw",
                "delete",
                "deny",
                "from",
                ip
            ],

            capture_output=True,

            text=True,

            timeout=15
        )

        if result.returncode == 0:

            print(
                f"[UFW] Unblocked {ip}",
                flush=True
            )

            return True

        print(
            f"[UFW] Unblock failed: "
            f"{result.stderr.strip()}",
            flush=True
        )

    except Exception as e:

        print(
            f"[UFW] Unblock exception: {e}",
            flush=True
        )

    return False