"""
ServerGuard Telegram Bot
English-only localization.

The bot has no language selection.
All user-facing text is always in English.
"""

from config import LOCALES_DIR


DEFAULT_LANGUAGE = "en"


# ============================================================
# LANGUAGE
# ============================================================

def current_language():
    """
    The bot is English-only.
    """
    return DEFAULT_LANGUAGE


# ============================================================
# LOAD ENGLISH
# ============================================================

_cache = {}


def load_language(language=None):

    language = DEFAULT_LANGUAGE

    if language in _cache:
        return _cache[language]

    path = (
        LOCALES_DIR /
        f"{DEFAULT_LANGUAGE}.json"
    )

    data = {}

    try:

        if path.exists():

            import json

            with path.open(
                "r",
                encoding="utf-8"
            ) as file:

                data = json.load(
                    file
                )

    except Exception as e:

        print(
            f"[I18N] Cannot load English locale: {e}",
            flush=True
        )

    _cache[language] = data

    return data


# ============================================================
# NESTED VALUE
# ============================================================

def get_nested(
    data,
    key
):

    current = data

    for part in key.split("."):

        if not isinstance(
            current,
            dict
        ):

            return None

        current = current.get(
            part
        )

    return current


# ============================================================
# TRANSLATION
# ============================================================

def tr(
    language=None,
    key=None,
    **kwargs
):
    """
    English-only translation function.

    The language argument is intentionally ignored.
    It is kept for compatibility with the existing bot code.
    """

    # --------------------------------------------------------
    # Compatibility:
    #
    # tr("some.key")
    # tr("en", "some.key")
    # --------------------------------------------------------

    if key is None:

        key = language

    if key is None:

        return ""

    data = load_language(
        DEFAULT_LANGUAGE
    )

    value = get_nested(
        data,
        key
    )

    if value is None:

        return str(
            key
        )

    value = str(
        value
    )

    try:

        return value.format(
            **kwargs
        )

    except Exception:

        return value