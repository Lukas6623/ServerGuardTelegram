from aiogram.types import Message

from database import (
    get_owner,
    get_verification,
    register_owner
)

from i18n import tr

from keyboards import main_keyboard


async def handle_start(
    message: Message
):

    chat_id = message.chat.id

    owner = get_owner()

    # --------------------------------------------------------
    # ALREADY OWNER
    # --------------------------------------------------------

    if owner:

        try:

            if int(
                owner["chat_id"]
            ) == int(
                chat_id
            ):

                language = owner.get(
                    "language",
                    "en"
                )

                await message.answer(

                    tr(
                        language,
                        "welcome.owner"
                    ),

                    reply_markup=main_keyboard(
                        language
                    )
                )

                return

        except Exception:
            pass

        await message.answer(
            tr(
                "en",
                "registration.owner_exists"
            )
        )

        return

    # --------------------------------------------------------
    # CODE
    # --------------------------------------------------------

    parts = (
        message.text or ""
    ).split(
        maxsplit=1
    )

    if len(parts) < 2:

        await message.answer(

            tr(
                "en",
                "registration.instructions"
            )
        )

        return

    code = parts[1].strip()

    if (
        not code.isdigit()
        or
        len(code) != 6
    ):

        await message.answer(

            tr(
                "en",
                "registration.invalid_code"
            )
        )

        return

    verification = get_verification()

    if not verification:

        await message.answer(

            tr(
                "en",
                "registration.expired"
            )
        )

        return

    expected = str(
        verification.get(
            "code",
            ""
        )
    )

    if code != expected:

        await message.answer(

            tr(
                "en",
                "registration.wrong_code"
            )
        )

        return

    if not register_owner(
        message
    ):

        await message.answer(

            tr(
                "en",
                "registration.failed"
            )
        )

        return

    await message.answer(

        tr(
            "en",
            "registration.success"
        ),

        reply_markup=main_keyboard(
            "en"
        )
    )

    print(
        f"[OWNER] Registered chat_id={chat_id}",
        flush=True
    )