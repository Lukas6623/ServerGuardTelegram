from pathlib import Path


# ============================================================
# SERVERGUARD
# ============================================================

BASE_DIR = Path(
    "/opt/serverguard"
)


DATA_DIR = (
    BASE_DIR / "data"
)


TELEGRAM_DIR = (
    BASE_DIR / "telegram"
)


LOCALES_DIR = (
    TELEGRAM_DIR / "locales"
)


# ============================================================
# TELEGRAM
# ============================================================

CONFIG_FILE = (
    TELEGRAM_DIR / "telegram.conf"
)


OWNER_FILE = (
    TELEGRAM_DIR / "owner.json"
)


VERIFICATION_FILE = (
    TELEGRAM_DIR / "verification.json"
)


SEEN_BLOCKS_FILE = (
    TELEGRAM_DIR / "seen_blocks.json"
)


SEEN_EVENTS_FILE = (
    TELEGRAM_DIR / "seen_events.json"
)


SEEN_FILEGUARD_EVENTS_FILE = (
    TELEGRAM_DIR / "seen_file_events.json"
)


# ============================================================
# SERVERGUARD DATA
# ============================================================

EVENTS_FILE = (
    DATA_DIR / "ssh_events.json"
)


BLOCKS_FILE = (
    DATA_DIR / "blocked_ips.json"
)


STATS_FILE = (
    DATA_DIR / "ip_stats.json"
)


FILEGUARD_EVENTS_FILE = (
    DATA_DIR / "file_events.json"
)


# ============================================================
# SETTINGS
# ============================================================

CHECK_INTERVAL = 3

MAX_EVENTS_TO_SHOW = 10

MAX_BLOCKS_TO_SHOW = 30

MAX_FILE_EVENTS_TO_SHOW = 20

VERIFICATION_TIMEOUT = 600

DEFAULT_TIMEZONE = "Europe/Kyiv"

DEFAULT_LANGUAGE = "en"


# ============================================================
# CREATE DIRECTORIES
# ============================================================

BASE_DIR.mkdir(
    parents=True,
    exist_ok=True
)


DATA_DIR.mkdir(
    parents=True,
    exist_ok=True
)


TELEGRAM_DIR.mkdir(
    parents=True,
    exist_ok=True
)


LOCALES_DIR.mkdir(
    parents=True,
    exist_ok=True
)


# ============================================================
# CONFIG LOADER
# ============================================================

def load_config():

    if not CONFIG_FILE.exists():

        return ""

    try:

        with CONFIG_FILE.open(
            "r",
            encoding="utf-8"
        ) as file:

            for raw_line in file:

                line = raw_line.strip()

                if not line:
                    continue

                if line.startswith("#"):
                    continue

                if line.startswith(
                    "BOT_TOKEN="
                ):

                    return line.split(
                        "=",
                        1
                    )[1].strip()

    except Exception as e:

        print(
            f"[CONFIG] Read error: {e}",
            flush=True
        )

    return ""