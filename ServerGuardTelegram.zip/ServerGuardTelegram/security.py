from config import (
    EVENTS_FILE,
    BLOCKS_FILE,
    STATS_FILE,
    MAX_EVENTS_TO_SHOW,
    MAX_BLOCKS_TO_SHOW
)

from database import load_json

import html
import time


# ============================================================
# LOAD EVENTS
# ============================================================

def load_events():

    data = load_json(
        EVENTS_FILE,
        []
    )

    if not isinstance(
        data,
        list
    ):
        return []

    return data


# ============================================================
# LOAD BLOCKS
# ============================================================

def load_blocks():

    data = load_json(
        BLOCKS_FILE,
        {}
    )

    if not isinstance(
        data,
        dict
    ):
        return {}

    return data


# ============================================================
# LOAD STATS
# ============================================================

def load_stats():

    data = load_json(
        STATS_FILE,
        {}
    )

    if not isinstance(
        data,
        dict
    ):
        return {}

    return data


# ============================================================
# CHECK BLOCK
# ============================================================

def block_is_active(
    block
):

    if not isinstance(
        block,
        dict
    ):
        return False

    if block.get(
        "permanent",
        False
    ):
        return True

    expires_at = block.get(
        "expires_at"
    )

    if expires_at is None:
        return False

    try:

        return int(
            expires_at
        ) > int(
            time.time()
        )

    except Exception:

        return False


# ============================================================
# ACTIVE BLOCKS
# ============================================================

def active_blocks():

    blocks = load_blocks()

    result = {}

    for ip, block in blocks.items():

        if block_is_active(
            block
        ):

            result[
                ip
            ] = block

    return result


# ============================================================
# SECURITY STATUS
# ============================================================

def security_status():

    events = load_events()
    blocks = active_blocks()
    stats = load_stats()

    failed = 0
    success = 0

    for event in events:

        if not isinstance(
            event,
            dict
        ):
            continue

        event_type = event.get(
            "type"
        )

        if event_type == "failed":

            failed += 1

        elif event_type == "success":

            success += 1

    return {

        "events":
            len(events),

        "failed":
            failed,

        "success":
            success,

        "blocked":
            len(blocks),

        "stats":
            len(stats)
    }


# ============================================================
# STATUS TEXT
# ============================================================

def build_status_text(
    language=None
):

    status = security_status()

    return (

        "🛡️ <b>ServerGuard Status</b>\n\n"

        "🔐 <b>SSH:</b> ACTIVE\n"
        "🤖 <b>Telegram:</b> ACTIVE\n\n"

        f"📋 <b>Events:</b> "
        f"{status['events']}\n"

        f"❌ <b>Failed:</b> "
        f"{status['failed']}\n"

        f"✅ <b>Successful:</b> "
        f"{status['success']}\n"

        f"🚫 <b>Blocked IPs:</b> "
        f"{status['blocked']}\n"

        f"📊 <b>Statistics:</b> "
        f"{status['stats']}"
    )


# ============================================================
# BLOCKED TEXT
# ============================================================

def build_blocked_text(
    language=None
):

    blocks = active_blocks()

    if not blocks:

        return (
            "🚫 <b>Blocked IPs</b>\n\n"
            "No active blocked IP addresses."
        )

    lines = [

        "🚫 <b>Blocked IPs</b>",
        ""
    ]

    count = 0

    for ip, block in blocks.items():

        if count >= MAX_BLOCKS_TO_SHOW:

            break

        attempts = html.escape(
            str(
                block.get(
                    "failed_attempts",
                    "?"
                )
            )
        )

        if block.get(
            "permanent",
            False
        ):

            lines.append(

                f"♾️ <code>{html.escape(str(ip))}</code> "
                f"— permanent "
                f"({attempts} attempts)"
            )

        else:

            expires = html.escape(
                str(
                    block.get(
                        "expires_at_iso",
                        block.get(
                            "expires_at",
                            "?"
                        )
                    )
                )
            )

            lines.append(

                f"⏱️ <code>{html.escape(str(ip))}</code> "
                f"— until {expires} "
                f"({attempts} attempts)"
            )

        count += 1

    return "\n".join(
        lines
    )


# ============================================================
# EVENTS TEXT
# ============================================================

def build_events_text(
    language=None
):

    events = load_events()

    if not events:

        return (
            "📋 <b>SSH Events</b>\n\n"
            "No events recorded."
        )

    events = events[
        -MAX_EVENTS_TO_SHOW:
    ]

    lines = [

        "📋 <b>SSH Events</b>",
        ""
    ]

    for event in reversed(
        events
    ):

        if not isinstance(
            event,
            dict
        ):
            continue

        event_type = str(
            event.get(
                "type",
                "unknown"
            )
        )

        username = html.escape(
            str(
                event.get(
                    "username",
                    "unknown"
                )
            )
        )

        ip = html.escape(
            str(
                event.get(
                    "ip",
                    "unknown"
                )
            )
        )

        event_time = html.escape(
            str(
                event.get(
                    "time_iso",
                    event.get(
                        "time",
                        "unknown"
                    )
                )
            )
        )

        if event_type == "success":

            icon = "✅"

        elif event_type == "failed":

            icon = "❌"

        else:

            icon = "ℹ️"

        lines.append(

            f"{icon} "
            f"<code>{event_time}</code>\n"
            f"👤 User: <code>{username}</code>\n"
            f"🌐 IP: <code>{ip}</code>"
        )

    return "\n".join(
        lines
    )


# ============================================================
# EVENT SIGNATURE
# ============================================================

def event_signature(
    event
):

    return "|".join(
        [

            str(
                event.get(
                    "time",
                    ""
                )
            ),

            str(
                event.get(
                    "type",
                    ""
                )
            ),

            str(
                event.get(
                    "username",
                    ""
                )
            ),

            str(
                event.get(
                    "ip",
                    ""
                )
            ),

            str(
                event.get(
                    "auth_method",
                    ""
                )
            ),

            str(
                event.get(
                    "fingerprint",
                    ""
                )
            )
        ]
    )


# ============================================================
# BLOCK SIGNATURE
# ============================================================

def block_signature(
    ip,
    block
):

    return "|".join(
        [

            str(ip),

            str(
                block.get(
                    "level",
                    ""
                )
            ),

            str(
                block.get(
                    "failed_attempts",
                    ""
                )
            ),

            str(
                block.get(
                    "blocked_at",
                    ""
                )
            ),

            str(
                block.get(
                    "expires_at",
                    ""
                )
            ),

            str(
                block.get(
                    "permanent",
                    ""
                )
            )
        ]
    )