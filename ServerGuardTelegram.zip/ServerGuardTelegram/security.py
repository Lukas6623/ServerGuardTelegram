from config import (
    EVENTS_FILE,
    BLOCKS_FILE,
    STATS_FILE,
    MAX_EVENTS_TO_SHOW,
    MAX_BLOCKS_TO_SHOW
)

from database import load_json

from i18n import tr

import html
import time


def load_events():

    data = load_json(
        EVENTS_FILE,
        []
    )

    if not isinstance(
        data,
        list
    ):

        return []

    return data


def load_blocks():

    data = load_json(
        BLOCKS_FILE,
        {}
    )

    if not isinstance(
        data,
        dict
    ):

        return {}

    return data


def load_stats():

    data = load_json(
        STATS_FILE,
        {}
    )

    if not isinstance(
        data,
        dict
    ):

        return {}

    return data


def block_is_active(
    block
):

    if not isinstance(
        block,
        dict
    ):

        return False

    if block.get(
        "permanent",
        False
    ):

        return True

    expires_at = block.get(
        "expires_at"
    )

    if expires_at is None:

        return False

    try:

        return int(
            expires_at
        ) > int(
            time.time()
        )

    except Exception:

        return False


def active_blocks():

    blocks = load_blocks()

    result = {}

    for ip, block in blocks.items():

        if block_is_active(
            block
        ):

            result[
                ip
            ] = block

    return result


def security_status():

    events = load_events()

    blocks = active_blocks()

    stats = load_stats()

    failed = 0

    success = 0

    for event in events:

        if not isinstance(
            event,
            dict
        ):

            continue

        event_type = event.get(
            "type"
        )

        if event_type == "failed":

            failed += 1

        elif event_type == "success":

            success += 1

    return {

        "events":
            len(events),

        "failed":
            failed,

        "success":
            success,

        "blocked":
            len(blocks),

        "stats":
            len(stats)
    }


def format_time(
    value
):

    if not value:

        return "unknown"

    try:

        return str(
            value
        )

    except Exception:

        return "unknown"


def build_status_text(
    language
):

    status = security_status()

    return (

        tr(
            language,
            "status.title"
        )

        + "\n\n"

        + tr(
            language,
            "status.ssh"
        )

        + "\n"

        + tr(
            language,
            "status.telegram"
        )

        + "\n\n"

        + tr(
            language,
            "status.events",
            value=status["events"]
        )

        + "\n"

        + tr(
            language,
            "status.failed",
            value=status["failed"]
        )

        + "\n"

        + tr(
            language,
            "status.success",
            value=status["success"]
        )

        + "\n"

        + tr(
            language,
            "status.blocked",
            value=status["blocked"]
        )

        + "\n"

        + tr(
            language,
            "status.stats",
            value=status["stats"]
        )
    )


def build_blocked_text(
    language
):

    blocks = active_blocks()

    if not blocks:

        return tr(
            language,
            "blocked.none"
        )

    lines = [

        tr(
            language,
            "blocked.title"
        ),

        ""
    ]

    count = 0

    for ip, block in blocks.items():

        if count >= MAX_BLOCKS_TO_SHOW:

            break

        attempts = html.escape(
            str(
                block.get(
                    "failed_attempts",
                    "?"
                )
            )
        )

        level = html.escape(
            str(
                block.get(
                    "level",
                    "?"
                )
            )
        )

        if block.get(
            "permanent",
            False
        ):

            lines.append(
                tr(
                    language,
                    "blocked.permanent",
                    ip=html.escape(
                        str(ip)
                    ),
                    attempts=attempts
                )
            )

        else:

            expires = html.escape(
                str(
                    block.get(
                        "expires_at_iso",
                        block.get(
                            "expires_at",
                            "?"
                        )
                    )
                )
            )

            lines.append(
                tr(
                    language,
                    "blocked.temporary",
                    ip=html.escape(
                        str(ip)
                    ),
                    attempts=attempts,
                    level=level,
                    expires=expires
                )
            )

        count += 1

    return "\n".join(
        lines
    )


def build_events_text(
    language
):

    events = load_events()

    if not events:

        return tr(
            language,
            "events.none"
        )

    events = events[
        -MAX_EVENTS_TO_SHOW:
    ]

    lines = [

        tr(
            language,
            "events.title"
        ),

        ""
    ]

    for event in reversed(
        events
    ):

        if not isinstance(
            event,
            dict
        ):

            continue

        event_type = str(
            event.get(
                "type",
                "unknown"
            )
        )

        username = html.escape(
            str(
                event.get(
                    "username",
                    "unknown"
                )
            )
        )

        ip = html.escape(
            str(
                event.get(
                    "ip",
                    "unknown"
                )
            )
        )

        event_time = html.escape(
            str(
                event.get(
                    "time_iso",
                    event.get(
                        "time",
                        "unknown"
                    )
                )
            )
        )

        if event_type == "success":

            icon = "✅"

        elif event_type == "failed":

            icon = "❌"

        else:

            icon = "ℹ️"

        lines.append(

            f"{icon} "
            f"<code>{event_time}</code>\n"

            + tr(
                language,
                "events.user",
                value=username
            )

            + "\n"

            + tr(
                language,
                "events.ip",
                value=ip
            )
        )

    return "\n".join(
        lines
    )


def event_signature(
    event
):

    return "|".join(

        [
            str(
                event.get(
                    "time",
                    ""
                )
            ),

            str(
                event.get(
                    "type",
                    ""
                )
            ),

            str(
                event.get(
                    "username",
                    ""
                )
            ),

            str(
                event.get(
                    "ip",
                    ""
                )
            ),

            str(
                event.get(
                    "auth_method",
                    ""
                )
            ),

            str(
                event.get(
                    "fingerprint",
                    ""
                )
            )
        ]
    )


def block_signature(
    ip,
    block
):

    return "|".join(

        [
            str(ip),

            str(
                block.get(
                    "level",
                    ""
                )
            ),

            str(
                block.get(
                    "failed_attempts",
                    ""
                )
            ),

            str(
                block.get(
                    "blocked_at",
                    ""
                )
            ),

            str(
                block.get(
                    "expires_at",
                    ""
                )
            ),

            str(
                block.get(
                    "permanent",
                    ""
                )
            )
        ]
    )