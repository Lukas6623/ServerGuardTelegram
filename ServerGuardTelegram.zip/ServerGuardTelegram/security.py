from config import (
    EVENTS_FILE,
    MAX_EVENTS_TO_SHOW
)

from database import load_json

import html


# ============================================================
# LOAD EVENTS
# ============================================================

def load_events():

    data = load_json(
        EVENTS_FILE,
        []
    )

    if not isinstance(
        data,
        list
    ):
        return []

    return data


# ============================================================
# SSH STATUS
# ============================================================

def security_status():

    events = load_events()

    failed = 0
    success = 0

    for event in events:

        if not isinstance(
            event,
            dict
        ):
            continue

        event_type = event.get(
            "type"
        )

        if event_type == "failed":

            failed += 1

        elif event_type == "success":

            success += 1

    return {
        "events": len(events),
        "failed": failed,
        "success": success
    }


# ============================================================
# STATUS TEXT
# ============================================================

def build_status_text(
    language=None
):

    status = security_status()

    return (
        "🛡️ <b>ServerGuard Status</b>\n\n"

        "🔐 <b>SSH:</b> ACTIVE\n"
        "🤖 <b>Telegram:</b> ACTIVE\n\n"

        f"📋 <b>Events:</b> "
        f"{status['events']}\n"

        f"❌ <b>Failed:</b> "
        f"{status['failed']}\n"

        f"✅ <b>Successful:</b> "
        f"{status['success']}"
    )


# ============================================================
# EVENTS TEXT
# ============================================================

def build_events_text(
    language=None
):

    events = load_events()

    if not events:

        return (
            "📋 <b>SSH Events</b>\n\n"
            "No events recorded."
        )

    events = events[
        -MAX_EVENTS_TO_SHOW:
    ]

    lines = [
        "📋 <b>SSH Events</b>",
        ""
    ]

    for event in reversed(
        events
    ):

        if not isinstance(
            event,
            dict
        ):
            continue

        event_type = str(
            event.get(
                "type",
                "unknown"
            )
        )

        username = html.escape(
            str(
                event.get(
                    "username",
                    "unknown"
                )
            )
        )

        ip = html.escape(
            str(
                event.get(
                    "ip",
                    "unknown"
                )
            )
        )

        event_time = html.escape(
            str(
                event.get(
                    "time_iso",
                    event.get(
                        "time",
                        "unknown"
                    )
                )
            )
        )

        if event_type == "success":

            icon = "✅"

        elif event_type == "failed":

            icon = "❌"

        else:

            icon = "ℹ️"

        lines.append(
            f"{icon} "
            f"<code>{event_time}</code>\n"
            f"👤 User: <code>{username}</code>\n"
            f"🌐 IP: <code>{ip}</code>"
        )

    return "\n".join(
        lines
    )


# ============================================================
# EVENT SIGNATURE
# ============================================================

def event_signature(
    event
):

    return "|".join(
        [
            str(
                event.get(
                    "time",
                    ""
                )
            ),

            str(
                event.get(
                    "type",
                    ""
                )
            ),

            str(
                event.get(
                    "username",
                    ""
                )
            ),

            str(
                event.get(
                    "ip",
                    ""
                )
            ),

            str(
                event.get(
                    "auth_method",
                    ""
                )
            ),

            str(
                event.get(
                    "fingerprint",
                    ""
                )
            )
        ]
    )